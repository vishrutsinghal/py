import boto3 as boto
""" tetsubf
"""




# Printing the buckets created in S3
bucket_list = []
for bucket in s3.buckets.all():
	print("buckets are:" , bucket.name)


# check if bucket already created
print (s3.Bucket('test.vishu.bucket2') in s3.buckets.all())
# print(type(s3.buckets.all()))

# creating Bucket
# response = client.create_bucket(
#     ACL='private',
#     Bucket=bucket_name,
#     # CreateBucketConfiguration={
#     #     'LocationConstraint': 'us-east-1'
#     # },
#     # GrantFullControl='write ACP',
#     # GrantRead='string',
#     # GrantReadACP='string',
#     # GrantWrite='string',
#     # GrantWriteACP='string',
#     # ObjectLockEnabledForBucket=True
# ) 

# for bucket in s3.buckets.all():
# 	print("buckets are:" , bucket.name)

# deleting the bucket created
# response = client.delete_bucket(Bucket="test.vishu.bucket2")


# for bucket in s3.buckets.all():
# 	print("buckets are:" , bucket.name)

# uploading file to bucket 
'''
hat method is handled by the S3 Transfer Manager 
which means that it will automatically handle multipart uploads behind the scenes for you, if necessary.

'''
# s3.meta.client.upload_file('get_location.py','test.vishu.bucket1','a/b/test_file.py')

# download file
# s3.meta.client.download_file('test.vishu.bucket1','a/b/test_file.py','D:/')

# delete an object (file)
# client.delete_object(Bucket = 'test.vishu.bucket1',Key = 'a/b/test_file.py')

#get bucket location.
# response = client.get_bucket_location(Bucket='test.vishu.bucket1')
# print(response)


#add object to bucket
'''
The put_object method maps directly to the low-level S3 API request.
It does not handle multipart for you. It will attempt to send the entire body in one request.

'''
# response = client.put_object(Bucket='test.vishu.bucket1', Key = 'test_demo_aws.txt')
# print(response)



################ downloading file

'''
import boto3
import botocore

# BUCKET_NAME = 'my-bucket' # replace with your bucket name
# KEY = 'my_image_in_s3.jpg' # replace with your object key

s3 = boto3.resource('s3')

try:
    s3.Bucket('test.vishu.bucket1').download_file('test_demo_aws.txt', 'local_test_file_aws.txt')
except botocore.exceptions.ClientError as e:
    if e.response['Error']['Code'] == "404":
        print("The object does not exist.")
    else:
        raise

'''