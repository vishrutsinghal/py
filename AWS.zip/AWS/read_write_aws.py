import boto3 as boto
import botocore
""" tetsubf
"""

class aws_file():
	def __init__(self, bucket_name, aws_filename, local_filename):
		self.aws_filename = aws_filename
		self.local_filename = local_filename
		self.bucket_name = bucket_name

	def file_editing(self):
		print("editing file begin")
		with open(self.aws_filename, 'r') as read_file:
			with open(self.local_filename, 'a') as write_file:
				for line in read_file:
					writer = write_file.write(reader)


	def download_aws_file(self, s3):
		try:
		    s3.Bucket(self.bucket_name).download_file(self.aws_filename, self.aws_filename)
		except botocore.exceptions.ClientError as e:
		    if e.response['Error']['Code'] == "404":
		        print("The object does not exist.")
		    else:
		        raise
		finally:
			self.file_editing()



	def uploading_file_aws(self):
		client = boto.client('s3')

		s3 = boto.resource('s3')

		# uploading file to bucket 
		'''
		that method is handled by the S3 Transfer Manager 
		which means that it will automatically handle multipart uploads behind the scenes for you, if necessary.

		'''
		aws_path_upload = 'a/b/c/'
		aws_fileupload_name = aws_path_upload+self.local_filename
		s3.meta.client.upload_file(self.local_filename,self.bucket_name,aws_fileupload_name)

		print("Work Done file uploaded")


		#add object to bucket
		'''
		The put_object method maps directly to the low-level S3 API request.
		It does not handle multipart for you. It will attempt to send the entire body in one request.

		'''
		# response = client.put_object(Bucket='test.vishu.bucket1', Key = 'test_demo_aws.txt')
		# print(response)

	def setting_up(self):
		client = boto.client('s3')

		s3 = boto.resource('s3')

		# Printing the buckets created in S3
		bucket_list = []
		for bucket in s3.buckets.all():
			print("buckets are:" , bucket.name)

		# check if bucket already created test.vishu.bucket2
		print (s3.Bucket(self.bucket_name) in s3.buckets.all())
		self.download_aws_file(s3)


if __name__ == '__main__':
	aws_filename = 'test_demo_aws.txt'
	local_filename = 'local_filename_aws.txt'
	bucket_name = 'test.vishu.bucket1'

	aws = aws_file(bucket_name,aws_filename,local_filename )
	aws.setting_up()
	aws.uploading_file_aws()