def file_editing():
	print("editing file begin")
	with open("text.txt") as f:
		with open("test2.txt", "w") as f1:
			for line in f:
				f1.write(line)


file_editing()