from boto3.s3.connection  import S3Connection
print('/n'. join 
	(i for i in dir(Location) if i[0].isupper()))