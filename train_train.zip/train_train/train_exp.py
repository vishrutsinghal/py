import requests
import json
from pprint import pprint
from operator import itemgetter
from collections import defaultdict
from collections import OrderedDict
import datetime as DT
from time import gmtime, strftime
import math
dict = OrderedDict()

r = requests.get("http://api.bart.gov/api/etd.aspx?cmd=etd&orig=ALL&key=ZLB9-5SSE-94ZT-DWE9&json=y")

route_api  =requests.get("http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=all&key=MW9S-E7SL-26DU-VV8V&json=y")
json_response_route = route_api.json()

origin =[]
route_station = json_response_route["root"]["routes"]["route"]
for list_route in route_station:
    detail_root_list = list_route["config"]["station"]
    # pprint(detail_root_list)
    if "MONT" in detail_root_list:
        origin.append(detail_root_list[0])


# try:
json_response = r.json()
# pprint(json_response)
dictList = []
dict_by_min= []
Destination_station = "MONT"
for distro in json_response["root"]["station"]:
    total_station = distro['abbr']
    if distro["abbr"] in origin:
        des = distro['etd']
        # station_name = distro["name"]
        for details in des:
            # if Destination_station in detail_root_list:
            for minutes in details["estimate"]:
                station_name = distro["name"]
                # pprint(station_name)
                dict = {}

                # dict["origin_start"] = distro["abbr"]
                dict["origin_start"] = station_name
                try:
                    dict["minutes"] = int(minutes["minutes"])
                except:
                    dict["minutes"] = 0

                dict["delay"] = minutes["delay"]


                dictList.append(dict)

                dict_by_min = sorted(dictList, key=itemgetter('minutes'))

if len(dict_by_min) <10 or len(dict_by_min)==0:
    dict_by_min=dict_by_min[:]
else:
    dict_by_min = dict_by_min[:10]

current_time = strftime("%Y-%m-%d %H:%M:%S", gmtime())

pprint("-"*35)
pprint(Destination_station+ " "*5 + current_time)
pprint("-"*35)
# pprint(dict_by_min)
for data in dict_by_min:
    # try:
        # delay_data = math.floor(int(data["delay"])/60)
        # route_details = str(data["minutes"])+" min "+" "*5+ data["origin_start"] + " "*5+ str(delay_data)+ " min"
    route_details = str(data["minutes"])+" min "+" "*5+ data["origin_start"]
    pprint(route_details)
    # except:
        # delay_data = 0
        # route_details = str(data["minutes"])+" min "+" "*5+ data["origin_start"]
        # pprint(route_details)
# except:
#     pprint("Bad Request!!!!")