import requests
import json
from pprint import pprint
from operator import itemgetter
from collections import defaultdict
from collections import OrderedDict
import datetime as DT
from time import gmtime, strftime
import math
dict = OrderedDict()

r = requests.get("http://api.bart.gov/api/etd.aspx?cmd=etd&orig=ALL&key=ZLB9-5SSE-94ZT-DWE9&json=y")
try:
    json_response = r.json()
    top_10 = []
    dictList = []
    Destination_station = "Richmond"

    for distro in json_response["root"]["station"]:
        total_station = distro['abbr']
        des = distro['etd']

        for destination in des:
            if destination["destination"] == Destination_station:
                for details in des:

                    for minutes in details["estimate"]:
                        dict = {}


                        dict["distro"] = distro["abbr"]
                        try:
                            dict["minutes"] = int(minutes["minutes"])
                        except:
                            dict["minutes"] = 0

                        dict["delay"] = minutes["delay"]


                        dictList.append(dict)

                        dict_by_min = sorted(dictList, key=itemgetter('minutes'))
    if len(dict_by_min) <10:
        dict_by_min=dict_by_min[:]
    else:
        dict_by_min = dict_by_min[:10]

    current_time = strftime("%Y-%m-%d %H:%M:%S", gmtime())

    pprint("-"*35)
    pprint(Destination_station+ " "*5 + current_time)
    pprint("-"*35)
    # pprint(dict_by_min)
    for data in dict_by_min:
        try:
            delay_data = math.floor(int(data["delay"])/60)
            route_details = str(data["minutes"])+" min "+" "*5+ data["distro"] + " "*5+ str(delay_data)+ " min"
            pprint(route_details)
        except:
            delay_data = 0
            route_details = str(data["minutes"])+" min "+" "*5+ data["distro"] + " "*5+ str(delay_data)+ " min"
            pprint(route_details)

        # route_details = str(data["minutes"])+" min "+" "*5+ data["distro"] + " "*5+ int(data["delay"])
        # pprint(route_details)

except:
    print("Bad URL!!!!!")