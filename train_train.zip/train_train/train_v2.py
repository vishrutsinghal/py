import requests
from pprint import pprint

# r  =requests.get("http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=all&key=MW9S-E7SL-26DU-VV8V&json=y")
# json_response_route = r.json()
# pprint(json_response_route)
# for distro in json_response["root"]["routes"]["route"]["config"]["station"]:
# 	pprint(distro)
# # pprint(json_response_route)
# route_station = json_response_route["root"]["routes"]["route"]
# for list_route in route_station:
# 	detail_root_list = list_route["config"]["station"]
# 	# for step_route in detail_root_list:
# 	# 	pprint(step_route)
# 	# pprint(detail_root_list)
# 	if "MONT" in detail_root_list:
# 		origin = detail_root_list[0]
# 		pprint(origin)

# # pprint(detail_root_list)

import requests
import json
from pprint import pprint
from operator import itemgetter
from collections import defaultdict
from collections import OrderedDict
import datetime as DT
from time import gmtime, strftime
import math
dict = OrderedDict()

try:
	r = requests.get("http://api.bart.gov/api/etd.aspx?cmd=etd&orig=RICH&key=ZLB9-5SSE-94ZT-DWE9&json=y")
	pprint(r.json())
except ConnectionError:
	pprint("bas")