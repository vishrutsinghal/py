import requests
import json
from pprint import pprint
from operator import itemgetter
from collections import defaultdict
from collections import OrderedDict
import datetime as DT
from time import gmtime, strftime
import math
import sys
dict = OrderedDict()

try:
    #API for getting general info "minutes", "origin", "delay", "name" 
    r = requests.get("http://api.bart.gov/api/etd.aspx?cmd=etd&orig=ALL&key=ZLB9-5SSE-94ZT-DWE9&json=y")
    json_response = r.json()

    #API for collecting stations between two source and destination of stations
    route_api  =requests.get("http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=all&key=MW9S-E7SL-26DU-VV8V&json=y")
    json_response_route = route_api.json()

    origin =[]
    Destination_station = "WOAK"
    route_station = json_response_route["root"]["routes"]["route"]
    for list_route in route_station:
        detail_root_list = list_route["config"]["station"]
        # collecting source stations
        if Destination_station in detail_root_list:
            origin.append(detail_root_list[0])

    dictList = []
    dict_by_min= []

    for distro in json_response["root"]["station"]:
        total_station = distro['abbr']
        if distro["abbr"] in origin:
            des = distro['etd']

            for details in des:

                for minutes in details["estimate"]:
                    # getting comman name of station
                    station_name = distro["name"]
 
                    dict = {}
                    dict["origin_start"] = station_name
                    # Handling the case when train status is "Leaving" used "0" to suggest train is leaving so 0 waiting time
                    try:
                        dict["minutes"] = int(minutes["minutes"])
                    except:
                        dict["minutes"] = 0

                    dict["delay"] = minutes["delay"]


                    dictList.append(dict)

                    # Sort the dictionary basis on minutes
                    dict_by_min = sorted(dictList, key=itemgetter('minutes'))

    if len(dict_by_min) <10 or len(dict_by_min)==0:
        dict_by_min=dict_by_min[:]
    else:
        dict_by_min = dict_by_min[:10]

    #fetching current date and time 
    current_time = strftime("%Y-%m-%d %H:%M:%S", gmtime())

    #display the output in desired format
    pprint("-"*35)
    pprint(Destination_station+ " "*5 + current_time)
    pprint("-"*35)

    for data in dict_by_min:
        route_details = str(data["minutes"])+" min "+" "*5+ data["origin_start"]
        pprint(route_details)

except:
    pprint("Bad Request!!!!")