cucumberjvm-selenium-pageObject
=====================

Page Object Framework using cucumber jvm (java) and Selenium java.
Read about it on [seleniumframework.com] (http://www.seleniumframework.com/cucumber-jvm-2/what-is-cucumber-jvm/)
