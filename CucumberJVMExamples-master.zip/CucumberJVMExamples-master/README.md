# CucumberJVMExamples
Cucumber JVM with Selenium Java  
All explanation is here - http://www.seleniumframework.com/cucumber-jvm-3/cucumber-jvm-and-selenium/  

# Index  
[Browser Commands class1](http://www.seleniumframework.com/cucumber-jvm-3/browser-commands/)  
[Find Element Strategies class2](http://www.seleniumframework.com/cucumber-jvm-3/find-element-strategies/)  
[Web Element Operations class3](http://www.seleniumframework.com/cucumber-jvm-3/web-element-operations/)  
[Waits and Synchronization class4](http://www.seleniumframework.com/cucumber-jvm-3/waits-and-synchronization/)  
[Switch Commands class5](http://www.seleniumframework.com/cucumber-jvm-3/switch-commands/)  
[Tag Scenarios class6](http://www.seleniumframework.com/cucumber-jvm-3/tag-scenarios)  
[Boolean operations on Tags class7](http://www.seleniumframework.com/cucumber-jvm-3/orng-and-andg-of-scenarios)  
[Test Data Scenario Outline & Data Tables class 3](http://www.seleniumframework.com/cucumber-jvm-3/data-tables/)  
[Test Data Parse Excel with Apache POI + Pipe the parsed data into web form class 8](http://www.seleniumframework.com/cucumber-jvm-3/test-data-with-excel/)  
[Headless Testing using PhantomJS + GhostDriver class 9](http://www.seleniumframework.com/cucumber-jvm-3/headless-testing/)  
[Test Data with Json using Gson Class 10](http://www.seleniumframework.com/cucumber-jvm-3/test-data-with-json/)  
  
  
  

