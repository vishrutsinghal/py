package stepDefinitions;

import org.javalite.activejdbc.Model;

/**
 * Created by pmacharl on 1/27/2015.
 */
public class Product extends Model{
}
