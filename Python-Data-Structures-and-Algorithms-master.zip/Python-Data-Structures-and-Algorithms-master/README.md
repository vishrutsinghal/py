# Python-Data-Structures-and-Algorithms

***Data Structures & Algorithms implementation using Python 3 and PyCharm.***

|       Data Structure      |         Status          |
| ------------------------- | ----------------------- |
|         Arrays            |         Completed       |
|         Stacks            |         Completed       |
|         Queues            |         Completed       |
|       Linked List         |         Completed       |
|   Binary Search Tree      |         Completed       |
|         AVL Tree          |         Completed       |
|         Heap              |         Completed       |
|      Dictionaries         |         Completed       |
|   Ternary Search Tree     |         Completed       |
|   Bredth First Search     |         Completed       |
|    Depth First Search     |         Completed       |
|    Dijkstra Algorithm     |         Completed       |
|  Bellman-Ford Algorithm   |         Completed       |
|    Kruskal Algorithm      |         Completed       |
| Prim's Jarnik Algorithm   |         Completed       |
|       Quick Sort          |         Completed       |
|       Merge Sort          |         Completed       |
|     Selection Sort        |         Completed       |
|     Insertion Sort        |         Completed       |
|       Bubble Sort         |         Completed       |
