from selenium import webdriver

# def test():
driver = webdriver.Chrome()
driver.get("https://datatables.net/examples/basic_init/scroll_xy.html")
path = '//*[@id="example"]/tbody/tr[10]/td[1]'
click_tbody = '//*[@id="example"]/tbody'
ele = driver.find_element_by_xpath(path)
driver.find_element_by_xpath(click_tbody).click()
# driver.execute_script("""return document.evaluate(ele, document, null, 
# 					XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.scrollIntoView(true);""")
ele.location_once_scrolled_into_view




# SCROLL_PAUSE_TIME = 0.5

# # Get scroll height
# last_height = driver.execute_script("return document.body.scrollHeight")

# while True:
#     # Scroll down to bottom
#     driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

#     # Wait to load page
#     time.sleep(SCROLL_PAUSE_TIME)

#     # Calculate new scroll height and compare with last scroll height
#     new_height = driver.execute_script("return document.body.scrollHeight")
#     if new_height == last_height:
#         break
#     last_height = new_height

-----------------------------------------------------------------------------
# from selenium import webdriver
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.support.wait import WebDriverWait
# from selenium.webdriver.common.by import By   


# driver = webdriver.Firefox()
# driver.get('www.url.com')

# try:
#     wait = driver.WebDriverWait(driver,10).until(EC.presence_of_element_located(By.CLASS_NAME,'x'))
# except:
#     pass

-----------------------------------------------------------------------

def wait_for_element(element):
     count = 1
     if(self.is_element_present(element)):
          if(self.is_visible(element)):
              return
          else:
              time.sleep(.1)
              count = count + 1
     else:
         time.sleep(.1)
         count = count + 1
         if(count > 300):
             print("Element %s not found" % element)
             self.stop
             #prevents infinite loop

-----------------------------------------------------------------------

wait.until(lambda driver: driver.find_element_by_id('someId'))



try:
    wait = driver.WebDriverWait(driver,10).until(EC.presence_of_element_located(By.CLASS_NAME,'x'))
except:
    pass


 driver.execute_script("window.scrollTo(0, Y)")
