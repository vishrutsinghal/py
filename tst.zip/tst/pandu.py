import pandas as pd
import numpy as np

# r_csv = pd.read_csv("sample_csv.csv")
# print(r_csv)

# df = pd.DataFrame({'AAA' : [4,5,6,7], 'BBB' : [10,20,30,40],'CCC' : [100,50,-30,-50]})

# print(df)
# print()

# df.loc[df.AAA >= 5,'BBB'] = -1
# print(df)

# df.loc[df.AAA>=5,["BBB", "CCC"]]= 555
# print(df)

# df.loc[df.AAA < 5,['BBB','CCC']] = 2000
# print(df)

# df_mask = pd.DataFrame({'AAA' : [True] * 4, 'BBB' : [False] * 4,'CCC' : [True,False] * 2})
# -------------------------------------------------------------------------------------------------

"""A Series is a one-dimensional array-like object containing a sequence of values"""

# obj = pd.Series([4,3,45,5])
# print(obj)

# print(obj.values)
# print()

# print(obj.index)

# ----------------------------------------------------------------

# obj2 = pd.Series([4, 7, -5, 3], index=['d', 'b', 'a', 'c'])

# print(obj2)
# print()
# print(obj2["a"])
# print(obj2[["c","a","b"]])
# print(obj2[obj2>0])
# print(obj2*2)
# print("b" in obj2)
# print("e" in obj2)

# ---------------------------------------------------------------

# sdata = {'Ohio': 35000, 'Texas': 71000, 'Oregon': 16000, 'Utah': 5000}
# obj3 = pd.Series(sdata)
# print(obj3)
# print()

# states = ['California', 'Ohio', 'Oregon', 'Texas']
# obj4 = pd.Series(sdata, index = states)
# print(obj4)
# print()
# print(pd.isnull(obj4))    # print(obj4.isnull())
# print()
# print(pd.notnull(obj4))
# print()
# print(obj3+obj4)

# obj4.name = "Population"
# obj4.index.name = "state"

# print(obj4)

# --------------------------------------------------------------------

# obj = pd.Series([4,3,45,5])
# print(obj)
# obj.index = ['Bob', 'Steve', 'Jeff', 'Ryan']
# print(obj)

# ---------------------------------------------------------------------

''' A DataFrame represents a rectangular table of data and contains an ordered collec‐
tion of columns, each of which can be a different value type (numeric, string,
boolean, etc.). The DataFrame has both a row and column index; it can be thought of
as a dict of Series all sharing the same index. Under the hood, the data is stored as one
or more two-dimensional blocks rather than a list, dict, or some other collection of
one-dimensional arrays. '''

# data = {'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada', 'Nevada'],
# 'year': [2000, 2001, 2002, 2001, 2002, 2003],
# 'pop': [1.5, 1.7, 3.6, 2.4, 2.9, 3.2]}
# frame = pd.DataFrame(data)
# print(frame)
# print()
# print(frame.head())

# frame2 = pd.DataFrame(data, columns=['year', 'state', 'pop'])
# print(frame2)

# frame2 = pd.DataFrame(data, columns=['year', 'state', 'pop', 'debt'],
# index=['one', 'two', 'three', 'four','five', 'six'])

# print (frame2)
# print()
# print(frame2.columns)
# print(frame2['state'])
# print(frame2.year)

'''frame2[column] works for any column name, but  frame2.column
only works when the column name is a valid Python variable
name.'''

'''Rows can also be retrieved by position or name with the special  loc attribute '''

# print(frame2.loc["three"])
# print()
# frame2["debt"]= 16.5
# print(frame2)
# print()

# frame2['debt'] = np.arange(6.)
# print(frame2)
# -----------------------------------------------------------------------------------------

'''When you are assigning lists or arrays to a column, the value’s length must match the
length of the DataFrame. If you assign a Series, its labels will be realigned exactly to
the DataFrame’s index, inserting missing values in any holes:'''

# value = pd.Series([1.2, -1.5,-1.7], index= ["two", "four", "five"])
# print(value)

# frame2['debt'] = value
# print(frame2)
# print()
# frame2["eastern"] = frame2.state == "Ohio"
# print(frame2)
# print()
# frame2["demo"]= "None"
# print(frame2)


'''The  del method can then be used to remove this column:'''

# del frame2['eastern']
# print(frame2.columns)

# pop = {'Nevada': {2001: 2.4, 2002: 2.9},
# 	'Ohio': {2000: 1.5, 2001: 1.7, 2002: 3.6}}

# frame3 = pd.DataFrame(pop)
# print(frame3)
# print()

# '''You can transpose the DataFrame (swap rows and columns)'''

# print(frame3.T)
# print()

# frame3 = pd.DataFrame(pop, index= [2001, 2001, 2003])
# print(frame3)

# frame3.index.name = 'year'; frame3.columns.name = 'state'
# print()
# print(frame3)
# print()
# print(frame3.values)

# print('Ohio' in frame3.columns)
# print(2003 in frame3.index)



'''

2D ndarray  --- A matrix of data, passing optional row and column labels
dict of arrays, lists, or tuples --- Each sequence becomes a column in the DataFrame; all sequences must be the same length
NumPy structured/record
array          ----------  Treated as the “dict of arrays” case

dict of Series ------ Each value becomes a column; indexes from each Series are unioned together to form the
						result’s row index if no explicit index is passed
dict of dicts -------- Each inner dict becomes a column; keys are unioned to form the row index as in the “dict of
					Series” case
List of dicts or Series  -------- Each item becomes a row in the DataFrame; union of dict keys or Series indexes become the
					DataFrame’s column labels
List of lists or tuples ------ Treated as the “2D ndarray” case
Another DataFrame -----The DataFrame’s indexes are used unless different ones are passed
NumPy MaskedArray --------- lLike the “2D ndarray” case except masked values become NA/missing in the DataFrame result '''



# --------------------------------------------------------------------------

# Index Objects

"""pandas’s Index objects are responsible for holding the axis labels and other metadata
(like the axis name or names). Any array or other sequence of labels you use when
constructing a Series or DataFrame is internally converted to an Index:"""



# obj = pd.Series(range(3), index= ["a","b","c"])
# print(obj)
# index = obj.index
# print(index[1:])

'''Index objects are immutable and thus can’t be modified by the user:'''

# index[1] = 'd' # TypeError

'''Immutability makes it safer to share Index objects among data structures: '''

# labels = pd.Index(np.arange(3))
# print(labels)

# obj2 = pd.Series([1.3, 5.6, 100], index = labels)
# print(obj2)


'''Unlike Python sets, a pandas Index can contain duplicate labels:'''

# dup_labels = pd.Index(['foo', 'foo', 'bar', 'bar'])
# print(dup_labels)


'''

append ---Concatenate with additional Index objects, producing a new Index
difference ---Compute set difference as an Index
intersection ---Compute set intersection
union--- Compute set union
isin ---Compute boolean array indicating whether each value is contained in the passed collection
delete ---Compute new Index with element at index  i deleted
drop ---Compute new Index by deleting passed values
insert ---Compute new Index by inserting element at index  i
is_monotonic ---Returns  True if each element is greater than or equal to the previous element
is_unique ---Returns  True if the Index has no duplicate values
unique ---Compute the array of unique values in the Index

'''

# ------------------------------------------------------------

# Reindexing

''' An important method on pandas objects is  reindex , which means to create a new
object with the data conformed to a new index. '''

# obj = pd.Series([4.5, 7.2, -5.3, 3.6], index=['d', 'b', 'a', 'c'])
# print(obj)
# print()

'''Calling  reindex on this Series rearranges the data according to the new index, intro‐
ducing missing values if any index values were not already present:'''


# obj2 = obj.reindex(['a', 'b', 'c', 'd', 'e'])
# print(obj2)

'''
For ordered data like time series, it may be desirable to do some interpolation or fill‐
ing of values when reindexing. The  method option allows us to do this, using a
method such as  ffill , which forward-fills the values:
'''

# obj3 = pd.Series(['blue', 'purple', 'yellow'], index=[0, 2, 4])
# print(obj3)

# obj4 = obj3.reindex(range(6), method= 'ffill')   #forward fill
# print(obj4)



'''With DataFrame,  reindex can alter either the (row) index, columns, or both. When
passed only a sequence, it reindexes the rows in the result:
'''

# frame = pd.DataFrame(np.arange(9).reshape((3,3)),
# 		index=['a','c','d'],
# 		columns= ['Ohio', 'Texas', 'California'])

# print(frame)
# print()
# frame2 = frame.reindex(['a', 'b', 'c', 'd'])
# print(frame2)
# print()

'''The columns can be reindexed with the  columns keyword'''
# states = ['Texas', 'Utah', 'California']

# frame3 = frame.reindex(columns=states)
# print(frame3)


'''

index --- New sequence to use as index. Can be Index instance or any other sequence-like Python data structure. An
			Index will be used exactly as is without any copying.
method --- Interpolation (fill) method;  'ffill' fills forward, while  'bfill' fills backward.
fill_value --- Substitute value to use when introducing missing data by reindexing.
limit --- When forward- or backfilling, maximum size gap (in number of elements) to fill.
tolerance ---  When forward- or backfilling, maximum size gap (in absolute numeric distance) to fill for inexact matches.
level --- Match simple Index on level of MultiIndex; otherwise select subset of.
copy --- If  True , always copy underlying data even if new index is equivalent to old index; if  False , do not copy
			the data when the indexes are equivalent.

'''

# ---------------------------------------------------------------------------

''' Dropping Entries from an Axis '''

''' Dropping one or more entries from an axis is easy if you already have an index array
or list without those entries. As that can require a bit of munging and set logic, the
drop method will return a new object with the indicated value or values deleted from
an axis: ''' 

# obj = pd.Series(np.arange(5.), index=['a', 'b', 'c', 'd', 'e'])
# print(obj)
# print()

# new_obj = obj.drop("c")
# print(new_obj)

# new_obj = obj.drop(['d', 'c'])
# print(new_obj)


''' 
With DataFrame, index values can be deleted from either axis. To illustrate this, we
first create an example DataFrame:
'''

# data = pd.DataFrame(np.arange(16).reshape((4, 4)),
# index=['Ohio', 'Colorado', 'Utah', 'New York'],
# columns=['one', 'two', 'three', 'four'])

# print(data)
# print()

'''Calling  drop with a sequence of labels will drop values from the row labels (axis 0):'''

# new_data =  data.drop(['Colorado', 'Ohio'])
# print(new_data)

'''You can drop values from the columns by passing  axis=1 or  axis='columns' '''



# new_data = data.drop('two', axis = 'columns')
# print(new_data)


'''
Many functions, like  drop , which modify the size or shape of a Series or DataFrame,
can manipulate an object in-place without returning a new object
'''

''' Be careful with the  inplace , as it destroys any data that is dropped.'''


# obj.drop('c', inplace=True)
# print(obj)


# ------------------------------------------------------------------------------------------

"""
Indexing, Selection, and Filtering

"""


'''
Series indexing ( obj[...] ) works analogously to NumPy array indexing, except you
can use the Series’s index values instead of only integers.
'''

# obj = pd.Series(np.arange(4.), index=["a","b", "c","d"])

# print(obj)
# print()
# print(obj["b"])
# print(obj[1])
# print(obj[2:4])
# print(obj[["b", "a", "d"]])
# print(obj[[1,3]])
# print(obj[obj<2])
# print(obj['b':'c'])
# obj['b':'c'] = 5
# print(obj)


"""
Indexing into a DataFrame is for retrieving one or more columns either with a single
value or sequence:

"""

data = pd.DataFrame(np.arange(16).reshape((4,4)),
index= ["Ohio", "Colorado","Utah", "New York"],
columns = ["one", "two", "three","four"])

print(data) 
print()

# *********************************
# print(data[['two']])
# print(data[['two', "three"]])
# print(data[:2])
# *********************************

# ==============================
# print(data['three']>5)
# print(data[data['three']>5])
# ==============================

# print(data<5)
data[data<5]= 0
print(data)