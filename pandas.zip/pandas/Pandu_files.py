import pandas as pd
import numpy as np
from functools import reduce

'''
Reading and Writing Data in Text Format
'''

'''

read_csv ---Load delimited data from a file, URL, or file-like object; use comma as default delimiter
read_table ---Load delimited data from a file, URL, or file-like object; use tab ( r'\t' ) as default delimiter
read_fwf ---Read data in fixed-width column format (i.e., no delimiters)
read_clipboard ---Version of  read_table that reads data from the clipboard; useful for converting tables from web
				pages
read_excel ---Read tabular data from an Excel XLS or XLSX file

'''

# df = pd.read_csv("Sales_csv.csv")
# print(df)

# df = pd.read_table('examples.csv', sep=',')
# print(df)

'''
To read this file, you have a couple of options. You can allow pandas to assign default
column names, or you can specify names yourself:

'''

# df = pd.read_csv('examples.csv', header=None)
# print(df)

# df = pd.read_csv('examples.csv', names=["a","b","c","d","message"])
# print(df)

# names = ['a', 'b', 'c', 'd', 'message']
# df = pd.read_csv("examples.csv", names=names, index_col = "message")
# print(df)

# parsed = pd.read_csv("key_csv.csv", index_col = ['key1','key2'])
# print(parsed)

# df = list(open("text.txt"))
# print(df)

