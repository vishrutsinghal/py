import pandas as pd
import numpy as np

# r_csv = pd.read_csv("sample_csv.csv")
# print(r_csv)

# df = pd.DataFrame({'AAA' : [4,5,6,7], 'BBB' : [10,20,30,40],'CCC' : [100,50,-30,-50]})

# print(df)
# print()

# df.loc[df.AAA >= 5,'BBB'] = -1
# print(df)

# df.loc[df.AAA>=5,["BBB", "CCC"]]= 555
# print(df)

# df.loc[df.AAA < 5,['BBB','CCC']] = 2000
# print(df)

# df_mask = pd.DataFrame({'AAA' : [True] * 4, 'BBB' : [False] * 4,'CCC' : [True,False] * 2})
# -------------------------------------------------------------------------------------------------

"""A Series is a one-dimensional array-like object containing a sequence of values"""

# obj = pd.Series([4,3,45,5])
# print(obj)

# print(obj.values)
# print()

# print(obj.index)

# ----------------------------------------------------------------

# obj2 = pd.Series([4, 7, -5, 3], index=['d', 'b', 'a', 'c'])

# print(obj2)
# print()
# print(obj2["a"])
# print(obj2[["c","a","b"]])
# print(obj2[obj2>0])
# print(obj2*2)
# print("b" in obj2)
# print("e" in obj2)

# ---------------------------------------------------------------

# sdata = {'Ohio': 35000, 'Texas': 71000, 'Oregon': 16000, 'Utah': 5000}
# obj3 = pd.Series(sdata)
# print(obj3)
# print()

# states = ['California', 'Ohio', 'Oregon', 'Texas']
# obj4 = pd.Series(sdata, index = states)
# print(obj4)
# print()
# print(pd.isnull(obj4))    # print(obj4.isnull())
# print()
# print(pd.notnull(obj4))
# print()
# print(obj3+obj4)

# obj4.name = "Population"
# obj4.index.name = "state"

# print(obj4)

# --------------------------------------------------------------------

# obj = pd.Series([4,3,45,5])
# print(obj)
# obj.index = ['Bob', 'Steve', 'Jeff', 'Ryan']
# print(obj)

# ---------------------------------------------------------------------

''' A DataFrame represents a rectangular table of data and contains an ordered collec‐
tion of columns, each of which can be a different value type (numeric, string,
boolean, etc.). The DataFrame has both a row and column index; it can be thought of
as a dict of Series all sharing the same index. Under the hood, the data is stored as one
or more two-dimensional blocks rather than a list, dict, or some other collection of
one-dimensional arrays. '''

# data = {'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada', 'Nevada'],
# 'year': [2000, 2001, 2002, 2001, 2002, 2003],
# 'pop': [1.5, 1.7, 3.6, 2.4, 2.9, 3.2]}
# frame = pd.DataFrame(data)
# print(frame)
# print()
# print(frame.head())

# frame2 = pd.DataFrame(data, columns=['year', 'state', 'pop'])
# print(frame2)

# frame2 = pd.DataFrame(data, columns=['year', 'state', 'pop', 'debt'],
# index=['one', 'two', 'three', 'four','five', 'six'])

# print (frame2)
# print()
# print(frame2.columns)
# print(frame2['state'])
# print(frame2.year)

'''frame2[column] works for any column name, but  frame2.column
only works when the column name is a valid Python variable
name.'''

'''Rows can also be retrieved by position or name with the special  loc attribute '''

# print(frame2.loc["three"])
# print()
# frame2["debt"]= 16.5
# print(frame2)
# print()

# frame2['debt'] = np.arange(6.)
# print(frame2)
# -----------------------------------------------------------------------------------------

'''When you are assigning lists or arrays to a column, the value’s length must match the
length of the DataFrame. If you assign a Series, its labels will be realigned exactly to
the DataFrame’s index, inserting missing values in any holes:'''

# value = pd.Series([1.2, -1.5,-1.7], index= ["two", "four", "five"])
# print(value)

# frame2['debt'] = value
# print(frame2)
# print()
# frame2["eastern"] = frame2.state == "Ohio"
# print(frame2)
# print()
# frame2["demo"]= "None"
# print(frame2)


'''The  del method can then be used to remove this column:'''

# del frame2['eastern']
# print(frame2.columns)

# pop = {'Nevada': {2001: 2.4, 2002: 2.9},
# 	'Ohio': {2000: 1.5, 2001: 1.7, 2002: 3.6}}

# frame3 = pd.DataFrame(pop)
# print(frame3)
# print()

# '''You can transpose the DataFrame (swap rows and columns)'''

# print(frame3.T)
# print()

# frame3 = pd.DataFrame(pop, index= [2001, 2001, 2003])
# print(frame3)

# frame3.index.name = 'year'; frame3.columns.name = 'state'
# print()
# print(frame3)
# print()
# print(frame3.values)

# print('Ohio' in frame3.columns)
# print(2003 in frame3.index)



'''

2D ndarray  --- A matrix of data, passing optional row and column labels
dict of arrays, lists, or tuples --- Each sequence becomes a column in the DataFrame; all sequences must be the same length
NumPy structured/record
array          ----------  Treated as the “dict of arrays” case

dict of Series ------ Each value becomes a column; indexes from each Series are unioned together to form the
						result’s row index if no explicit index is passed
dict of dicts -------- Each inner dict becomes a column; keys are unioned to form the row index as in the “dict of
					Series” case
List of dicts or Series  -------- Each item becomes a row in the DataFrame; union of dict keys or Series indexes become the
					DataFrame’s column labels
List of lists or tuples ------ Treated as the “2D ndarray” case
Another DataFrame -----The DataFrame’s indexes are used unless different ones are passed
NumPy MaskedArray --------- lLike the “2D ndarray” case except masked values become NA/missing in the DataFrame result '''



# --------------------------------------------------------------------------

# Index Objects

"""pandas’s Index objects are responsible for holding the axis labels and other metadata
(like the axis name or names). Any array or other sequence of labels you use when
constructing a Series or DataFrame is internally converted to an Index:"""



# obj = pd.Series(range(3), index= ["a","b","c"])
# print(obj)
# index = obj.index
# print(index[1:])

'''Index objects are immutable and thus can’t be modified by the user:'''

# index[1] = 'd' # TypeError

'''Immutability makes it safer to share Index objects among data structures: '''

# labels = pd.Index(np.arange(3))
# print(labels)

# obj2 = pd.Series([1.3, 5.6, 100], index = labels)
# print(obj2)


'''Unlike Python sets, a pandas Index can contain duplicate labels:'''

# dup_labels = pd.Index(['foo', 'foo', 'bar', 'bar'])
# print(dup_labels)


'''

append ---Concatenate with additional Index objects, producing a new Index
difference ---Compute set difference as an Index
intersection ---Compute set intersection
union--- Compute set union
isin ---Compute boolean array indicating whether each value is contained in the passed collection
delete ---Compute new Index with element at index  i deleted
drop ---Compute new Index by deleting passed values
insert ---Compute new Index by inserting element at index  i
is_monotonic ---Returns  True if each element is greater than or equal to the previous element
is_unique ---Returns  True if the Index has no duplicate values
unique ---Compute the array of unique values in the Index

'''

# ------------------------------------------------------------

# Reindexing

''' An important method on pandas objects is  reindex , which means to create a new
object with the data conformed to a new index. '''

# obj = pd.Series([4.5, 7.2, -5.3, 3.6], index=['d', 'b', 'a', 'c'])
# print(obj)
# print()

'''Calling  reindex on this Series rearranges the data according to the new index, intro‐
ducing missing values if any index values were not already present:'''


# obj2 = obj.reindex(['a', 'b', 'c', 'd', 'e'])
# print(obj2)

'''
For ordered data like time series, it may be desirable to do some interpolation or fill‐
ing of values when reindexing. The  method option allows us to do this, using a
method such as  ffill , which forward-fills the values:
'''

# obj3 = pd.Series(['blue', 'purple', 'yellow'], index=[0, 2, 4])
# print(obj3)

# obj4 = obj3.reindex(range(6), method= 'ffill')   #forward fill
# print(obj4)



'''With DataFrame,  reindex can alter either the (row) index, columns, or both. When
passed only a sequence, it reindexes the rows in the result:
'''

# frame = pd.DataFrame(np.arange(9).reshape((3,3)),
# 		index=['a','c','d'],
# 		columns= ['Ohio', 'Texas', 'California'])

# print(frame)
# print()
# frame2 = frame.reindex(['a', 'b', 'c', 'd'])
# print(frame2)
# print()

'''The columns can be reindexed with the  columns keyword'''
# states = ['Texas', 'Utah', 'California']

# frame3 = frame.reindex(columns=states)
# print(frame3)


'''

index --- New sequence to use as index. Can be Index instance or any other sequence-like Python data structure. An
			Index will be used exactly as is without any copying.
method --- Interpolation (fill) method;  'ffill' fills forward, while  'bfill' fills backward.
fill_value --- Substitute value to use when introducing missing data by reindexing.
limit --- When forward- or backfilling, maximum size gap (in number of elements) to fill.
tolerance ---  When forward- or backfilling, maximum size gap (in absolute numeric distance) to fill for inexact matches.
level --- Match simple Index on level of MultiIndex; otherwise select subset of.
copy --- If  True , always copy underlying data even if new index is equivalent to old index; if  False , do not copy
			the data when the indexes are equivalent.

'''

# ---------------------------------------------------------------------------

''' Dropping Entries from an Axis '''

''' Dropping one or more entries from an axis is easy if you already have an index array
or list without those entries. As that can require a bit of munging and set logic, the
drop method will return a new object with the indicated value or values deleted from
an axis: ''' 

# obj = pd.Series(np.arange(5.), index=['a', 'b', 'c', 'd', 'e'])
# print(obj)
# print()

# new_obj = obj.drop("c")
# print(new_obj)

# new_obj = obj.drop(['d', 'c'])
# print(new_obj)


''' 
With DataFrame, index values can be deleted from either axis. To illustrate this, we
first create an example DataFrame:
'''

# data = pd.DataFrame(np.arange(16).reshape((4, 4)),
# index=['Ohio', 'Colorado', 'Utah', 'New York'],
# columns=['one', 'two', 'three', 'four'])

# print(data)
# print()

'''Calling  drop with a sequence of labels will drop values from the row labels (axis 0):'''

# new_data =  data.drop(['Colorado', 'Ohio'])
# print(new_data)

'''You can drop values from the columns by passing  axis=1 or  axis='columns' '''



# new_data = data.drop('two', axis = 'columns')
# print(new_data)


'''
Many functions, like  drop , which modify the size or shape of a Series or DataFrame,
can manipulate an object in-place without returning a new object
'''

''' Be careful with the  inplace , as it destroys any data that is dropped.'''


# obj.drop('c', inplace=True)
# print(obj)


# ------------------------------------------------------------------------------------------

"""
Indexing, Selection, and Filtering

"""


'''
Series indexing ( obj[...] ) works analogously to NumPy array indexing, except you
can use the Series’s index values instead of only integers.
'''

# obj = pd.Series(np.arange(4.), index=["a","b", "c","d"])

# print(obj)
# print()
# print(obj["b"])
# print(obj[1])
# print(obj[2:4])
# print(obj[["b", "a", "d"]])
# print(obj[[1,3]])
# print(obj[obj<2])
# print(obj['b':'c'])
# obj['b':'c'] = 5
# print(obj)


"""
Indexing into a DataFrame is for retrieving one or more columns either with a single
value or sequence:

"""

# data = pd.DataFrame(np.arange(16).reshape((4,4)),
# index= ["Ohio", "Colorado","Utah", "New York"],
# columns = ["one", "two", "three","four"])

# print(data) 
# print()

# *********************************
# print(data[['two']])
# print(data[['two', "three"]])
# print(data[:2])
# *********************************

# ==============================
# print(data['three']>5)
# print(data[data['three']>5])
# ==============================

# print(data<5)
# data[data<5]= 0
# print(data)


# ---------------------------------------------------------------------

'''Selection with loc and iloc'''

'''For DataFrame label-indexing on the rows, I introduce the special indexing operators
loc and  iloc . They enable you to select a subset of the rows and columns from a
DataFrame with NumPy-like notation using either axis labels ( loc ) or integers
( iloc ).'''


# data = pd.DataFrame(np.arange(16).reshape((4,4)),
# index= ["Ohio", "Colorado","Utah", "New York"],
# columns = ["one", "two", "three","four"])

# print(data) 
# print()

# data_segment = data.loc['Colorado',['two','three']]
# print(data_segment)

''' We’ll then perform some similar selections with integers using  iloc '''

# data_segment = data.iloc[2,[3,0,1]]
# print(data_segment)

# data_segment = data.iloc[2]
# print(data_segment)

# data_segment = data.iloc[[1,2],[3,0,1]]
# print(data_segment)  # .T for trnsapose

'''  Both indexing functions work with slices in addition to single labels or lists of labels:  '''

# print(data.loc[:"Utah", "two"])

# data_segment = data.iloc[:,:3][data.three >5]   # all rows and 3 columns
# print(data_segment)


"""

df[val] ---- Select single column or sequence of columns from the DataFrame; special case
			conveniences: boolean array (filter rows), slice (slice rows), or boolean DataFrame
			(set values based on some criterion)
df.loc[val] --- Selects single row or subset of rows from the DataFrame by label
df.loc[:, val] --- Selects single column or subset of columns by label
df.loc[val1, val2] --- Select both rows and columns by label
df.iloc[where] --- Selects single row or subset of rows from the DataFrame by integer position

df.iloc[:, where] --- Selects single column or subset of columns by integer position
df.iloc[where_i, where_j] --- Select both rows and columns by integer position
df.at[label_i, label_j] --- Select a single scalar value by row and column label
df.iat[i, j] --- Select a single scalar value by row and column position (integers)
reindex method --- Select either rows or columns by labels
get_value, set_value methods --- Select single value by row and column label

"""

 
''' 

To select rows whose column value equals a scalar, some_value, use ==: 

df.loc[df['column_name'] == some_value]
To select rows whose column value is in an iterable, some_values, use isin:

df.loc[df['column_name'].isin(some_values)]
Combine multiple conditions with &:

df.loc[(df['column_name'] == some_value) & df['other_column'].isin(some_values)]
To select rows whose column value does not equal some_value, use !=:

df.loc[df['column_name'] != some_value]
isin returns a boolean Series, so to select rows whose value is not in some_values, negate the boolean Series using ~:

df.loc[~df['column_name'].isin(some_values)]

'''

'''
WHERE
'''
# s = pd.Series(range(5))*2
# print(s)
# print()
# print(s.where (s>2))
# print(s.where (s>2, 10))



# raw_data = {'first_name': ['Jason', 'Molly', np.nan, np.nan, np.nan], 
#         'nationality': ['USA', 'USA', 'France', 'UK', 'UK'], 
#         'age': [42, 52, 36, 24, 70]}
# df = pd.DataFrame(raw_data, columns = ['first_name', 'nationality', 'age'])


# data_segment = df[df['first_name'].notnull() & (df['nationality'] == "USA")]
# print(data_segment)



# df = pd.DataFrame({'A': 'foo bar foo bar foo bar foo foo'.split(),
#                    'B': 'one one two three two two one three'.split(),
#                    'C': np.arange(8), 'D': np.arange(8) * 2})
# print(df)
# print()
# print(df.loc[df['A'] == 'foo'])

"""
If you have multiple values you want to include, put them in a list (or more generally, any iterable) and use isin:
"""

# print(df.loc[df['B'].isin(['one','three'])])

'''
Note, however, that if you wish to do this many times, it is more efficient to make an index first, and then use df.loc:
'''

# df = df.set_index(['B'])
# print(df.loc['one'])


# --------------------------------------------------------------------------------------------------------------------
'''
Integer Indexes

'''

# ser =  pd.Series(np.arange(3.))
# print(ser)
# print()
# print(ser[-1])   #error

# ser2 = pd.Series(np.arange(3.), index=['a', 'b', 'c'])
# print(ser2)
# print()
# print(ser.loc[1])

# ----------------------------------------------------------------------------------------------------------------------

'''
Arithmetic and Data Alignment
'''

'''

An important pandas feature for some applications is the behavior of arithmetic
between objects with different indexes. When you are adding together objects, if any
index pairs are not the same, the respective index in the result will be the union of the
index pairs. For users with database experience, this is similar to an automatic outer
join on the index labels

'''

# s1 = pd.Series([7.3, -2.5, 3.4, 1.5], index=['a', 'c', 'd', 'e'])
# s2 = pd.Series([-2.1, 3.6, -1.5, 4, 3.1],index=['a', 'c', 'e', 'f', 'g'])

# print(s1)
# print()
# print(s2)
# print()
# print(s1+s2)

'''
In the case of DataFrame, alignment is performed on both the rows and the columns:
'''

# df1 = pd.DataFrame(np.arange(9.).reshape((3, 3)), columns=list('bcd'),index=['Ohio', 'Texas', 'Colorado'])
# df2 = pd.DataFrame(np.arange(12.).reshape((4, 3)), columns=list('bde'),index=['Utah', 'Ohio', 'Texas', 'Oregon'])

# print(df1)
# print()
# print(df2)
# print()
# print(df1+df2)

'''
Since the  'c' and  'e' columns are not found in both DataFrame objects, they appear
as all missing in the result. The same holds for the rows whose labels are not common
to both objects.
'''

'''
If you add DataFrame objects with no column or row labels in common, the result
will contain all nulls:
'''

# df1 = pd.DataFrame({'A': [1, 2]})
# df2 = pd.DataFrame({'B': [3, 4]})
# print(df1)
# print()
# print(df2)
# print()
# print(df1-df2)

# ---------------------------------------------------------------------------------------------------------

'''
Arithmetic methods with fill values
'''

'''
In arithmetic operations between differently indexed objects, you might want to fill
with a special value, like 0, when an axis label is found in one object but not the other:
'''

# df1 = pd.DataFrame(np.arange(12.).reshape((3,4)), columns=list("abcd"))
# df2 = pd.DataFrame(np.arange(20.).reshape((4,5)), columns=list("abcde"))
# print(df1)
# print()
# print(df2)
# print()
# data_segment = df2.loc[1, "b"] = np.nan   # does not create a copy, changes at original object itself
# print(data_segment)

# df2.loc[1, "b"] = np.nan
# print(df2)

'''
Adding these together results in NA values in the locations that don’t overlap
'''
# print(df1+df2)
# print(df2+df1)

'''
Using the  add method on  df1 , I pass  df2 and an argument to  fill_value 
'''

# new_df = df1.add(df2, fill_value=0)
# print(df1)
# print (df2)
# print(new_df)

# print(1/df1)
# print(df1.rdiv(1))

'''
Relatedly, when reindexing a Series or DataFrame, you can also specify a different fill
value:
'''

# new_df1 = df1.reindex(columns=df2.columns, fill_value=0)
# print(new_df1)

# --------------------------------------------------------------------------------------------------------

'''
Operations between DataFrame and Series

'''

'''
As with NumPy arrays of different dimensions, arithmetic between DataFrame and
Series is also defined. First, as a motivating example, consider the difference between
a two-dimensional array and one of its rows:
'''

# arr = np.arange(12.).reshape((3, 4))
# print(arr)
# print()
# print(arr[0])
# print()
# print(arr-arr[0])

'''
When we subtract  arr[0] from  arr , the subtraction is performed once for each row.
This is referred to as broadcasting
'''

# frame = pd.DataFrame(np.arange(12.).reshape((4, 3)),columns=list('bde'),index=['Utah', 'Ohio', 'Texas', 'Oregon'])
# print(frame)
# print()
# series = frame.iloc[0]
# print(series)

'''
By default, arithmetic between DataFrame and Series matches the index of the Series
on the DataFrame’s columns, broadcasting down the rows:
'''

# print(frame - series)
'''
delete the series from each row in frame
'''

'''
If an index value is not found in either the DataFrame’s columns or the Series’s index,
the objects will be reindexed to form the union:
'''

# series2 = pd.Series(range(3), index=['b', 'e', 'f'])
# print(frame+series2)

'''
If you want to instead broadcast over the columns, matching on the rows, you have to
use one of the arithmetic methods. 
'''

# series3 = frame['d']
# print(series3)
# print()
# new_frame = frame.sub(series3, axis='index')   # subtracting index wise
# print(new_frame)

# ---------------------------------------------------------------------------------------------------------------

'''
Function Application and Mapping
'''

'''
NumPy ufuncs (element-wise array methods) also work with pandas objects:
'''

# frame = pd.DataFrame(np.random.randn(4, 3), columns=list('bde'),index=['Utah', 'Ohio', 'Texas', 'Oregon'])
# print(frame)
# print()
# print(np.abs(frame))

'''
Another frequent operation is applying a function on one-dimensional arrays to each
column or row. DataFrame’s  apply method does exactly this:
'''

# f = lambda x: x.max() - x.min()
# new_frame = frame.apply(f)
# print(new_frame)
# print()

'''

Here the function  f , which computes the difference between the maximum and mini‐
mum of a Series, is invoked once on each column in  frame . The result is a Series hav‐
ing the columns of  frame as its index.
If you pass  axis='columns' to  apply , the function will be invoked once per row
instead:

'''

# new_frame2 = frame.apply(f, axis='columns')
# print(new_frame2)

# def f(x):
# 	return pd.Series([x.min(), x.max()], index=['min', 'max'])

# new_frame2 = frame.apply(f)
# print(new_frame2)

'''

Element-wise Python functions can be used, too. Suppose you wanted to compute a
formatted string from each floating-point value in  frame . You can do this with  apply
map 

'''
# df2.loc[1, "b"] = np.nan

# format = lambda x: '%.2f' % x
# new_frame = frame.applymap(format)
# print(new_frame)
# print()
# frame.loc["Utah"] = 1
# print(frame)
# df_num = frame.select_dtypes(include=[np.float])
# print(df_num)

# frame.at['Utah', 'b'] = 10
# print(frame)

# -------------------------------------------------------------------------------------------------------------------

'''
Sorting and Ranking

'''

'''
Sorting a dataset by some criterion is another important built-in operation. To sort
lexicographically by row or column index, use the  sort_index method, which returns
a new, sorted object:
'''

# obj = pd.Series(range(4), index=['d', 'a', 'b', 'c'])
# print(obj)
# print()
# obj_sorted = obj.sort_index()
# print(obj_sorted)

'''
With a DataFrame, you can sort by index on either axis:
'''

# frame = pd.DataFrame(np.arange(12).reshape((3, 4)),index=['three', 'one','two'],columns=['d', 'a', 'b', 'c'])
# print(frame)
# print()
# frame_sorted = frame.sort_index()
# print(frame_sorted)

# frame_sorted =frame.sort_index(axis=1)  #or "columns" 
# print(frame_sorted)

'''
The data is sorted in ascending order by default, but can be sorted in descending
order, too:
'''

# frame_sorted = frame.sort_index(axis=1, ascending=False)
# print(frame_sorted)

'''
To sort a Series by its values, use its  sort_values method:
'''
# obj = pd.Series([4, 7, -3, 2])
# print(obj)
# print()
# obj_sorted = obj.sort_values()
# print(obj_sorted)

'''
When sorting a DataFrame, you can use the data in one or more columns as the sort
keys. To do so, pass one or more column names to the  by option of  sort_values 
'''

# frame = pd.DataFrame({'b': [4, 7, -3, 2], 'a': [0, 1, 0, 1]})
# print(frame)
# print()
# frame_sorted = frame.sort_values(by="b")
# frame_sorted = frame.sort_values(by=['a', 'b'])
# print(frame_sorted)

'''
Ranking assigns ranks from one through the number of valid data points in an array.
The  rank methods for Series and DataFrame are the place to look; by default  rank
breaks ties by assigning each group the mean rank:
'''

# ---------------------------------------------
# obj = pd.Series([7, -5, 7, 4, 2, 0, 4])
# print(obj)
# print()
# obj_rank = obj.rank()
# print(obj_rank)
# ---------------------------------------------


# -----------------------------------------------------------------------------------------------------------

'''
Axis Indexes with Duplicate Labels
'''

'''
Up until now all of the examples we’ve looked at have had unique axis labels (index
values). While many pandas functions (like  reindex ) require that the labels be
unique,

'''

# obj = pd.Series(range(5), index=['a', 'a', 'b', 'b', 'c'])
# print(obj)

# print(obj.index.is_unique)
# print(obj["a"])

'''
The same logic extends to indexing rows in a DataFrame
'''

# df = pd.DataFrame(np.random.randn(4, 3), index=['a', 'a', 'b', 'b'])
# print(df)
# print()
# print(df.loc["b"])
# print(df.index.is_unique)

# ---------------------------------------------------------------------------------------------------------

'''
Summarizing and Computing Descriptive Statistics
'''

'''
pandas objects are equipped with a set of common mathematical and statistical meth‐
ods. Most of these fall into the category of reductions or summary statistics, methods
that extract a single value (like the sum or mean) from a Series or a Series of values
from the rows or columns of a DataFrame.
'''

# df = pd.DataFrame([[1.4, np.nan], [7.1, -4.5],[np.nan, np.nan], [0.75, -1.3]],index=['a', 'b', 'c', 'd'],columns=['one', 'two'])
# print(df)
# print()

'''
Calling DataFrame’s  sum method returns a Series containing column sums:
'''

# df_sum = df.sum()
# print(df_sum)

'''
Passing  axis='columns' or  axis=1 sums across the columns instead:
'''

# df_sum = df.sum(axis=1) #columns
# print(df_sum)

'''
NA values are excluded unless the entire slice (row or column in this case) is NA.
This can be disabled with the  skipna option:
'''
# df_mean= df.mean(axis='columns', skipna=False)
# print(df_mean)
# print()
# df_mean= df.mean(axis='columns', skipna=True)
# print(df_mean)

'''
Some methods, like  idxmin and  idxmax , return indirect statistics like the index value
where the minimum or maximum values are attained:
'''

# print(df.idxmax())
# print(df.idxmin())

# print(df.cumsum())

'''
Another type of method is neither a reduction nor an accumulation.  describe is one
such example, producing multiple summary statistics in one shot:
'''

# print(df.describe())

'''
On non-numeric data,  describe produces alternative summary statistics:
'''

# obj = pd.Series(['a', 'a', 'b', 'c'] * 4)
# print(obj)
# print()
# print(obj.describe())

'''
count ---Number of non-NA values
describe ---Compute set of summary statistics for Series or each DataFrame column
min, max ---Compute minimum and maximum values
argmin, argmax ---Compute index locations (integers) at which minimum or maximum value obtained, respectively
idxmin, idxmax ---Compute index labels at which minimum or maximum value obtained, respectively
quantile ---Compute sample quantile ranging from 0 to 1
sum ---Sum of values
mean ---Mean of values
median ---Arithmetic median (50% quantile) of values
mad--- Mean absolute deviation from mean value
prod--- Product of all values
var ---Sample variance of values
std ---Sample standard deviation of values
skew ---Sample skewness (third moment) of values
kurt ---Sample kurtosis (fourth moment) of values
cumsum ---Cumulative sum of values
cummin, cummax--- Cumulative minimum or maximum of values, respectively
cumprod ---Cumulative product of values
diff ---Compute first arithmetic difference (useful for time series)
pct_change ---Compute percent changes

'''





# *******************************************************************


# def print_series(n):
# 	l = []
# 	for i in range(1, n+1):
# 		series = str(n)*i
# 		l.append(str(series))
# 	new_series = " + ".join(l)
# 	print(new_series)

# print_series(5)

# n = 5
# series = [str(n) * i for i in range(1, n+1)]
# print(series)

# n= 5
# series =reduce(lambda x, y: "+".join(x), [str(n)*i for i in range(1, n+1)])


# series = '+'.join([str(n)*i for i in range(1, n+1)])
# print(series)

# n= 5
# new_series= ""
# for i in range(1, n+1):
# 	series = str(n) * i
# 	if i == 1:
# 		new_series = series
# 	else:
# 		new_series = new_series + "+" + series
# print(new_series)

# ********************************************************************