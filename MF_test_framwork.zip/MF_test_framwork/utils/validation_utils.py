from resource.config_details import data_paramters
from resource.json_util import json_utils

import pytest

api_methods = {
    "get":200,
    "post":201,
    "put":201,
    "delete":202,
    "unauthorized":401,
    "bad_request":400,
    "authentication":403
}

def create_data_object():
    json_obj = json_utils()
    return json_obj

def verify_status_code(method, actual_data):
    if method in api_methods:
        assert api_methods[method] == actual_data
    else:
        pytest.raises("ERROR!!! No such method available")

def verify_response(response,test,items=None, expected_data=None, limit=0):
    if items is None and expected_data is None:
        items = data_paramters[test]['items']
        expected_data = data_paramters[test]['expected_data']
    elif (items is None and expected_data is not None) or (items is not None and expected_data is None):
        pytest.raises("ERROR!!! Cannot compare None values")

    json_obj = create_data_object()
    actual_result_set = json_obj.json_parser(response, items, limit)
    assert actual_result_set == expected_data



