import requests
import os
import sys

dir_path = os.path.dirname(os.path.realpath(__file__))
os.chdir("..")
cwd = os.getcwd()
sys.path.insert(1, cwd)

class API_util:
    def __init__(self ):
        pass

    def status_code_and_response(self,response):
        status_code = response.status_code
        json_response = response.json()
        return status_code, json_response


    def get_api_create_order(self, URL,header, data):
        response = requests.get(URL, headers=header, params= data)
        status_code, json_response = self.status_code_and_response(response)
        return status_code, json_response

    def post_api_create_order(self, URL, header, data):
        response = requests.post(URL, data=data)
        status_code, json_response = self.status_code_and_response(response)
        return status_code, json_response

    def put_api_create_order(self, URL, header, data):
        response = requests.post(URL, data=data)
        status_code, json_response = self.status_code_and_response(response)
        return status_code, json_response

    def delete_api_create_order(self, URL, header, data):
        response = requests.post(URL, data=data)
        status_code, json_response = self.status_code_and_response(response)
        return status_code, json_response





if __name__ == "__main__":
    obj = API_util()
    obj.api_create_order()


