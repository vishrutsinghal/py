import requests
import responses
import pytest
import json
import os
import sys
from requests.exceptions import ConnectionError
from urllib.parse import urlparse

dir_path = os.path.dirname(os.path.realpath(__file__))
os.chdir("..")
cwd = os.getcwd()
sys.path.insert(1, cwd)

from resource.config_details import mock_create_order
from resource.response_json import orders

URL = mock_create_order['URL']

@responses.activate
def test_simulate_data_cannot_be_found():
    responses.add(
        responses.GET,
        URL,
        json=orders,
    )

    response = requests.get(URL)
    assert response.status_code == 404
    response_body = response.json()
    assert response_body['error'] == 'No data exists for US zip code 90210'


@responses.activate
def test_unmatched_endpoint_raises_connectionerror():
    with pytest.raises(ConnectionError):
        requests.get(URL+"/123")


@responses.activate
def test_responses_can_raise_error_on_demand():
    responses.add(
        responses.GET,
        URL,
        body=RuntimeError('A runtime error occurred')
    )

    with pytest.raises(RuntimeError) as re:
        requests.get(URL)
    assert str(re.value) == 'A runtime error occurred'


@responses.activate
def test_using_a_callback_for_dynamic_responses():

    def request_callback(request):
        request_url = request.url
        resp_body = {'value': generate_response_from(request_url)}
        return 200, {}, json.dumps(resp_body)

    responses.add_callback(
        responses.GET, URL,
        callback=request_callback,
        content_type='application/json',
    )

    response = requests.get(URL)
    assert response.json() == {'value': 'You requested data for US zip code 55555'}

    assert len(responses.calls) == 1
    assert responses.calls[0].request.url == URL
    assert responses.calls[0].response.text == '{"value": "You requested data for US zip code 55555"}'


def generate_response_from(url):
    parsed_url = urlparse(url).path
    split_url = parsed_url.split('/')
    return f'You requested data for {split_url[1].upper()} zip code {split_url[2]}'

