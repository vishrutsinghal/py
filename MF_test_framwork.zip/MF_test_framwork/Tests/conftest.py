
import os
import re
import sys

dir_path = os.path.dirname(os.path.realpath(__file__))
os.chdir("..")
cwd = os.getcwd()
# print(cwd)
sys.path.insert(1, cwd)


import pytest
from resource.config_details import data_paramters
from utils.api_utils import API_util
from resource.json_util import json_utils

def create_Object():
    api = API_util()
    return api

@pytest.fixture()
def define_api_util():
    def parameters(url,header,data):
        api = create_Object()
        api_call = api.get_api_create_order(URL = url, header = header, data = data)
        return api_call
    return parameters


@pytest.fixture()
def attributes(define_api_util):
    def values(parameter):
        URL=data_paramters[parameter]['URL']
        header=data_paramters[parameter]['header']
        params= data_paramters[parameter]['params']

        status_code, json_response =define_api_util(url = URL, header = header, data = params)

        return status_code, json_response
    return values
