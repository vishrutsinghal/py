import pytest
import os
import sys
from pprint import pprint

dir_path = os.path.dirname(os.path.realpath(__file__))
os.chdir("..")
cwd = os.getcwd()
sys.path.insert(1, cwd)

from utils.api_utils import API_util
from utils.validation_utils import verify_status_code, verify_response
from resource.config_details import data_paramters


def test_create_order_status_code(attributes):
    status_code, response = attributes('create_order')
    verify_status_code(method='get', actual_data=status_code)

def test_create_order_Response(attributes):
    status_code, response = attributes('create_order')
    response = response['orders']
    # items = ['orderId', 'postalCode']
    # expected = ['MF-062130', '13441-4516']
    verify_response(response,test='create_order')


def test_create_order_Response_2(attributes):
    status_code, response = attributes('create_order_limit')
    response = response['orders']
    # items = ['orderId']
    # expected = ['TO03-PK']
    verify_response(response,test='create_order_limit', limit=1)


