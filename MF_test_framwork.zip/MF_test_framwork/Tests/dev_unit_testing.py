import responses

@responses.activate
def test_simulate_data_cannot_be_found():
    responses.add(
        responses.GET,
        "http://api.dev_env/create_order/12345",
        json={"error": "No order exists"},
        status=404
    )
