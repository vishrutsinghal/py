data_paramters = {
    'create_order':{
        "URL": "https://uat.api.barrettdistribution.io/v1/orders",
        "header" : {'x-barrett-custom-api-token': 'edc2c339-a6f4-49c4-b940-36ce81358dff:003eafcf-45ec-4319-b46f-2d88879b51fc'},
        "params" : {'limit':2, 'page':1},
        "items":['orderId', 'postalCode'],
        "expected_data":['MF-062130', '13441-4516']
        },

    'create_order_limit':{
        "URL": "https://uat.api.barrettdistribution.io/v1/orders",
        "header" : {'x-barrett-custom-api-token': 'edc2c339-a6f4-49c4-b940-36ce81358dff:003eafcf-45ec-4319-b46f-2d88879b51fc'},
        "params" : {'limit':2, 'page':1},
        "items":['orderId', 'postalCode'],
        "expected_data":['MF-062128', '33810']
        }
}


# mock_create_order= {
#     "URL": "https://dev.api.barrettdistribution.io/v1/orders",
#     "header" : {'x-barrett-custom-api-token': 'edc2c339-a6f4-49c4-b940-36ce81358dff:003eafcf-45ec-4319-b46f-2d88879b51fc'},
#     "params" : {'limit':2, 'page':1}
# }


