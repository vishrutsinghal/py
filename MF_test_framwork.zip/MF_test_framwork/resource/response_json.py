orders=[
        {
            "orderId": "TO12",
            "purchaseOrder": "TPO01",
            "orderType": "outgoing",
            "orderStatus": "hold",
            "customerId": "1805",
            "fromFacility": "BRI",
            "dates": {
                "shipDateStart": "2021-07-30"
            },
            "transport": {
                "carrier": "FEDX",
                "service": "GRND",
                "terms": "COL",
                "type": "P"
            },
            "shipTo": {
                "contactName": "Barrett Distribution Center",
                "streetOne": "45 Scotland Blvd",
                "city": "Bridgewater",
                "state": "MA",
                "postalCode": "02324",
                "country": "USA"
            }
        }
    ]
