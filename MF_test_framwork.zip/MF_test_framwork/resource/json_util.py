from pprint import pprint

class json_utils:

    def __init__(self):
        self.new_reposnse= {}
        self.actual_result_list = []

    def flatten_response(self,response):
        self.actual_result_list = []
        for key, value in response.items():
            if isinstance(value, dict):
                self.flatten_response(value)
            else:
                self.new_reposnse[key] = value
        return self.new_reposnse


    def json_parser(self,response, args, limit=0):
        response = response[limit]
        response = self.flatten_response(response)
        try:
            for field in args:
                if field in response:
                    data= response[field]
                    self.actual_result_list.append(data)
            return self.actual_result_list
        except KeyError:
            print(f'Key {field}  not found in response, check for spelling and char case')
            return None

