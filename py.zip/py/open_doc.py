import os
import re
import win32api
import threading

class advance_search():
	drive_list = []

	for drive in win32api.GetLogicalDriveStrings().split("\000")[:-1]:
			drive_list.append(drive)

	def __init__(self,thread_count):
		self.thr= []
		for _ in range(thread_count):
			t= threading.Thread(target = self.find_drives("robot framewotk errors"))
			t.daemon = True
			t.start()
			self.thr.append(t)


	def join (self):
		for th in self.thr:
			th.join()

	def find_drives(self, file_name):
		# for drive in win32api.GetLogicalDriveStrings().split("\000")[:-1]:
		# 	drive_list.append(drive)
		rex = re.compile(file_name)
		while len(drive_list):
			drive = drive_list.pop(0)
			print ("drive is : ", drive)
			self.find_file(drive, rex)

	def find_file(self, root_folder, rex):
		for root, dirs, files in os.walk(root_folder):
			for f in files:
				result = rex.search(f)
				if result:
					self.read_data = os.path.join(root, f)
					print (self.read_data)


if __name__ == '__main__':
	advance_search(2).join()

