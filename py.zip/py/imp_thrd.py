



import threading
import advance_search as ass


global TH


# for i in path_list:
# 	a = subprocess.run(['notepad.exe', i])



# work the whole list as fast as possilble
# def work():
# 	while len(path_list):
# 		elem = path_list.pop(0)
# 		subprocess.run(["notepad.exe", elem])
# 		print ("paths are : ", elem)
# 		print (threading.current_thread().name, elem)	



class Runner:
    def __init__(self,thread_count):
        self.thr = []
        for _ in range(thread_count):
            t = threading.Thread(target = ass.find_drives("robot framewotk errors"))
            t.daemon  = True
            t.start()
            self.thr.append( t )

    def join(self):
        for th in self.thr:
            th.join()

if __name__ == '__main__':
    Runner(4).join()
