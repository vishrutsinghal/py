import subprocess




import threading

# p = [11,22,33,44,55,66,77,88,99,111,222,333,444,555,666,777,888,999,1111,22222,44444,566666,877889528]

global TH
# a = subprocess.run(['notepad.exe', ])
# b = subprocess.run(['notepad.exe', ])

path_list = [ "C:\\Users\\vsinghal2\\Desktop\\robot\\robot framewotk errors.txt",
			"C:\\Users\\vsinghal2\\Desktop\\TELUS framework\\robot framewotk.txt"]

# for i in path_list:
# 	a = subprocess.run(['notepad.exe', i])



# work the whole list as fast as possilble
def work():
	while len(path_list):
		elem = path_list.pop(0)
		subprocess.run(["notepad.exe", elem])
		print ("paths are : ", elem)
		print (threading.current_thread().name, elem)	



class Runner:
    def __init__(self,thread_count):
        self.thr = []
        for _ in range(thread_count):
            t = threading.Thread(target = work)
            t.daemon  = True
            t.start()
            self.thr.append( t )

    def join(self):
        for th in self.thr:
            th.join()

if __name__ == '__main__':
    Runner(4).join()