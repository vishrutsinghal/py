import os
import re
import win32api
import threading

class advance_search():



	def find_drives(self, file_name):
		drive_list=[]
		for drive in win32api.GetLogicalDriveStrings().split("\000")[:-1]:
			drive_list.append(drive)

		rex = re.compile(file_name)
		while len(drive_list):
			drive = drive_list.pop(0)
			print ("drive is : ", drive)
			self.find_file(drive, rex)

	def find_file(self, root_folder, rex):
		for root, dirs, files in os.walk(root_folder):
			for f in files:
				result = rex.search(f)
				if result:
					self.read_data = os.path.join(root, f)
					print (self.read_data)


