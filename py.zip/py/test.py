import extra_py as ep
from extra_py import advance_search

t= advance_search.find_drives("ddd", "ff")