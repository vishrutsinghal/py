
exports.config = {
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['TestSpec.js']
  capabilities: {
	    browserName: 'chrome'
	  capabilities: browserCapabilities.returnCapabilities(browserToUse, platform, divideTests, maxBrowserInstances)
	   
	  }
	  	localSeleniumStandaloneOpts: {
		jvmArgs: [
			"-Dwebdriver.gecko.driver=node_modules/protractor/node_modules/webdriver-manager/selenium/geckodriver-v0.19.1.exe",
			"-Dwebdriver.ie.driver=node_modules/protractor/node_modules/webdriver-manager/selenium/IEDriverServer3.4.0.exe",
			"-Dwebdriver.chrome.driver=node_modules/protractor/node_modules/webdriver-manager/selenium/chromedriver_2.33.exe",
			"-Dwebdriver.edge.driver=node_modules/protractor/node_modules/webdriver-manager/selenium/MicrosoftWebDriver.exe"
		]
	},

  
  
  
};

first to run
webdriver-manager update --ie32 --versions.standalone=3.4.0 --versions.ie=3.4.0

after that 
webdriver-manager start --versions.standalone=3.4.0