
module.exports = {
	chrome: function(platform,shardTestFiles,maxInstances) {
			return {
					browserName: 'chrome',
					shardTestFiles: shardTestFiles,
					maxInstances: maxInstances,
					chromeOptions: {
									args: ['--start-maximized'],
									prefs: {
										download: {
										  'prompt_for_download': false,
										  'directory_upgrade': true,
										  'default_directory': downloadloc
												   }
											  }
					}
			}
	},
	'internet explorer': function(platform,shardTestFiles,maxInstances) {
			return {
					browserName: 'internet explorer',
					shardTestFiles: shardTestFiles,
					maxInstances: maxInstances,
					version: '11',
					ignoreProtectedModeSettings: true
				}
	},
	firefox: function(platform,shardTestFiles,maxInstances) {
			return {
					browserName: 'firefox',
					shardTestFiles: shardTestFiles,
					maxInstances: maxInstances,
			       }
	},
	safari: function(platform,shardTestFiles,maxInstances) {
			return {
					browserName: 'safari',
					shardTestFiles: shardTestFiles,
					maxInstances: maxInstances,
			       }
	},
	returnCapabilities: function(browserName,platform,shardTestFilesEnabled,maxInstances) {
			return this[browserName](platform,shardTestFilesEnabled,maxInstances)
	}
}