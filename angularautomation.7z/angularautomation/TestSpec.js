describe ('This is to launch test on IE', function(){
beforeEach(function(){
console.log("Launch the IE browser");

});
afterEach(function(){
console.log("Test Ends");

})

it('First Test' function(){
browser.get("https://angularjs.org");
console.log("test launched on IE");
});
});