import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchDriver 
{
	
	public static WebDriver driver = null;
	public static List<String> locators = new ArrayList<String>();
	public static List<String> Tagnames = new ArrayList<String>();
	 
	
	//launches the driver 
	public  WebDriver driverLauncher()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rray\\Desktop\\drivers_new\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com");
        return driver;
	}
	public WebDriver navigateToOtherPage()
	{
		//WebDriver driver_new= driverLauncher();
		driver.findElement(By.xpath("//a[text()='Privacy']")).click();
		System.out.println(driver.getCurrentUrl());

		return driver;
		
	}

}
