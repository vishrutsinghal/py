import re
import boto3
from pyspark import sql
import s3fs
import pandas as pd
# from pyarrow import csv
import pyarrow.parquet as pq
from pyspark import SparkContext
from pyspark.sql import SQLContext
from functools import partialmethod, reduce
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import FloatType
from pprint import pprint
from pyspark.sql import *
import pyspark
import os
import csv
import sys

# initialise sparkContext
from pyspark.sql.functions import lit, count, col, shiftRight, when
from pyspark.sql import SQLContext



# cwd = os.getcwd() 
# # print(cwd)
# sys.path.insert(1, cwd)




fs=s3fs.S3FileSystem()

s3 = boto3.resource('s3')
class aws_extractor:
    
    def __init__(self,AWS_ACCESS_KEY,AWS_SECRET_KEY):
        dir_path = os.path.dirname(os.path.realpath(__file__)) 
        os.chdir(".") 
        os.getcwd()
        
        self.save_file_path = os.getcwd()
        print("self.save file: ", self.save_file_path)

        self.file_list = []
        self.AWS_ACCESS_KEY = AWS_ACCESS_KEY
        self.AWS_SECRET_KEY = AWS_SECRET_KEY

    def _spark_config(self):
        spark = SparkSession.builder \
        .master('local') \
        .appName('myAppName') \
        .config('spark.executor.memory', '5gb') \
        .config("spark.cores.max", "8") \
        .getOrCreate()

        sc = spark.sparkContext

        sqlContext = SQLContext(sc)
        sqlContext.setConf("spark.default.parallelism", "300")

    def get_files(self, bucket, path):
        '''
        Arguments 
            bucket : Bucket is usually the very first folder that we create
            path   : Path is to the file or directory you want to perform operation in S3

        Functionality: get file will take bucket and path as arguments and it will parse
                    all folder to n depth and displayes on console
        Usage:
            <class_obj>.get_files(bucket=BUCKET, path=PATH)
        '''
        self.list_files =[]
        my_bucket = s3.Bucket(bucket)
        bucket_uri=f's3a://{my_bucket}/{path}'
        print(bucket_uri)
        for object_summary in my_bucket.objects.filter(Prefix=path):
            self.file_list.append(object_summary.key)
            print("FILES!! ", object_summary.key)
        return self.file_list

    def _read_file_format(self,query, file_format, bucket_uri,sqlContext,output_file=None,file_object=None):
        if file_format == 'parquet':
            try:
                df = sqlContext.read.parquet(bucket_uri)
                df.createOrReplaceTempView('mytable')
                parq_data = sqlContext.sql(query)
                print("QUERY ", query)
                print("Query Result: ")
                parq_data.show(truncate = False)

                if output_file:
                    try:                           
                        print("Preparing Output file:", output_file)     
                        output_file = self.save_file_path+"\\Resources\\"+output_file
                        print("OUTPUT File location: ", output_file)  
                        # print("OUTPUT File location inside TSV: ", output_file) 
                        if not file_object:
                            df.toPandas().to_csv(output_file, index=False)
                        else:
                            pass
                        # if file_object:
                        #     print("inside file object ", file_object)
                        #     # with open (output_file, "w") as file_object:
                        #     #     file_object.write.csv(parq_data)
                        #     return parq_data
                        # else:
                        #     with open (output_file, "w") as f: 
                        #         f.write.csv(parq_data)
                        # parq_data.write.csv(output_file)
                        return parq_data
                    except:
                        print("ERROR!!! File can not be created")
                        return
                else:
                    return parq_data
            except pyspark.sql.utils.AnalysisException:
                print("ERROR!!! Table must be mytable")
                return

        if file_format == 'csv': 
            try:
                df = sqlContext.read.csv(bucket_uri)
                df.createOrReplaceTempView('mytable')
                parq_data = sqlContext.sql(query).cache()
                print("Query Result: ")
                parq_data.show(truncate = False)

                if output_file:
                    try:                           
                        print("Preparing Output file")     
                        output_file = self.save_file_path+"\\Resources\\"+output_file
                        print("OUTPUT File location: ", output_file)  
                        df.toPandas().to_csv(output_file, index=False)
                        # if file_object:
                        #     with open (output_file, "w") as file_object:
                        #         file_object.write.csv(parq_data)
                        # else:
                        #     with open (output_file, "w") as f: 
                        #         f.write.csv(parq_data)
                        # parq_data.write.csv(output_file)
                        return parq_data
                    except:
                        print("ERROR!!! File can not be created")
                        return None
                else:
                    return parq_data.cache()
            except pyspark.sql.utils.AnalysisException:
                print("ERROR!!! Table must be mytable")
                return 

        if file_format == 'tsv':
            try:
                df = sqlContext.read.csv(bucket_uri, header=True, inferSchema= True, sep='\t')
                df.createOrReplaceTempView('mytable')
                parq_data = sqlContext.sql(query).cache()
                print("Query Result: ")
                parq_data.show(truncate = False)

                if output_file:
                    # try:           
                    print("Preparing Output file")     
                    output_file = self.save_file_path+"\\Resources\\"+output_file
                    print("OUTPUT File location inside TSV: ", output_file) 
                    df.toPandas().to_csv(output_file, index=False) 
                    # if file_object:
                    #     with open (output_file, "w") as file_object:
                    #         file_object.write.csv(parq_data)
                    # else:
                    #     print("Inside else")
                    #     # parq_data.repartition(1).write.format('com.databricks.spark.csv').save(output_file,header = 'true')
                    #     df.toPandas().to_csv(output_file, index=False)

                    # parq_data.write.csv(output_file)
                    return parq_data
                    # except:
                    #     print("ERROR!!! File can not be created")
                    #     return None
                else:
                    return parq_data.cache()
            except pyspark.sql.utils.AnalysisException:
                print("ERROR!!! Table must be mytable")
                return 
        # return parq_data

    def _read_recursive(self, bucket,query,file_format, file_folder, output_file, sqlContext):
        # file_folder = self.get_files()
        series_list = []
        output_file1 = self.save_file_path+"\\Resources\\"+output_file
        print("OUTPUT File location: ", output_file1)
        # with open (output_file1, "a") as file_object:
        if isinstance(file_folder, str):
            print("SQLCONTEXT ", sqlContext)
            print("PROCESSING!!! file ", file_folder)
            bucket_uri=f's3a://{bucket}/{file_folder}'
            # extension = file.endswith(fileformat)
            parq_data= self._read_file_format(query=query,file_format= file_format,bucket_uri= bucket_uri,output_file=output_file,sqlContext=sqlContext,file_object=False)
            return parq_data
        else:
            for file in file_folder:
                print("PROCESSING!!! file ", file)
                bucket_uri=f's3a://{bucket}/{file}'
                # extension = file.endswith(fileformat)
                
                parq_data= self._read_file_format(query=query, file_format=file_format, bucket_uri=bucket_uri,output_file=output_file,sqlContext=sqlContext,file_object=True)
                # data = parq_data.toPandas()
                # pd.concat([data], axis=1).to_csv(file_object, header=False, index=False)
                series_list.append(parq_data)
            print("SERIES_LIST: ", series_list)
            df_series = reduce(DataFrame.unionAll, series_list)
            df_series.show()
            if 'count' in query:
                sqlContext.registerDataFrameAsTable(df_series, "mytable")

                df_series = sqlContext.sql(query)
                df_series.show()
            # print("df_series ", df_series)
            # output_file2 = self.save_file_path+"\\Resources\\"+output_file
            # df_series.write.csv(output_file1)
            df_series.toPandas().to_csv(output_file1, index=False)
            print("SUCCESS!!! File created successfully")
            return df_series
        
    def read_file(self,bucket, path,filename=None, output_file =None, file_format = None,query=None, data_compare=False, recursive=False):
        '''
        Arguments:
            bucket      : Bucket is usually the very first folder that we create
            path        : Path is to the file or directory you want to perform operation
            filename    : Filename is required if need to read any specific file when using recursive = True
                          filename should be set as default value i.e None
            output_file : Output file is required when file needs to saved to locally after reading from s3
            file_format : In case of folder containes multiple files with different format this parameter
                          will help filtering them
            recursive   : To read files in recursively put recursive as True.

        Functionality   : read_file provides the feature to read files from different file formats like
                          parquet, tsv, csv. 
                        : With this there is an option to read files recursively(nested folders)
                        : There is an option to save files that you have read in any file format
                        : When read recursively it can concat the files data and sump to single output_file

        Usage:
            without recurssion:
                <class_obj>.read_file(bucket=BUCKET, path=PATH, filename=FILENAME)
            with recursion and output file:
                <class_obj>.read_file(bucket=BUCKET, path=PATH,output_file=OUTPUT_FILE, file_format=FILE_FORMAT,recursive=TRUE)
        '''
        if query is None:
            query = "select * from mytable"
        files = self.get_files(bucket, path)
        files = files[1:]
        file_folder = []
        for file in files:
            if file.endswith(file_format):
                file_folder.append(file)

        conf = (
            pyspark.SparkConf()
            .setAppName('app_name')
            .setMaster("local[*]")
            .set('spark.hadoop.fs.s3a.access.key', self.AWS_ACCESS_KEY)
            .set('spark.hadoop.fs.s3a.secret.key', self.AWS_SECRET_KEY)
            )

        # sc = pyspark.SparkContext(conf=conf)
        # sc= SparkContext.getOrCreate(conf=conf)
        # sqlContext = SQLContext(sc)
        sc = pyspark.SparkContext
        spark_current_session = SparkSession. \
                             builder. \
                             appName('APP'). \
                             config(conf=conf). \
                             getOrCreate()
        sqlContext = SQLContext(spark_current_session)

        if data_compare:
            if not recursive:
                if not isinstance(filename, list):
                    if len(filename) != 2:
                        raise Exception("ERROR!!! filename paramter must be a list containing 2 files names only")
                else:
                    dataframe_list = []
                    for file in filename:
                        print("file ", file)
                        file = path+file
                        df = self._read_recursive(bucket = bucket,query= query, file_format=file_format,file_folder= file, output_file = output_file, sqlContext= sqlContext)
                        dataframe_list.append(df)
                    self.data_comparitor(dataframe_list=dataframe_list)
            else:
                raise Exception("ERROR!!! data_compare and recursive cant be True at same time")

        else:
            print("VALIDATING!!! validating folder structure, it will fail if there is nested folder structure")
            if recursive is False:
                if not filename.endswith('.parquet') and not filename.endswith('.csv') and not filename.endswith('.tsv') and not filename.endswith('.txt'):
                    print("WARNING!!! It got nested folder structure or Invalid filename check for spaces")
                    return

                if filename:
                    for file in file_folder:
                        file_check = file.split("/")[-1]
                        # file = path+file
                        print("file_check ", file_check)
                        
                        if filename == file_check:
                            bucket_uri=f's3a://{bucket}/{file}'
                            print("Bucket_URI-----: ", bucket_uri)
                            parq_data =self._read_file_format(query=query, file_format=file_format,bucket_uri= bucket_uri, sqlContext=sqlContext, output_file=output_file)
                            print("Checking in aws utils ", parq_data)
                            # spark_current_session.stop()
                            # spark_current_session.newSession()
                            return parq_data

            elif recursive == True and file_format and output_file:
                # print("FILEFORMAT: ", file_folder)
                parq_data = self._read_recursive(bucket=bucket,query=query,file_format=file_format, file_folder=file_folder, output_file=output_file,sqlContext=sqlContext)
                return parq_data
            else:
                print("ERROR!!! Wrong input paramter ")
                return None

            

    def data_comparitor(self,dataframe_list):
        source, destination =  dataframe_list
        print("DF COMPARE!!! Data frame comparision started")

        source_df_header = source.columns
        destination_df_header= destination.columns
        if source_df_header != destination_df_header:
            raise Exception("ERROR!!! Source and destination columns do not match or in wrong order")
        source_df2 = source.withColumn('FLAG',lit('source'))
        destination_df2 = destination.withColumn('FLAG',lit('destination'))

        df = source_df2.union(destination_df2)

        my_window = Window.partitionBy(source_df_header).rowsBetween(-sys.maxsize, sys.maxsize)

        df = df.withColumn('FLAG', when((count('*').over(my_window) > 1),'SAME').otherwise(col('FLAG'))).dropDuplicates()
        df.show()

        csv_file_name = 'DF_CMP_RESULT.csv'

        df = df[df['FLAG']!='SAME']
        df.toPandas().to_csv(csv_file_name, index=False)

        print('ENDED:!! Data Frame comaprision done')


                
    def _create_folder(self, path):
      path_arr = path.rstrip("/").split("/")
      print(path_arr)

      parent = path_arr[0]
      bucket = s3.Bucket(parent)
      status = bucket.put_object(Key="/".join(path_arr[1:]) + "/")
      print(status)

    def _insert_files(self,bucket, local_path, aws_path, full_path,file_path=None):
        bucket_uri=f'{bucket}/{aws_path}'
        path_arr = bucket_uri.rstrip("/").split("/")
        print(path_arr)
        parent = path_arr[0]
        bucket_2 = s3.Bucket(bucket)
        if full_path is None:
            full_path = local_path+'//'+file_path
            key = "/".join(path_arr[1:]) + "/" +file_path
        else:
            key="/".join(path_arr[1:]) + "/" +full_path[len(local_path)+1:]
            key = key.replace("\\", "/")
        with open(full_path, 'rb') as data:         
            print(key)
            bucket_2.put_object(Key=key, Body= data)
            print("SUCCESS!!! File uploaded succesfully")

    def upload_files(self,bucket, local_path, aws_path,file_path=None, recursive=False):

        '''
        Arguments:
            bucket      : Bucket is usually the very first folder that we create
            local_path  : With this local path to file/folders can be set that needed to be uploaded
                        : Local path must be set to parent path such as it has all the file needed to be uploaded
            aws_path    : To set destination path (aws s3 path)
            file_path   : To upload file as single entity or to upload file in list(to upload selected files in single go)
                        : It can be path from local_path set to file path
            recursive   : To read files in recursively put recursive as True.

        Functionality   : upload_files provides the feature to upload files with nay file format
                        : With this there is an option to upload file recursively that will upload
                          files in same folder structure as in local setup

        Usage:
            without recurssion:
                <class_obj>.upload_files(bucket=BUCKET, local_path=LOCAL_PATH, aws_path=AWS_PATH, file_path=FILE_PATH)
            with recursion and output file:
                <class_obj>.upload_file(bucket=BUCKET, local_path=LOCAL_PATH, aws_path=AWS_PATH, file_path=FILE_PATH,recursive=TRUE)
        '''
        if not recursive:
            try:
                if isinstance(file_path, list):
                
                    for path in file_path:
                         self._insert_files(bucket=bucket, aws_path=aws_path, local_path=local_path, full_path=None, file_path=path)
                else:
                    self._insert_files(bucket=bucket, aws_path=aws_path, local_path=local_path, full_path =None,file_path=file_path)
            except FileNotFoundError:
                print("Can not find file location ", local_path)
        if recursive and isinstance(local_path, str):
            for root, dirs, files in os.walk(local_path):
               for file in files:
                    full_path = os.path.join(root, file)
                    self._insert_files(bucket=bucket, aws_path=aws_path, local_path=local_path, full_path=full_path)

    def _delete(self, bucket, path):
        file_list = self.get_files(bucket, path)
        for file in file_list:
            new_bucket_uri=f's3a://{bucket}/{file}'
            fs.rm(new_bucket_uri)
            print("DELETED!!! ", file)

    def delete_files(self,bucket, path, filename=None, recursive=False):
        '''
        Arguments:
            bucket      : Bucket is usually the very first folder that we create
            path        : Path is to the file or directory you want to perform operation in S3    
                        : Local path must be set to parent path such as it has all the file needed to be uploaded
            file_name   : To delete any sepecific file give s3 filename
            recursive   : To read files in recursively put recursive as True.

        Functionality   : deleting single specific file and recursively

        Usage:
            without recurssion:
                <class_obj>.delete_files(bucket=BUCKET,path=PATH, file_name=FILE_NAME)
            with recursion and output file:
                <class_obj>.delete_file(bucket=BUCKET,path=PATH, recursive=TRUE)
        '''
        if not filename and recursive is True:
            raw = input("WARNING!!! File name not provided it will delete all files continue ?Y/N ")
            if raw.lower() == 'y':
                self._delete(bucket, path)
                return
            elif raw.lower() == 'n':
                raise Exception("EXITING")
        else:
            bucket_uri=f's3a://{bucket}/{filename}'

        print(bucket_uri)
    
        # fs.rm(bucket_uri)

        file_list = self.get_files(bucket, path)
        index = 0
        try:
            if len(file_list) == 1:
                raise Exception("WARNING!!! No file found on this location")
            while len(file_list):
                # print("DATA " ,file_list[index])
                if filename not in file_list[index]:
                    index= index+1
                elif filename in file_list[index]:
                    fs.rm(bucket_uri)
                    print("DELETED!!! Files successfully deleted")
                    # _ = self.get_files(bucket, path)
                    return

        except Exception:
            print("ERROR!!! Check path and file name")

    def download_file(self, bucket, path,local_path=None, recursive=False):
        '''
        Arguments:
            bucket      : Bucket is usually the very first folder that we create
            path        : Path is to the file or directory you want to perform operation in S3    
            local_path  : Set path to local directory to store download fils
            recursive   : To read files in recursively put recursive as True.

        Functionality   : downloading single specific file and recursively

        Usage:
            without recurssion:
                <class_obj>.download_files(bucket=BUCKET,path=PATH, local_path=LOCAL_PATH)
            with recursion and output file:
                <class_obj>.download_file(bucket=BUCKET,path=PATH,local_path=LOCAL_PATH, recursive=TRUE)
        '''
        my_bucket = s3.Bucket(bucket)
        if not recursive:
            print("not recurssive")
            for s3_object in my_bucket.objects.all():
                filename = s3_object.key
                my_bucket.download_file(s3_object.key, path, local_path)
                print("SUCCESS!!! File downloaded successfully")
        elif recursive:
            objects = my_bucket.objects.filter(Prefix=path)
            for obj in objects:
                path, filename = os.path.split(obj.key)
                print(obj.key)
                if filename:     
                    local = local_path+'\\'+filename       
                    if local_path:
                        my_bucket.download_file(Key=obj.key,Filename= local)
                    else:
                        my_bucket.download_file(Key=obj.key)

            print("SUCCESS!!! Files downloaded successfully")
    
    def demo(self, bucket, path, test=True):
        print(test)
        conf = (
            pyspark.SparkConf()
            .setAppName('app_name')
            .setMaster("local[*]")
            .set('spark.hadoop.fs.s3a.access.key', self.AWS_ACCESS_KEY)
            .set('spark.hadoop.fs.s3a.secret.key', self.AWS_SECRET_KEY)
            )

        sc = pyspark.SparkContext(conf=conf)
        sqlContext = SQLContext(sc)
        return "hello return"


if __name__ =="__main__":
    AWS_ACCESS_KEY = "AKIA5IGIQDKSMJ6QU2XZ"
    AWS_SECRET_KEY = "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"

    BUCKET = 'analytics-chc-dev-analytics-cloud'
    # PATH = 'analyticsdataoperators/QA_filter_data/hqxdataoperatortest/output/raw/outputepisodedetail'
    # PATH = 'analyticsdataoperators/QA_filter_data/dummy_data'
    # PATH = 'QA_config_test/analyticsdataoperators/QA_filter_data/dummy_data/'
    PATH = 'QA_config_test/o2/'
    # PATH =  'analyticsdataoperators/hqxdataoperator/input/raw/member'

    # FILENAME ='analyticsdataoperators/QA_filter_data/dummy_data/part-00000-66285a3c-214e-4647-8003-2a1cb3d1ebab-c000.snappy.parquet'
    # FILENAME = ['sample2.csv','sample.csv']
    FILENAME = 'sample2.csv'

    # FILENAME = 'sample.snappy.parquet'
    # FILENAME ='associations-1.tsv'
    # FILENAME= 'analyticsdataoperators/QA_filter_data/dummy_data/sample.csv'
    # FILENAME= r'test101\test2.txt'
    filepath = 'analyticsdataoperators/QA_filter_data/hqxdataoperatortest/input'
    # s3://analytics-chc-dev-analytics-cloud/analyticsdataoperators/QA_filter_data/hqxdataoperatortest/output/raw/outputepisodedetail/part-00000-73463e7c-e14e-485d-a346-1aed79e85520-c000.snappy.parquet
    # FILENAME='part-00000-66285a3c-214e-4647-8003-2a1cb3d1ebab-c000.snappy.parquet'
    local_path = 'C:\\Users\\Vishrut.Singhal\\Documents\\cloud_data'

    obj = aws_extractor(AWS_ACCESS_KEY,AWS_SECRET_KEY)
    # obj.download_file(bucket=BUCKET, path=PATH, local_path=local_path, recursive=True)
    # obj.list_files()
    # FILE = 'associations-0.csv'
    # FILE = 'test2.parquet'
    # obj.delete_files(BUCKET, PATH,FILENAME)
    # obj.get_files(BUCKET,PATH)
    # query = "select * from mytable"
    PATH = "analyticsdataoperators/hqxdataoperator/output/raw/member"
    FILENAME = 'part-00000-1acdea6d-1e3f-4b4c-b6d9-0aa0cf06ab69-c000.snappy.parquet'
    query = "select * from mytable"

    obj.read_file(bucket= BUCKET,path =PATH,filename=None, file_format = 'parquet', recursive=True,output_file="test_parquet.csv", query=query )

    # data = obj.read_file(bucket= BUCKET,path =PATH, file_format = 'csv',output_file="test_csv.csv", recursive=True)
    # print("DATA")
    # data.show()
    # obj.read_file(bucket= BUCKET,path =PATH,filename=FILENAME, file_format = 'parquet', recursive=False, output_file="test.csv" )
    # obj.read_file( format = 'parquet', recursive=True,output_file="output_file.csv" )


    # For testing upload_files
    PATH = "analyticsdataoperators/hqxdataoperator/config/raw/"
    local_path ='C:\\Users\\Vishrut.Singhal\\Documents\\config_json'
    # file_path = ["member.json"]
    # file_path = 'test100'
    # file_path = ['sample2.csv']
    # PATH =  'analyticsdataoperators/hqxdataoperator/config/raw'
    # # PATH = PATH+"/
    # obj.upload_files(bucket=BUCKET, aws_path= PATH, local_path=local_path, file_path=None, recursive=True)
    # obj.get_files(bucket=BUCKET, path= PATH)
    
    # PATH = "analyticsdataoperators/hqxdataoperator/input/raw/"
    # obj.download_file(bucket=BUCKET, path=PATH, local_path=local_path, recursive=True)


