'''
This file contains the parameter for AWS 
'''


data_paramters = {
    "member" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperator/input/raw/member",
            "FILENAME":'QA_MEMBER_01.tsv',
            "FILE_FORMAT" :'tsv',
            "OUTPUT_FILE":"member_result.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False,
            "LOCAL_PATH":"C:\\Users\\Vishrut.Singhal\\Documents\\config_json\\raw_data\\QA_MEMBER_01.tsv"
    },

    "enroll" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperator/input/raw/enrollment",
            "FILENAME":'QA_enroll_01.tsv',
            "FILE_FORMAT" :'tsv',
            "OUTPUT_FILE":"enroll_result.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False
    },

    "rxclaim" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperator/input/raw/rxClaim",
            "FILENAME":'QA_rxclaim_01.tsv',
            "FILE_FORMAT" :'tsv',
            "OUTPUT_FILE":"rxclaim_result.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False
    }
}


