
import re
from utils.windows_utils import windows_extractor
import boto3
from pyspark import sql
import s3fs
import pandas as pd
# from pyarrow import csv
import pyarrow.parquet as pq
from pyspark import SparkContext
from pyspark.sql import SQLContext
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import FloatType
from pprint import pprint
from pyspark.sql import *
import pyspark
import os
import csv
import sys

# initialise sparkContext
from pyspark.sql.functions import lit, count, col, shiftRight, when
from pyspark.sql import SQLContext

def make_compare(aws_df, windows_df):

    spark = SparkSession.builder \
    .master('local') \
    .appName('myAppName') \
    .config('spark.executor.memory', '5gb') \
    .config("spark.cores.max", "6") \
    .getOrCreate()

    sc = spark.sparkContext

    # using SQLContext to read parquet file

    from pyspark.sql import SQLContext

    sqlContext = SQLContext(sc)
    spark.newSession()

    print("DF COMPARE!!! Data frame comparision started")

    source_df_header = aws_df.columns
    destination_df_header= windows_df.columns
    if source_df_header != destination_df_header:
        raise Exception("ERROR!!! Source and destination columns do not match or in wrong order")
    source_df2 = aws_df.withColumn('FLAG',lit('source'))
    destination_df2 = windows_df.withColumn('FLAG',lit('destination'))

    df = source_df2.union(destination_df2)

    my_window = Window.partitionBy(source_df_header).rowsBetween(-sys.maxsize, sys.maxsize)

    df = df.withColumn('FLAG', when((count('*').over(my_window) > 1),'SAME').otherwise(col('FLAG'))).dropDuplicates()
    print("files dne ")
    print("DF: ",df)
    df.show()

    csv_file_name = 'DF_CMP_RESULT.csv'

    df = df[df['FLAG']!='SAME']
    df.toPandas().to_csv(csv_file_name, index=False)
    print('ENDED:!! Data Frame comaprision done')
    if df.rdd.isEmpty():
        return True
    else:
        return False
