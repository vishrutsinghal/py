import re
import boto3
from pyspark import sql
import s3fs
import pandas as pd
# from pyarrow import csv
import pyarrow.parquet as pq
from pyspark import SparkContext
from pyspark.sql import SQLContext
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import FloatType
from pprint import pprint
from pyspark.sql import *
import pyspark
import os
import csv
import sys

# initialise sparkContext
from pyspark.sql.functions import lit, count, col, shiftRight, when
from pyspark.sql import SQLContext



class windows_extractor:
    def __init__(self):
        pass

    def wread_file(self, path, schema, query=None):
        if query is None:
            query = "select * from mytable"

        # print("reading windows file")

        spark = SparkSession.builder \
        .master('local') \
        .appName('myAppName') \
        .config('spark.executor.memory', '5gb') \
        .config("spark.cores.max", "8") \
        .getOrCreate()

        sc = spark.sparkContext

        sqlContext = SQLContext(sc)
        sqlContext.setConf("spark.default.parallelism", "300")
        spark.newSession()
        
        try:
        # windows_df = spark.read.csv(path, header=True, inferSchema= True, sep=',')
            windows_df = (spark.read.format("csv") \
            .option("inferSchema", "true") \
            .schema(schema) \
            .load(path))

            print("reading windows file")
            print(type(windows_df))

            windows_df.createOrReplaceTempView("mytable")
            print("reading windows file")
            source_df2 = sqlContext.sql(query).cache()
            print("Showing windows result ",path)
            source_df2.show()   
        # spark.stop()
            return source_df2
        except pyspark.sql.utils.AnalysisException:
                print("ERROR!!! Table must be mytable")
                return 


if __name__ =="__main__":
    obj = windows_extractor()
    PATH = 'C:\\Users\\Vishrut.Singhal\\Documents\\config_json\\raw_data\\QA_MEMBER_01.tsv'
    obj.wread_file(path=PATH)