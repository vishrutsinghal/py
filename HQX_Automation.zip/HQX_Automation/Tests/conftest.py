
import os
import re 
import sys
from py4j.java_gateway import OutputConsumer
from pyspark.sql.context import SQLContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import window 
dir_path = os.path.dirname(os.path.realpath(__file__)) 
os.chdir("..") 
cwd = os.getcwd() 
# print(cwd)
sys.path.insert(1, cwd) 

from utils.aws_utils import aws_extractor
from utils.windows_utils import windows_extractor
from utils.df_compare import make_compare


import pytest
from Tests.parameters import data_paramters

AWS_ACCESS_KEY = "AKIA5IGIQDKSMJ6QU2XZ"
AWS_SECRET_KEY = "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"



def create_Object(AWS_ACCESS_KEY=None, AWS_SECRET_KEY=None):
    if AWS_ACCESS_KEY and AWS_ACCESS_KEY:
        aws = aws_extractor(AWS_ACCESS_KEY, AWS_SECRET_KEY)
        return aws
    else:
        windows = windows_extractor()
        return windows

@pytest.fixture()
def define_aws():
    def parameters(bucket, path, filename=None, output_file=None, file_format='parquet', query=None, data_compare=False, recursive=False):
        aws = create_Object(AWS_ACCESS_KEY, AWS_SECRET_KEY)
        aws_df = aws.read_file(bucket=bucket, path=path, filename=filename,output_file= output_file, file_format=file_format,query=query,data_compare=data_compare, recursive =recursive)
        # df = aws.demo(bucket=bucket, path=path, test=False)

        return aws_df
    return parameters

@pytest.fixture()
def define_windows():
    def w_parameters( path,schema ,query=None):
        windows = create_Object()
        windows_df = windows.wread_file(path=path,query=query, schema=schema)
        # df = aws.demo(bucket=bucket, path=path, test=False)

        return windows_df
    return w_parameters

@pytest.fixture()
def attributes(define_aws, define_windows):
    def values(parameter):
        BUCKET=data_paramters[parameter]['BUCKET']
        PATH=data_paramters[parameter]['PATH']
        FILENAME= data_paramters[parameter]['FILENAME']
        OUTPUT_FILE = data_paramters[parameter]['OUTPUT_FILE']
        FILE_FORMAT = data_paramters[parameter]['FILE_FORMAT']
        QUERY =  data_paramters[parameter]['QUERY']
        DATA_COMPARE = data_paramters[parameter]['DATA_COMPARE']
        RECURSIVE = data_paramters[parameter]['RECURSIVE']
        LOCAL_PATH = data_paramters[parameter]['LOCAL_PATH']
        WOUTPUT_FILE = data_paramters[parameter]['WOUTPUT_FILE']
        SCHEMA = data_paramters[parameter]['SCHEMA']

        aws_df = define_aws(bucket=BUCKET,path=PATH, filename=FILENAME, file_format=FILE_FORMAT,output_file= OUTPUT_FILE, query=QUERY,data_compare=DATA_COMPARE, recursive=RECURSIVE)
        windows_df = define_windows(path=LOCAL_PATH, query=QUERY, schema=SCHEMA)
        # session.stop()
        # status = make_compare(parameter=parameter,OUTPUT_FILE=OUTPUT_FILE, WOUTPUT_FILE=WOUTPUT_FILE)
        status = make_compare(aws_df=aws_df, windows_df=windows_df)
        # print("aws_df ",aws_df)
        # print("windows_df ", windows_df)

        return status
    return values



