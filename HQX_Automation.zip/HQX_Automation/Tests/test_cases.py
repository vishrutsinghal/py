
import pytest
from Tests.parameters import data_paramters

def test_member(attributes): 
    status = attributes('member')
    print(status)
    if status:
        assert True
    elif not status:
        assert False

def test_enroll(attributes):
    status = attributes('enroll')
    print(status)
    if status:
        assert True
    elif not status:
        assert False


def test_rxclaim(attributes):
    status = attributes('rxclaim')
    print(status)
    if status:
        assert True
    elif not status:
        assert False

    