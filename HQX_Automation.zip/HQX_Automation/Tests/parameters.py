'''
This file contains the parameter for AWS 
'''
from pyspark.sql.types import StructType,StringType,StructField,IntegerType

data_paramters = {
    "member" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperator/output/raw/member",
            "FILENAME":'part-00000-1acdea6d-1e3f-4b4c-b6d9-0aa0cf06ab69-c000.snappy.parquet',
            "FILE_FORMAT" :'parquet',
            "OUTPUT_FILE":"member\\member1_result.csv",
            "WOUTPUT_FILE":"member\\QA_MEMBER_01.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False,
            "LOCAL_PATH":"C:\\Users\\Vishrut.Singhal\\Documents\\git_code\\testing\\HQX_Automation\\Resources\\member\\results.csv",
            "SCHEMA":StructType([StructField("MemberId",StringType(),True),StructField("Gender",StringType(),True),StructField("BirthDate",StringType(),True),StructField("Zip",StringType(),True), StructField("FirstName",StringType(),True), StructField("LastName",StringType(),True),StructField("SubscriberRelation",StringType(),True),StructField("DateOfDeath",StringType(),True)])
    },

    "enroll" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperatortest/output/raw/enrollment/",
            "FILENAME":'part-00000-18905a32-cc27-4bac-9046-7713776b284f-c000.snappy.parquet',
            "FILE_FORMAT" :'parquet',
            "OUTPUT_FILE":"enroll\\enroll_result.csv",
            "WOUTPUT_FILE":"enroll\\QA_enroll_01.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False,
            "LOCAL_PATH":"C:\\Users\\Vishrut.Singhal\\Documents\\git_code\\testing\\HQX_Automation\\Resources\\enroll\\results.csv",
            "SCHEMA":StructType([StructField("MemberId",StringType(),True), StructField("StartDate",StringType(),True), StructField("EndDate",StringType(),True),StructField("GroupName",StringType(),True),StructField("BusinessLine",StringType(),True),StructField("ProductCode",StringType(),True)])

    },

    "rxclaim" : {
            "BUCKET":'analytics-chc-dev-analytics-cloud',
            "PATH":"analyticsdataoperators/hqxdataoperator/input/raw/rxClaim",
            "FILENAME":'QA_rxclaim_01.tsv',
            "FILE_FORMAT" :'tsv',
            "OUTPUT_FILE":"rxclaim_result.csv",
            "WOUTPUT_FILE":"\\QA_rxclaim_01.csv",
            "QUERY":'select * from mytable',
            "DATA_COMPARE":False,
            "RECURSIVE":False,
            "LOCAL_PATH":"C:\\Users\\Vishrut.Singhal\\Documents\\config_json\\raw_data\\QA_rxclaim_01.tsv"
    }
}


