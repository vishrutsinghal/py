package com.xavient.tap.selenium.reporting;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import com.xavient.tap.selenium.actions.AppDriver;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.utils.Logger;

public class HtmlSummaryReport {

	private Writer bufWriterS, fileWriterS;
	private Logger logger = new Logger(this);
	String testFinishTime = null;
	String resultsFolder;
	String htmlEventsFolder;

	public void createHTMLSummaryReport(HashMap<Integer, TestResult> resultMAP) {
		try {
			 resultsFolder = ManagingReporter.readTxtFile();
			 htmlEventsFolder = resultsFolder + "/HtmlEvents";
			createSummaryReport(htmlEventsFolder, "Summary.html");
			for (Entry<Integer, TestResult> entry : resultMAP.entrySet()) {
				updateSummaryreport(entry.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeFileS();
		}

	}

	public void addToSummaryMap(TestResult result) {
		AppDriver.summaryMAP.put(AppDriver.summaryMAP.size() + 1, result);

	}

	private void createSummaryReport(String folderPath, String fileName) {

		openSummaryFile(folderPath + "/" + fileName);
		String workingDir = System.getProperty("user.dir");
		String logo = workingDir
				+ "\\src\\main\\resources\\data\\mufg.png";
		writeS("<html><head>");
		writeS("<title>Execution Summary Report</title>");
		writeS("<style>");
		writeS("body {font-family : Candara;background-color: #FFFFFF;}");
		writeS("td {font-family: Candara;background: #d3d3d3;}");
		writeS("th {font-family: Candara;background: #5D8AA8;}");
		writeS("</style>");
		writeS("</head><body>");
		writeS("<center><h3 style='font-family: Candara'>Execution Summary Report</h3></center>");
		writeS("<table width='50px' align='left'>");
		writeS("<tr><td><img alt='MUFG' src='" + logo + "'/></td></tr>");
		writeS("</table><br/><br/><br/><br/>");
		writeS("<table width='100%''>");
		writeS("<tr><th width='25%'>Test Name</th><th width='25%'>Result</th><th width='25%'>Start Time</th><th width='25%'>End Time</th></tr>");
	}

	private void openSummaryFile(String filePath) {
		try {
			fileWriterS = new FileWriter(filePath);
			bufWriterS = new BufferedWriter(fileWriterS);
		} catch (IOException e) {
			logger.handleError("Exception caught : When trying to open a file "
					+ filePath);
		}

	}

	private void writeS(String lines) {
		try {
			bufWriterS.write(lines);
		} catch (IOException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		}
	}

	private void updateSummaryreport(TestResult result) {
		//String testfinishtime = new Date().toString();
		String htmlFileRef = htmlEventsFolder+"/"+result.entityName+".html";
		String workingDir = System.getProperty("user.dir")+"/";
		htmlFileRef = htmlFileRef.replace("./",workingDir);
		String strS;
		strS = "<td> <a href='"+htmlFileRef+"'>" + result.entityName + "</a></td>";
		if(result.finalRsType.isPassed()){
		strS = strS + "<td style='color:#00AB66;'>" + result.finalRsType + "</td>";
		}else{
			strS = strS + "<td style='color:#FF0000;'>" + result.finalRsType + "</td>";
		}
		strS = strS + "<td>" + result.startTime + "</td>";
		strS = strS + "<td>" + result.finishTime + "</td>";
		writeS("<tr>" + strS + "</tr>");
	}

	public void closeFileS() {
		writeS("</table></body></html>");
		try {
			bufWriterS.close();
		} catch (IOException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		} finally {
			try {
				fileWriterS.close();
			} catch (IOException e) {
				logger.handleError("Exception caught : " + e.getMessage());
			} finally {
				fileWriterS = bufWriterS = null;
			}
		}
	}

}
