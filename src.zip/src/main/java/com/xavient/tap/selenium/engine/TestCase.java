package com.xavient.tap.selenium.engine;

import java.util.List;
import java.util.Map;

public interface TestCase {
	public String name();

	public int iterationCount();

	public TestIteration iteration(int iterationIx);

	public Map masterReferences();

	public List<Map> variables();
}
