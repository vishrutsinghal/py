package com.xavient.tap.selenium.reporting;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import com.xavient.tap.selenium.engine.ResultReporter;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.engine.TestResult.EntityType;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.UniqueUtils;
import com.xavient.tap.selenium.utils.Utils;

public class ScreenDumpManager implements ResultReporter {
	private String dumpFolder;
	private String filePath;
	public Logger logger = new Logger(this);
	String uniqueSuffix = UniqueUtils.singleton.uniqueString("3");

	public ScreenDumpManager(String dumpFolder) {
		this.dumpFolder = dumpFolder;
	}

	/****************************************************************
	 * @param fileName
	 ****************************************************************/
	private void dumpScreen(String fileName) {
		logger.trace("DumpScreen : " + fileName);
		Rectangle screenRectangle = new Rectangle(Toolkit.getDefaultToolkit()
				.getScreenSize());
		Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			logger.handleError("Exception in ScreenDumpManager "
					+ e.getMessage());
		}
		BufferedImage image = robot.createScreenCapture(screenRectangle);
		try {
			ImageIO.write(image, "png", new File(fileName));
		} catch (IOException e) {
			logger.handleError("Exception caught while creating screen dump",
					fileName, e.getMessage());
		}
	}

	/****************************************************************
	 * @param result
	 * @param eventData
	 * @return
	 ****************************************************************/
	private String makeDumpName(TestResult result, Object eventData) {
		String name;
		name = result.parent.parent.parent.entityName;
		name = name + "_" + result.parent.entityName;
		name = name + "_" + result.childCount;
		name = name + "_" + uniqueSuffix + System.currentTimeMillis();

		Pattern pattern = Pattern.compile("[^\\w-_]+");
		Matcher m = pattern.matcher(name);
		while (m.find()) {
			m.replaceAll(" ");
		}
		return name;
	}

	/****************************************************************
	 * @param eventType
	 * @param result
	 * @param eventData
	 * @return
	 ****************************************************************/
	private boolean isScreenDump(ResultType eventType, TestResult result,
			Map eventData) {
		if (result.entityType != EntityType.ACTION)
			return false;

		boolean isPassed = result.finalRsType.isPassed();
		if (!isPassed) {
			return true;
		}

		return eventData.get("screenDump") == Boolean.TRUE;
	}

	public void close() {
	}

	public void open(Map headers) {
	}

	public void finish(TestResult result, ResultType rsType, Object details) {
	}

	public void log(TestResult result, ResultType rsType, Map details) {
		logger.trace("Report log");
		if (details.get("screenDump").toString().equalsIgnoreCase("true")) {

			String dumpName = makeDumpName(result, details);
			String fileName = dumpName + ".png";
			filePath = dumpFolder + "/" + fileName;
			dumpScreen(filePath);
			result.miscInfo.put(
					"screenDump",
					Utils.toMap(new String[] { "name", dumpName, "fileName",
							fileName, "filePath", filePath }));
		}
	}

	public void start(TestResult result) {
	}

	public String toString() {
		return "ScreenDumpManager(" + filePath + ")";
	}
}
