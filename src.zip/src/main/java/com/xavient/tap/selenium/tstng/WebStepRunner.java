package com.xavient.tap.selenium.tstng;

import java.lang.reflect.Method;





import org.testng.Assert;
import org.testng.ITest;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.reporting.Report;
import com.xavient.tap.selenium.utils.DataRow;


@Listeners(
	    {
	        TestSequencer.class,
	        //ErsatzListener.class
	    }
)
public class WebStepRunner implements ITest {
	 private String moduleCode;
	  private String actionCode;
	  private DataRow input;
	  private DataRow output;
	  private AppDriver appDriver;
	  private int order;
	   private String stepName;
	
	  public WebStepRunner(int order,AppDriver driver,String moduleCode,String stepName,String actionCode,DataRow drI,DataRow drO) {
		  	this.moduleCode = moduleCode;
		  	this.actionCode=actionCode;
		  	this.input=drI;
		  	this.output=drO;
		  	this.appDriver=driver;
		  	this.order=order;
		  	this.stepName=stepName;
		  	Reporter.log(actionCode);
	  }
	  
	  public int getOrder(){
		  return order;
	  }
	  
	  @Test
	  public void stepRun() {
	    	 Report.start(stepName);	
		  	System.out.println(actionCode);
			appDriver.perform(moduleCode,actionCode,input, output);
			Report.end();
			
		   
		  
	  }
	
	  @Override
		public String getTestName() {
			return  stepName;
			//return null;
		}

}
