package com.xavient.tap.selenium.utils;

import java.util.HashMap;
import java.util.Map;

public class Utils {

	public static Map<Object, Object> toMap(Object[] array) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		for (int i = 0; i < array.length; i = i + 2) {
			map.put(array[i], array[i + 1]);
		}
		return map;
	}

	public static String toString(Object object) {
		return object.toString();
	}

	/****************************************************************
	 * @Method Name : string2Bool
	 * @Method Description : Replace string with boolean value
	 * @param value
	 * @return True or False
	 ****************************************************************/
	public static boolean string2Bool(String value) {
		boolean result = false;
		//if value is Pass|True|Yes|Y|true return true
		if (StringUtils.match(value,
				StringUtils.pattern("(Pass|True|Yes|Y|true)", false, true))) {
			result = true;
		}
		//if value is Pass|True|Yes|Y|true return false
		if (StringUtils.match(value,
				StringUtils.pattern("(Fail|False|No|N|false)", false, true))) {
			result = false;
		}
		return result;
	}

	/****************************************************************
	 * @param map
	 * @return
	 ****************************************************************/
	public static DataRow Map2DataRow(Map map) {
		return new DataRow(map);
	}
}
