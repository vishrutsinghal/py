package com.xavient.tap.selenium.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Substitutor {
	public interface Substitution {
		public String get(String ref);
	};

	private static class NestableMap implements Substitution {
		private Map map;

		NestableMap(Map m) {
			this.map = m;
		}

		public String get(String ref) {
			Object o = map.get(ref);
			if (o != null)
				try {
					return (String) o;
				} catch (ClassCastException e) {

				}
			int dotIx = ref.indexOf(".");
			if (dotIx < 0)
				return null;

			String ref1 = ref.substring(0, dotIx).trim();
			o = map.get(ref1);
			
			//To Fix the critical sonar issue : Dodgy - Redundant nullcheck of value known to be non-null 
			/*if (ref1 == null)
				return null;*/

			String ref2 = ref.substring(dotIx + 1).trim();
			if (o instanceof Substitution) {
				return ((Substitution) o).get(ref2);
			}

			if (o instanceof Map<?, ?>) {
				return (new NestableMap((Map) o)).get(ref2);
			}
			return null;
		}
	};

	private final Substitution substitution;

	public Substitutor(Substitution substitution) {
		this.substitution = substitution;
	}

	public Substitutor(Map substitution) {
		this.substitution = new NestableMap(substitution);
	}

	private static Pattern referencePattern = RegExUtils
			.string2Pattern("\\$\\{([^}]+)\\}");

	/****************************************************************
	 * @param String
	 * @return
	 ****************************************************************/
	public String substitute(String s) {
		return RegExUtils.replace(s, referencePattern,
				new RegExUtils.Replacements() {
					public String replacement(Matcher m) {
						String ref = m.group(1).trim();
						return substitution.get(ref);
					}
				});
	}

	/****************************************************************
	 * @param map
	 * @return
	 ****************************************************************/
	public Map substitute(final Map map) {
		Map substitutedMap = new HashMap();
		//Sonar Fix :  Performance - Inefficient use of keySet iterator instead of entrySet iterator
		Set<Entry> keys = map.entrySet();
		for(Iterator<Entry> i = keys.iterator(); i.hasNext(); ){
			Entry e = (Entry)i.next();
			substitutedMap.put(e.getKey().toString(), substitute(e.getValue().toString()));
		}
		/*Collection<String> keys = map.keySet();
		for (String key : keys) {
			System.out.println(key + " , "+map.get(key) );
			substitutedMap.put(key, substitute((String) map.get(key)));
		}*/
		return substitutedMap;
	}

	/****************************************************************
	 * @param list
	 * @return
	 ****************************************************************/
	public <T> List substitute(final List<T> list) {
		List<T> substitutedList = new ArrayList<T>(list.size());
		for (int ix = 0; ix < list.size(); ix++) {
			T temp = list.get(ix);
			if (temp instanceof Map<?, ?>) {
				temp = (T) substitute((Map) temp);
			} else if (temp instanceof String) {
				temp = (T) substitute((String) temp);
			}
			substitutedList.add(ix, temp);
		}
		return substitutedList;

	}

}
