package com.xavient.tap.selenium.reporting;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.xavient.tap.selenium.engine.ResultReporter;
import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.engine.TestIteration;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.engine.TestStep;
import com.xavient.tap.selenium.engine.TestResult.EntityType;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.HtmlUtils;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.StringUtils;
import com.xavient.tap.selenium.utils.Utils;

public class HtmlEventReporter implements ResultReporter {
	
	HtmlSummaryReport htmlSummaryReport = new HtmlSummaryReport();
	
	public HtmlEventReporter(String folderPath, Map<String, String> settings) {

		this.folderPath = folderPath;
	}

	int step = 0;
	
	public void open(Map headers) {
	}

	public void close() {
	}

	/****************************************************************
	 * @param entityType
	 * @return
	 ****************************************************************/
	private int logLevel(EntityType entityType) {
		String[] levels = new String[] { "TESTCASE", "ITERATION", "TESTSTEP",
				"ACTION" };

		int ix = 0;
		for (String lvl : levels) {
			if (lvl.equals(entityType.toString())) {
				return ix;
			}
			ix = ix + 1;
		}
		return -1;
	}

	/****************************************************************
	 * @param object
	 * @param type
	 * @return
	 * @throws ClassCastException
	 ****************************************************************/
	@SuppressWarnings("unused")
	private Map attributesToMap(Object o, EntityType type)
			throws ClassCastException {
		Map resultMap = null;
		Exception exc = null;
		try {
			switch (type) {
			case TESTCASE:
				TestCase testcase = (TestCase) o;
				resultMap = toMap(new Object[] { "IterationCount",
						testcase.iterationCount(), "TestCaseName",
						testcase.name() });
				break;
			case ITERATION:
				TestIteration iter = (TestIteration) o;
				resultMap = toMap(new Object[] { "StepCount", iter.stepCount(),
						"Parameters",
						iter.parameters().isEmpty() ? "-" : iter.parameters() });
				break;
			case TESTSTEP:
				TestStep step = (TestStep) o;
				resultMap = toMap(new Object[] { "Name", step.stepName(),
						"Action", attributesToMap(o, EntityType.ACTION),
						"OutputValidation", step.actionOutputValidation(),
						"FailTestIfUnexpected", step.failTestIfUnexpected(),
						"AbortTestIfUnexpected", step.abortTestIfUnexpected() });
				break;
			case ACTION:
				TestStep objStep = (TestStep) o;
				resultMap = toMap(new Object[] { "ModuleCode",
						objStep.moduleCode(), "ActionCode",
						objStep.actionCode(), "ActionParameters",
						objStep.actionParameters() });
				break;
			}

		} catch (Exception e) {
			exc = e;
			throw new ClassCastException();
		}
		if (resultMap == null) {
			resultMap = toMap(new Object[] { "EntityType", type, "Entity",
					(StringUtils.toString(o)) });
			/*
			 * if (exc != null) resultMap.put("Error", exc.getMessage());
			 */
		}
		return resultMap;
	}

	public void start(TestResult result) {
		report("START", result, result.entityDetails);
	}

	public void log(TestResult result, ResultType rsType, Map details) {
		reportHTML("DETAILS", result, rsType, details);
	}

	public void finish(TestResult result, ResultType rsType, Object details) {
		report("FINISH", result, result.entityDetails);
	}

	/****************************************************************
	 * @param eventType
	 * @param result
	 * @param eventData
	 ****************************************************************/
	@SuppressWarnings("unchecked")
	private void report(String eventType, TestResult result, Object eventData) {

		String str;
		EntityType entityType = result.entityType;
		int level = logLevel(entityType);
		if (level < 0) {
			return;
		}
		if (level == 0 && eventType.equals("START")) {
			String entityName = result.entityName;
			startHtmlFile(entityName + ".html", entityName);
		}

		if (eventType.equals("DETAILS")) {
			String stepfinishtime = new Date().toString();
			int c = step + 1;
			str = "<td>" + c + "</td>";
			String stepResult = result.finalRsType.toString();
			if (stepResult.equals("Passed")) {
				str = str + "<td style='color:#00AB66;'>" + result.finalRsType
						+ "</td>";
			} else if (stepResult.equals("Failed")) {
				str = str + "<td style='color:#FF0000;'>" + result.finalRsType
						+ "</td>";
			} else {
				str = str + "<td>" + result.finalRsType + "</td>";
			}
			Iterator it = ((Map<String, String>) eventData).entrySet()
					.iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				if (pair.getKey().equals("expected")) {
					str = str.concat("<td>").concat(pair.getValue().toString()).concat("</td>");
				}
				if (pair.getKey().equals("actual")) {
					str = str.concat("<td>").concat(pair.getValue().toString()).concat("</td>");
				}
			}
			str = str + "<td>" + result.startTime + "</td>";
			str = str + "<td>" + stepfinishtime + "</td>";
			str = str + "<td>" + screenDumpLink("Screen Dump", result)
					+ "</td>";
			step = c;
			log(str);
		}
		if (level == 1 && eventType.equals("FINISH")) {
			result.miscInfo.put(
					"EventReport",
					Utils.toMap(new String[] {
							"fileName",
							result.parent.entityName,
							"filePath",
							folderPath + "/" + result.parent.entityName
									+ ".html" }));
		}
		if (level == 0 && eventType.equals("FINISH")) {
			finishHtmlFile(result);
		}
	}

	@SuppressWarnings("unchecked")
	private void reportHTML(String eventType, TestResult result,
			ResultType rsType, Object eventData) {

		String str;
		EntityType entityType = result.entityType;
		int level = logLevel(entityType);
		if (level < 0) {
			return;
		}

		if (eventType.equals("DETAILS")) {
			String stepfinishtime = new Date().toString();
			int c = step + 1;
			str = "<td>" + c + "</td>";
			// result.finalRsType.toString() ;
			if (rsType.level == 1) {
				str = str + "<td style='color:#00AB66;'>Passed</td>";
			} else if (rsType.level == 3) {
				str = str + "<td style='color:#FF0000;'>Failed</td>";
			} else {
				str = str + "<td>" + result.finalRsType + "</td>";
			}
			Iterator it = ((Map<String, String>) eventData).entrySet()
					.iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				if (pair.getKey().equals("expected")) {
					str = str.concat("<td>").concat(pair.getValue().toString()).concat("</td>");
				}
				if (pair.getKey().equals("actual")) {
					str = str.concat("<td>").concat(pair.getValue().toString()).concat("</td>");
				}
			}
			str = str + "<td>" + result.startTime + "</td>";
			str = str + "<td>" + stepfinishtime + "</td>";
			str = str + "<td>" + screenDumpLink("Screen Dump", result)
					+ "</td>";
			step = c;
			log(str);
		}

	}

	/****************************************************************
	 * @param fileName
	 * @param title
	 ****************************************************************/
	private void startHtmlFile(String fileName, String title) {
		openFile(folderPath + "/" + fileName);
		String workingDir = System.getProperty("user.dir");
		String logo = workingDir
				+ "\\src\\main\\resources\\data\\mufg.png";
		write("<html><head>");
		write("<title>" + title + "</title>");
		write("<style>");
		write("body {font-family : Candara;background-color: #FFFFFF;}");
		write("td {font-family: Candara;background: #d3d3d3;}");
		write("th {font-family: Candara;background: #5D8AA8;}");
		write("</style>");
		write("</head><body>");
		write("<center><h3 style='font-family: Candara'>Test Execution Report</h3></center>");
		write("<table width='50px' align='left'>");
		write("<tr><td><img alt='MUFG' src='" + logo + "'/></td></tr>");
		write("</table>");
		write("<table width='320px' align='right'>");
		write("<tr><th>Date</th> <th>Test Case Name</th></tr>");
		write("<tr><td>" + new Date().toString() + "</td><td> " + title
				+ " </td></tr>");
		write("</table><br/><br/><br/><br/>");
		write("<table width='100%''>");
		write("<tr><th width='5%'>Step</th><th width='6%'>Result</th><th width='20%'>Expected Result</th><th width='20%'>Actual Result</th><th width='19%'>Start Time</th><th width='19%'>End Time</th><th width='11%'>Screen Dump</th></tr>");
	}

	private void finishHtmlFile(TestResult result) {
		write("</table></br></br>");
		write("<table width='320px' align='left'>");

		write("<tr><td style='background: #21ABCD;'><b>Test Status</b></td> <td style='background: #21ABCD;'><b>"
				+ result.finalRsType + "</b></td></tr>");

		write("</table></body></html>");
		closeFile();
	
		result.finishTime = new Date();
		htmlSummaryReport.addToSummaryMap(result);
	}

	private void log(String line) {
		write("<tr >" + line + "</tr>");
	}

	/*private String toHtml(TestResult result) {
		return HtmlUtils.getInstance().toHtml(
				toMap(new Object[] { "Result", result.finalRsType, "output",
						result.miscInfo.get("output") }));
	}*/

	private String toHtml(Map result) {
		return HtmlUtils.getInstance().toHtml(result);
	}

	/****************************************************************
	 * @param name
	 * @param eventData
	 * @return
	 ****************************************************************/
	private String screenDumpLink(String name, TestResult eventData) {
		String sDumpFile;
		try {
			sDumpFile = (String) ((Map<String, Map>) eventData.miscInfo).get(
					"screenDump").get("filePath");
			String newStr = sDumpFile.substring(1);
			String workingDir = System.getProperty("user.dir");
			sDumpFile = workingDir + newStr;
			sDumpFile = sDumpFile.replace("\\", "/");
		} catch (Exception e) {

			return "";
		}

		/*if (sDumpFile == null) {
			return "";
		}*/

		return "<a href='" + sDumpFile + "'>" + name + "</a>";
	}

	/****************************************************************
	 * @param status
	 * @return
	 ****************************************************************/
	private String status2Table(TestResult status) {
		ArrayList<Object> objList = new ArrayList<Object>();
		objList.add("Children");
		objList.add(status.childCount);
		for (Entry<ResultType, Integer> entry : status.rsTypeCounts.entrySet()) {
			objList.add(entry.getKey().toString());
			objList.add(entry.getValue() == null ? "-" : entry.getValue());
		}
		return toHtml(toMap(objList.toArray()));
	}

	private Map toMap(Object[] arr) {
		return Utils.toMap(arr);
	}

	/****************************************************************
	 * @param filePath
	 ****************************************************************/
	private void openFile(String filePath) {
		try {
			fileWriter = new FileWriter(filePath);
			bufWriter = new BufferedWriter(fileWriter);
		} catch (IOException e) {
			logger.handleError("Exception caught : When trying to open a file "
					+ filePath);
		}
	}

	/**
	 * 
	 */
	private void closeFile() {
		try {
			bufWriter.close();
		} catch (IOException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		} finally {
			try {
				fileWriter.close();
			} catch (IOException e) {
				logger.handleError("Exception caught : " + e.getMessage());
			} finally {
				fileWriter = bufWriter = null;
			}
		}
	}	

	/****************************************************************
	 * @param lines
	 ****************************************************************/
	private void write(String lines) {
		try {
			bufWriter.write(lines);
		} catch (IOException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		}
	}

	public String toString() {
		return "HtmlEventReporter(" + folderPath + ")";
	}

	private Writer bufWriter, fileWriter;
	private Logger logger = new Logger(this);
	private String folderPath;
}
