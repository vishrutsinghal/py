package com.xavient.tap.selenium.tstng;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;

import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.harness.AppLoader;
import com.xavient.tap.selenium.utils.DataRow;


public class TestFactory {
	
	
	
	 @Parameters({ "testName" })
	  @Factory
	  public Object[] createInstances(String param) {
		
		AppDriver appDriver=null;
		appDriver=new AppLoader().loadApp();
		
		DataRow dr1=new DataRow();
		DataRow dr2=new DataRow();
		DataRow dr3=new DataRow();
		DataRow dr4=new DataRow();
		DataRow dr5=new DataRow();
		
		List<Object> result2=new ArrayList<Object>();
		result2.clear();
		if(param.equals("LoginTest_001")){
			dr1.put("url", "https://www.gmail.com");
			result2.add(new WebStepRunner(0,appDriver,"UB","","launchApp",dr1,dr2));
			
			 dr3.put("Login-password", "1@34567f");
			 dr3.put("Login-userID", "qy92614");
			result2.add(1,new WebStepRunner(1,appDriver,"UB","","login",dr3,dr2));
			
			 dr4.put("SignOut", "Sign Out");
			result2.add(2,new WebStepRunner(2,appDriver,"UB","","logout",dr4,dr2));
		}else{
			dr5.put("url", "https://www.google.com");
			result2.add(0,new WebStepRunner(0,appDriver,"UB1","","launchApp",dr5,dr2));
		}
		Object[] result=result2.toArray(new Object[result2.size()]);
		// System.out.println(result[]);
		System.out.println(result.length);
		return result;
	  }

}
