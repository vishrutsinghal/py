package com.xavient.tap.selenium.qcRESTConnection;

import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;

public class updateEntity {
	
	private RestConnector con;
	/**
     * @param
     */
    public updateEntity() {
        con = RestConnector.getInstance();
    }
	/**
     * @param entityUrl
     *            to update
     * @param updatedEntityXml
     *            New entity descripion. Only lists updated fields.
     *            Unmentioned fields will not change.
     *
     * @return xml description of the entity on the serverside, after update.
     * @throws Exception
     */
    Response update(String entityUrl, String updatedEntityXml)
            throws Exception {

        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("Content-Type", "application/xml");
        requestHeaders.put("Accept", "application/xml");

        Response putResponse =
           con.httpPut(entityUrl, updatedEntityXml.getBytes(), requestHeaders);

        if (putResponse.getStatusCode() != HttpURLConnection.HTTP_OK) {
        	
            throw new Exception(putResponse.toString());
            
        }

        return putResponse;
    }

}
