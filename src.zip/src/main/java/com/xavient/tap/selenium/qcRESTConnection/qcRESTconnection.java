package com.xavient.tap.selenium.qcRESTConnection;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
/*import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.xavient.tap.selenium.common.Encryption;
import com.xavient.tap.selenium.common.FileUtilities;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.engine.TestResultLogger;
import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.qcRESTConnection.Entities.Entity;
import com.xavient.tap.selenium.qcRESTConnection.Entities.Entity.Fields.Field;
import com.xavient.tap.selenium.utils.StringUtils;

public class qcRESTconnection {

	public static String resultsFolder;
	ConfigParams CONFIG = ConfigParams.SINGLETON;
	String serverUrl = "http://hpqc.unionbank.com:8080/qcbin";
	
	String userName = CONFIG.properties.getProperty("ALMUserID");
	String password = CONFIG.properties.getProperty("ALMPassword");
	String domainName = CONFIG.properties.getProperty("ALMDomainName");
	String projectName = CONFIG.properties.getProperty("ALMProjectName");
	String ALMTestSetFolder = CONFIG.properties.getProperty("ALMTestSetFolder");
	String ALMTestSet=CONFIG.properties.getProperty("ALMTestSet");
	
	String testCyclId;
	String cyclId;
	String newRunID;
	
	String uploadTestResult = CONFIG.properties.getProperty("UploadRunResult");
	String UploadTestSteps = CONFIG.properties.getProperty("UploadTestSteps");
	String UploadAttachment = CONFIG.properties.getProperty("UploadAttachment");
	String logFolderPath = CONFIG.properties.getProperty("LogFolder");
	
	//For defect creation in QC
	String createDefect = CONFIG.properties.getProperty("CreateDefect");
	String defectInApplication = CONFIG.properties.getProperty("DefectInApplication");
	String detectedBy = CONFIG.properties.getProperty("DetectedBy");
	String assignedTo = CONFIG.properties.getProperty("AssignedTo");
	String environment = CONFIG.properties.getProperty("Environment");
	String severity = CONFIG.properties.getProperty("Severity");
	String testPhase = CONFIG.properties.getProperty("TestPhase");
	String projectID = CONFIG.properties.getProperty("ProjectID");
	String defectEmailRecipients = CONFIG.properties.getProperty("DefectEmailRecipients");

	RestConnector con;
	
	HashMap<String, String>  testInstanceHM= new HashMap<String, String>(); 
	HashMap<String, String>  testCyclIdHM= new HashMap<String, String>(); 
	
	public HashMap<String, String> connectToQc() throws Exception{
		
		List<String> testInstances = new ArrayList<String>();
		List<String> testIdList = new ArrayList<String>();
		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Accept", "application/xml");
		
		//Connect To QC and get the connection object
		con = RestConnector.getInstance().init(
				new HashMap<String, String>(), serverUrl, domainName, projectName);
		
		//Login to QC
		login(userName, Encryption.decrypt(password));
		
		//***********************************
		
		//Get the test folder path
		String testSetFoldersUrl = con.buildEntityCollectionUrl("test-set-folder");
		
		//Append the query with test folder name
		StringBuilder b = new StringBuilder();
		b.append("query={name['"+ALMTestSetFolder+"']}");
		
		String testSetFolderReturnedXML = con.httpGet(testSetFoldersUrl, b.toString(),
				requestHeaders).toString();
		
		//Map the response XML to an entity
		Entities entities = EntityMarshallingUtils.marshal(Entities.class,
				testSetFolderReturnedXML);
		
		List<Entity> folderEntity = (List<Entity>) entities.getEntity();
		
		//Parse through the entity to get test instance name
		for (Entity entity : folderEntity) {
			
			List<Field> fields = entity.getFields().getField();
			
			for(Field field : fields){
				if (field.getName().equals("hierarchical-path")){
					String value = field.getValue().toString();
					String hierarchcalPath = value.substring(1, value.length() - 1);
					
					String testSetUrl = con.buildEntityCollectionUrl("test-set");
					StringBuilder bu = new StringBuilder();
					bu.append("query={test-set-folder.hierarchical-path["+hierarchcalPath+"*]}");
					String testSetReturnedXML = con.httpGet(testSetUrl, bu.toString(),
							requestHeaders).toString();
					
					//Map the response XML to an entity
					Entities setEntities = EntityMarshallingUtils.marshal(Entities.class,
							testSetReturnedXML);
					
					List<Entity> setEntity = (List<Entity>) setEntities.getEntity();
					for (Entity setentity : setEntity) {
						List<Field> setFields = setentity.getFields().getField();
						for(Field setfield : setFields){
							if(setfield.getName().equals("name")){
								String name = setfield.getValue().toString();
								String setName = name.substring(1,name.length()-1);
								if(setName.equals(ALMTestSet)){
								
									String testInstanceUrl = con.buildEntityCollectionUrl("test-instance");
									StringBuilder bui = new StringBuilder();
									bui.append("query={contains-test-set.name["+setName+"]}&page-size=1000");
									String testInstanceReturnedXML = con.httpGet(testInstanceUrl, bui.toString(),
											requestHeaders).toString();
									Entities instanceEntities = EntityMarshallingUtils.marshal(Entities.class,
											testInstanceReturnedXML);
									List<Entity> instanceEntity = (List<Entity>) instanceEntities.getEntity();
									for (Entity instanceentity : instanceEntity) {
										String testId = null;
										List<Field> instanceFields = instanceentity.getFields().getField();
										for(Field instancefield : instanceFields){
											
											if(instancefield.getName().equals("test-id")){
												String testIdValue = instancefield.getValue().toString();
												testId = testIdValue.substring(1, testIdValue.length()-1);
												testIdList.add(testId);
											}
											else if(instancefield.getName().equals("id")){
												String id =  instancefield.getValue().toString();
												testCyclId = id.substring(1, id.length()-1);
											}else if(instancefield.getName().equals("cycle-id")){
												String cycle_id = instancefield.getValue().toString();
												cyclId = cycle_id.substring(1, cycle_id.length()-1);
											}
											
										}
										testCyclIdHM.put(testId, testCyclId);
									}
								}
							}
						}
					}
					
				}
			}
		}
		//Iterate through each test Id and get the test instance name
		for(String testIds : testIdList){
			
			String testInstanceNameUrl = con
					.buildEntityCollectionUrl("test");
			String testInstanceNameReturnedXML = con.httpGet(testInstanceNameUrl + "/" +testIds, null,
					requestHeaders).toString();
			com.xavient.tap.selenium.qcRESTConnection.Entity instanceNameEntities = EntityMarshallingUtils.marshal(com.xavient.tap.selenium.qcRESTConnection.Entity.class, testInstanceNameReturnedXML);
			List<com.xavient.tap.selenium.qcRESTConnection.Entity.Fields.Field> instanceNameFields = instanceNameEntities.getFields().getField();
			for(com.xavient.tap.selenium.qcRESTConnection.Entity.Fields.Field instancenamefield : instanceNameFields){
				if(instancenamefield.getName().equals("name")){
					String instName = instancenamefield.getValue().toString();
					testInstances.add(instName.substring(1, instName.length()-1));
					testInstanceHM.put(testIds, instName.substring(1, instName.length()-1));
					
				}
			
		}
		}
		return testInstanceHM;
	}
	
	/**
     * @param username
     * @param password
     * @return true if authenticated at the end of this method.
     * @throws Exception
     *
     * convenience method used by other examples to do their login
     */
	
	public boolean login(String username, String password) throws Exception {

        String authenticationPoint = this.isAuthenticated();
        if (authenticationPoint != null) {
            return this.login(authenticationPoint, username, password);
        }
        return true;
    }
	
	/**
     * @param loginUrl
     *            to authenticate at
     * @param username
     * @param password
     * @return true on operation success, false otherwise
     * @throws Exception
     *
     * Logging in to our system is standard http login (basic authentication),
     * where one must store the returned cookies for further use.
     */
	public boolean login(String loginUrl, String username, String password)
	        throws Exception {

	        //create a string that lookes like:
	        // "Basic ((username:password)<as bytes>)<64encoded>"
	        byte[] credBytes = (username + ":" + password).getBytes();
	        String credEncodedString = "Basic " + Base64Converter.encode(credBytes);

	        Map<String, String> map = new HashMap<String, String>();
	        map.put("Authorization", credEncodedString);

	        Response response = con.httpGet(loginUrl, null, map);

	        boolean ret = response.getStatusCode() == HttpURLConnection.HTTP_OK;

	        return ret;
	    }
	/**
     * @return null if authenticated.<br>
     *         a url to authenticate against if not authenticated.
     * @throws Exception
     */
    public String isAuthenticated() throws Exception {

        String isAuthenticateUrl = con.buildUrl("rest/is-authenticated");
        String ret;

        Response response = con.httpGet(isAuthenticateUrl, null, null);
        int responseCode = response.getStatusCode();

        //if already authenticated
        if (responseCode == HttpURLConnection.HTTP_OK) {

            ret = null;
        }

        //if not authenticated - get the address where to authenticate
        // via WWW-Authenticate
        else if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {

            Iterable<String> authenticationHeader =
                    response.getResponseHeaders().get("WWW-Authenticate");

            String newUrl =
                authenticationHeader.iterator().next().split("=")[1];
            newUrl = newUrl.replace("\"", "");
            newUrl += "/authenticate";
            ret = newUrl;
        }

        //Not ok, not unauthorized. An error, such as 404, or 500
        else {

            throw response.getFailure();
        }

        return ret;
    }
    
    /**
     * @return true if logout successful
     * @throws Exception
     *             close session on server and clean session cookies on client
     */
    public boolean logout() throws Exception {

     //note the get operation logs us out by setting authentication cookies to:
     // LWSSO_COOKIE_KEY="" via server response header Set-Cookie

        Response response =
                con.httpGet(con.buildUrl("authentication-point/logout"),
                null, null);
     
        return (response.getStatusCode() == HttpURLConnection.HTTP_OK);
       
    }
    
    /**
     * @return true if disconnected successful
     * @throws Exception
     *             close session on server and clean session cookies on client
     */
    public boolean closeQC() throws Exception {

     //note the get operation logs us out by setting authentication cookies to:
     // LWSSO_COOKIE_KEY="" via server response header Set-Cookie
   	
        Response response =
                con.httpGet(con.buildUrl("authentication-point/Disconnect"),
                null, null);
     
        return (response.getStatusCode() == HttpURLConnection.HTTP_OK);
       
    }
    /****************************************************************
	 * @Method Name :updateTestCaseStatus
	 * @Method Description : Update the Testcase Status in QC
	 * @param args
	 *            TestResult object
	 * @return Void
	 * @sample Call : updateTestCaseStatus(qcResult)
	 ****************************************************************/
	public void updateTestCaseStatus(TestResult qcResult) {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String execDate = dateFormat.format(date);
		
		DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = new Date();
		String execTime = timeFormat.format(time);
		
		String testCycleID = null;
		try{
			if (uploadTestResult.equalsIgnoreCase("true")) {
				
				HashMap<String , String> testInstHM = connectToQc();
				Set set = testInstHM.entrySet();
	        	Iterator i = set.iterator();
	        	while(i.hasNext()) {
	                Map.Entry me = (Map.Entry)i.next();
	                if (qcResult.entityName.equals(me.getValue())) {
	                	String testRunUrl = con
								.buildEntityCollectionUrl("run");
	                	createEntity ce = new createEntity();
	                	Set testCycleIDset = testCyclIdHM.entrySet();
	                	Iterator testCycleIDItr = testCycleIDset.iterator();
	                	while(testCycleIDItr.hasNext()){
	                		 Map.Entry meTestCycleID = (Map.Entry)testCycleIDItr.next();
	                		if(me.getKey().equals(meTestCycleID.getKey())){
	                			testCycleID = meTestCycleID.getValue().toString();
	                		}
	                	}
	                	
	                	String testInstURL = con.buildEntityCollectionUrl("test-instance");
	                	updateEntity ue = new updateEntity();
	                	ue.update(testInstURL+"/"+testCycleID, "<Entity Type='test-instance'> <Fields> <Field Name='exec-date'> <Value>"+execDate+"</Value> </Field><Field Name='exec-time'> <Value>"+execTime+"</Value> </Field> <Field Name='status'> <Value>"+qcResult.finalRsType.toString()+"</Value> </Field> </Fields> <RelatedEntities /> </Entity>");
	                	String url = ce.createEnt(testRunUrl, "<?xml version='1.0' encoding='UTF-8' standalone='yes'?> <Entity Type='run'> <Fields> <Field Name='name'> <Value>RunNew</Value> </Field> <Field Name='test-instance'> <Value>1</Value> </Field> <Field Name='testcycl-id'> <Value>"+testCycleID+"</Value> </Field> <Field Name='cycle-id'> <Value>"+cyclId+"</Value> </Field> <Field Name='test-id'> <Value>"+me.getKey()+"</Value> </Field> <Field Name='subtype-id'> <Value>hp.qc.run.MANUAL</Value> </Field> <Field Name='status'> <Value>"+qcResult.finalRsType.toString()+"</Value> </Field> <Field Name='owner'> <Value>"+userName+"</Value> </Field> </Fields> <RelatedEntities /> </Entity>");
	                	newRunID = url.substring(url.lastIndexOf("/")+1, url.length());
	                	if (UploadTestSteps.equalsIgnoreCase("true")) {
							try {
								// updating the test steps for the current run
								updateTestSteps(newRunID);
							} catch (Exception e) {
								e.printStackTrace();
								System.out
										.println("Failed to update Test steps for test case "
												+ me.getValue());
							}
						}
	                	if (UploadAttachment.equalsIgnoreCase("true")) {
							FileUtilities fu = new FileUtilities();
							try {
								// uploading the result(logs) to the current run
								uploadAttachemnt(newRunID, fu.zipFolder(
										resultsFolder,  me.getValue().toString()),me.getValue().toString());
							} catch (Exception e) {
								e.printStackTrace();
								System.out
										.println("Failed to upload attachements for test case "
												+ me.getValue());
							}

						}
	                }
	        	}
				
			}	
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/****************************************************************
	 * @Method Name :updateTestSteps
	 * @Method Description : Update the test steps for the test ID for current
	 *         run
	 * @param args
	 *            TestID,IRun object
	 * @return Void
	 * @throws Exception 
	 * @sample Call : updateTestSteps(testID,run)
	 ****************************************************************/
	private void updateTestSteps(String runID) throws Exception {
		
		createEntity ce = new createEntity();
		Map<String, String> stepMap = null;
		Map<String, Map<String, String>> testSteps = TestResultLogger.testSteps;
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String execDate = dateFormat.format(date);
		
		DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = new Date();
		String execTime = timeFormat.format(time);
		
		String testRunStepUrl = con
				.buildEntityCollectionUrl("run");
		String runStepURL = testRunStepUrl+"/"+runID+"/run-steps/";
		
		for (int i = 1; i <= testSteps.size(); i++) {
			stepMap = new HashMap<String, String>();
			stepMap = testSteps.get("Step" + i);
			if (StringUtils.isValidString(stepMap.get("name"))) {
				String name = null;
				if(stepMap.get("name").contains("&")){
					name = stepMap.get("name").replace("&", "and");
				}else{
					name = stepMap.get("name");
				}
				ce.createEnt(runStepURL, "<Entity Type='run-step'> <Fields> <Field Name='name'> <Value>"+name+"</Value> </Field> <Field Name='status'> <Value>"+stepMap.get("StepResult")+"</Value> </Field> <Field Name='parent-id' /> <Field Name='execution-date'> <Value>"+execDate+"</Value> </Field><Field Name='expected'> <Value>"+stepMap.get("expected")+"</Value> </Field> <Field Name='actual'> <Value>"+stepMap.get("actual")+"</Value> </Field> <Field Name='execution-time'> <Value>"+execTime+"</Value> </Field> <Field Name='step-order'> <Value>"+i+"</Value> </Field> </Fields> </Entity>");
			}
		}
		
	}
	/****************************************************************
	 * @Method Name :uploadAttachemnt
	 * @Method Description : Upload the Result file to QC for current run
	 * @param args
	 *            IRun object, file
	 * @return Void
	 * @throws Exception 
	 * @sample Call : uploadAttachemnt(run,file)
	 ****************************************************************/
	private void uploadAttachemnt(String newRunID, String file, String name) throws Exception {
		
		String strDate;
		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		strDate = ft.format(dNow);
		
		String fileName = "Report_" + strDate+"_"+name+".zip";
		
		String testRunUrl = con
				.buildEntityCollectionUrl("run");
		
		String 	testRunAttUrl = testRunUrl+"/"+newRunID;
		
		FileInputStream fileInputStream=null;
		File fil = new File(file);
		 byte[] bFile = new byte[(int) fil.length()];
		 try {
			 //convert file into array of bytes
		    fileInputStream = new FileInputStream(fil);
		    fileInputStream.read(bFile);
		 }catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(fileInputStream!=null){
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		 
		/*Path path = Paths.get(file);
		byte[] data = Files.readAllBytes(path);*/
		attachWithOctetStream(testRunAttUrl, bFile, fileName);
	}
	
	/****************************************************************
     * @param entityUrl
     *            url of entity to attach the file to
     * @param fileData
     *            content of file
     * @param filename
     *            to use on server side
     * @return
     ****************************************************************/
    String attachWithOctetStream(String entityUrl, byte[] fileData,
         String filename) throws Exception {

        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("Slug", filename);
        requestHeaders.put("Content-Type", "application/octet-stream");

        Response response =
			con.httpPost(entityUrl + "/attachments", fileData, requestHeaders);

        if (response.getStatusCode() != HttpURLConnection.HTTP_CREATED) {
            throw new Exception(response.toString());
        }

        return response.getResponseHeaders().get("Location").iterator().next();
    }
    
    
    /****************************************************************
	 * @Method Name :createDefect
	 * @Method Description : Create a defect in QC, if a test case fails
	 * @param args
	 *            TestResult object
	 * @return Void
	 * @sample Call : createDefect(qcResult)
	 ****************************************************************/
	public void createDefect(TestResult qcResult) {
		try{
			System.out.println(qcResult.finalRsType.toString());
			if (createDefect.equalsIgnoreCase("true") && qcResult.finalRsType.toString().equalsIgnoreCase("failed")) {
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				Date date = new Date();
				String createDate = dateFormat.format(date);
				
				createEntity ce = new createEntity();
				String defectURL = ce.createEnt(con.buildEntityCollectionUrl("defect"), 
						"<?xml version='1.0' encoding='UTF-8'?>" +
						"<Entity Type='defect'><Fields>" +
						"<Field Name='name'><Value>"+qcResult.entityName+"</Value></Field>" +
						"<Field Name='closing-version'><Value>OB R25</Value></Field>" +
						"<Field Name='description'><Value>Test Case Name : "+qcResult.entityName+" under the test folder "+ALMTestSetFolder+" and test set "+ALMTestSet+" is failed. Please check the attachments for logs.</Value></Field>" +
						"<Field Name='detected-by'><Value>"+userName+"</Value></Field>" +
						"<Field Name='creation-time'><Value>"+createDate+"</Value></Field>" +
						"<Field Name='dev-comments'><Value>Test Case Name : "+qcResult.entityName+" under the test folder "+ALMTestSetFolder+" and test set "+ALMTestSet+" is failed. Please check the attachments for logs.</Value></Field>" +
						"<Field Name='owner'><Value>"+userName+"</Value></Field>" +
						"<Field Name='status'><Value>New</Value></Field>" +
						"<Field Name='user-01'><Value>"+defectInApplication+"</Value></Field>" +
						"<Field Name='user-02'><Value>"+defectInApplication+"</Value></Field>" +
						"<Field Name='user-03'><Value>1</Value></Field>" +
						"<Field Name='user-04'><Value>"+projectID+"</Value></Field>" +
						"<Field Name='user-05'><Value>"+environment+"</Value></Field>" +
						"<Field Name='user-07'><Value>"+testPhase+"</Value></Field>" +
						"<Field Name='user-08'><Value>TAP_Test</Value></Field>" +
						"<Field Name='user-11'><Value>"+severity+"</Value></Field>" +
						"<Field Name='user-15'><Value>"+assignedTo+"</Value></Field>" +
						"<Field Name='user-16'><Value>"+detectedBy+"</Value></Field>" +
						"</Fields></Entity>");
				
				String newDefectID = defectURL.substring(defectURL.lastIndexOf("/")+1, defectURL.length());
				FileUtilities fu = new FileUtilities();
				uploadDefectAttachemnt(newDefectID,fu.zipFolder(
						resultsFolder,  qcResult.entityName),qcResult.entityName);

				ce.createEnt(con.buildEntityCollectionUrl("defect")+"/"+newDefectID+"/mail",
						"<mail><to-recipients>"+defectEmailRecipients+"</to-recipients></mail>");
				
				System.out.println("Test Case :" + qcResult.entityName +" is failed. A defect with attached logs has been created in QC.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/****************************************************************
	 * @Method Name :uploadDefectAttachemnt
	 * @Method Description : Upload the log for defect created
	 * @param args
	 *            IRun object, file
	 * @return Void
	 * @throws Exception 
	 * @sample Call : uploadAttachemnt(run,file)
	 ****************************************************************/    
	private void uploadDefectAttachemnt(String newDefectID, String file, String name) throws Exception {
		
		String strDate;
		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
		strDate = ft.format(dNow);
		
		String fileName = "Report_" + strDate+"_"+name+".zip";
		
		String testDefectUrl = con
				.buildEntityCollectionUrl("defect");
		
		String 	testDefectAttUrl = testDefectUrl+"/"+newDefectID;
		
		FileInputStream fileInputStream=null;
		File fil = new File(file);
		 byte[] bFile = new byte[(int) fil.length()];
		 try {
			 //convert file into array of bytes
		    fileInputStream = new FileInputStream(fil);
		    fileInputStream.read(bFile);
		 }catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(fileInputStream!=null){
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		 
		/*Path path = Paths.get(file);
		byte[] data = Files.readAllBytes(path);*/
		attachWithOctetStream(testDefectAttUrl, bFile, fileName);
	}

	/****************************************************************
	 * @Method Name :UpdateRunStatus
	 * @Method Description : Update the status in excel sheet for the current
	 *         step
	 * @return Void
	 * @sample Call : UpdateRunStatus()
	 ****************************************************************/

	public void UpdateRunStatus() {
		
		String sFileName, sSheetName, sUpdateFld;
		sFileName = ConfigParams.SINGLETON.properties.getProperty("DataTable");
		sSheetName = "[Steps$]";
		sUpdateFld = "_selectYN";
		PreparedStatement pstmt = null;
		Connection con = null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager
					.getConnection("jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="
							+ sFileName + ";READONLY=false");

			String sMainQry = "UPDATE " + sSheetName + " SET " + sUpdateFld
					+ "=?";
			String sWhereClause = ";";
			pstmt = con.prepareStatement(sMainQry + sWhereClause);
			pstmt.setString(1, "No");
			int changedRows = pstmt.executeUpdate();
			System.out.println("Tcom.unionbank.qel Rows Updated= "
					+ changedRows);

			pstmt.close();
			con.close();
		} catch (Exception ex) {
			System.err.print("Exception: " + ex);
		}finally{
			if(pstmt!=null){
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
