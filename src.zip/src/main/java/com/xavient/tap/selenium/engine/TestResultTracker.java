package com.xavient.tap.selenium.engine;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.xavient.tap.selenium.engine.TestResult.EntityType;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.FrameworkException;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.StringUtils;
import com.xavient.tap.selenium.utils.Utils;

public class TestResultTracker {
	public interface Reporter {
		public void start(TestResult result);

		public void log(TestResult result, ResultType rsType, Map details);

		public void finish(TestResult result, ResultType rsType, Object details);
	};

	public TestResultTracker(List<Reporter> oReporter) {
		reporters = oReporter;
	}

	public void addReporter(Reporter reporter) {
		try {
			reporters.add(reporter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	TestResult leafResult = null;

	/************* Functions ********************/
	/****************************************************************
	 * @param testResult
	 * @param entityType
	 * @param entityName
	 * @param entityDetails
	 * @return
	 ****************************************************************/
	private TestResult start(TestResult testResult,
			TestResult.EntityType entityType, String entityName,
			Object entityDetails) {
		TestResult result = new TestResult(leafResult, entityType, entityName,
				entityDetails);
		result.startTime = new Date();
		leafResult = result;
		for (Reporter reporter : reporters)
			reporter.start(result);
		return result;
	}

	private void finish() {
		TestResult result = leafResult;
		if (result == null) {
			throw new FrameworkException("No result when details called ");
		}
		leafResult = result.parent;
		if (leafResult != null) {
			result.finishTime = new Date();
			leafResult.add(result.msRsType, result);
		}
		for (Reporter reporter : reporters)
			reporter.finish(result, result.msRsType, result.finalRsType);
	}

	public interface Trackable {
		// results have to be added/set to this result object
		public void run(TestResult result) throws Exception;
	}

	/****************************************************************
	 * @param trackable
	 * @param entityType
	 * @param entityName
	 * @param entity
	 * @return
	 ****************************************************************/
	public TestResult track(Trackable trackable,
			TestResult.EntityType entityType, String entityName, Object entity) {
		TestResult result = start(leafResult, entityType, entityName, entity);

		logger.detail("START : "
				+ Thread.currentThread().getStackTrace()[4].getMethodName());
		try {
			trackable.run(result);
		} catch (Exception e) {
			result.add(ResultType.FAILED,
					toMap(new Object[] { "exception", e }));
		}
		logger.detail("FINISH : "
				+ Thread.currentThread().getStackTrace()[4].getMethodName()
				+ " STATUS : " + result.finalRsType);

		finish();

		return result;
	}

	/****************************************************************
	 * @param rsType
	 * @param details
	 ****************************************************************/
	public void log(ResultType rsType, Object details) {
		if (leafResult.entityType == EntityType.TESTCASE) { // details is
															// TestCase
			leafResult.entityDetails = details;
			return; // consume this event
		}

		leafResult.add(rsType, (Map) details);
		logger.trace("Report Event: type:" + rsType.toString() + ":details:"
				+ toString(details));
		for (Reporter reporter : reporters)
			reporter.log(leafResult, rsType, (Map) details);
	}

	private Logger logger = new Logger(this);
	private List<Reporter> reporters = new ArrayList<Reporter>();

	private static String toString(Object o) {
		return StringUtils.toString(o);
	}

	private static Map toMap(Object[] o) {
		return Utils.toMap(o);
	}

	public String toString() {
		return "TestResultTracker()";
	}
}
