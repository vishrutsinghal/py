package com.xavient.tap.selenium.xmlparser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.xavient.tap.selenium.common.FileUtilities;
import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.engine.TestIteration;
import com.xavient.tap.selenium.engine.TestStep;
import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.qcRESTConnection.qcRESTconnection;
import com.xavient.tap.selenium.utils.DataRow;
import com.xavient.tap.selenium.utils.StringUtils;
import com.xavient.tap.selenium.utils.Substitutor;
import com.xavient.tap.selenium.utils.Utils;

public class XmlReader {
	
	ConfigParams CONFIG = ConfigParams.SINGLETON;
	public qcRESTconnection qcConnect = new qcRESTconnection();
	
	/****************************************************************
	 * @return
	 * @throws Exception
	 ****************************************************************/
	public List<String> tetsToExecute() throws Exception{
		String currentTestCase="";
		List<String> testCaseList=new ArrayList<String>();
		String testCaseName = CONFIG.properties.getProperty(
				"testcasename");
		
		try{
			if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
        		System.out.println("Getting the test instance name from QC and executing");
        		//Using REST
        		HashMap<String,String> testCases = qcConnect.connectToQc();
        		Set set = testCases.entrySet();
        		Iterator i = set.iterator();
        		while(i.hasNext()) {
        			Map.Entry me = (Map.Entry)i.next();
        			currentTestCase = me.getValue().toString();
        			System.out.println("Executing "+currentTestCase);
        			testCaseList.add(currentTestCase);
        		}//end of if
        	
        	}else if(CONFIG.properties.getProperty("QCConnection").toLowerCase().equalsIgnoreCase("false") && CONFIG.properties.getProperty("TestDataMode").toLowerCase().equalsIgnoreCase("xml")) { 
				System.out.println("Executing from XML **********");
				try {
					FileUtilities fileUtilities = new FileUtilities();
					File fXmlFile = fileUtilities.loadFile(
							ConfigParams.SINGLETON.properties
									.getProperty("TestDataXml"));
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory
							.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document doc = dBuilder.parse(fXmlFile);
		
					doc.getDocumentElement().normalize();
		
					/*System.out.println("Root element :"
							+ doc.getDocumentElement().getNodeName());*/
		
		
					Element rootElement = doc.getDocumentElement();
					NodeList children = rootElement.getChildNodes();
					Node current = null;
					int count = children.getLength();
					//System.out.println("Count : " + count);
		
					for (int i = 0; i < count; i++) {
						current = children.item(i);
						if (current.getNodeType() == Node.ELEMENT_NODE) {
							Element element = (Element) current;
		
							String secondLevelTagName = element.getAttribute("name");
							
							//Execute the test case if the attribute "execute" of test case name is "yes" 
							if(element.getAttribute("execute").toString().equalsIgnoreCase("yes")){
								currentTestCase = element.getAttribute("name");
								System.out.println("Executing " + currentTestCase);
								testCaseList.add(currentTestCase);
							}//end of if
							
						}//end of if
					}//end of for
				}catch (ParserConfigurationException e) {
					e.printStackTrace();
				} catch (SAXException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			
		}else{
      	  System.out.println("Executing the give test case ");
      	  testCaseList.add(testCaseName);
			
		}//end of else	
			
		}catch(Exception e){
			e.printStackTrace();
        	//logger.error("Error while executing test case "+currentTestCase+", "+e.getMessage());
			System.out.println("Error while executing test case "+currentTestCase+", "+e.getMessage());
			
		}finally {
			if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
				boolean logOff= qcConnect.logout();
				if(logOff){
					System.out.println("Succesfully logged out from QC");
				}//end of if -logout
			}
		}//end of finally
		
		return testCaseList;
		
	}
	
	/****************************************************************
	 * @param testName
	 * @return
	 * @throws Exception
	 ****************************************************************/
	public TestCase getTestCase(String testName) throws Exception{
		final Map references=null;
		List<Map> iterRows = null;
		List<Map> vars = new ArrayList<Map>();
		List<Map> stepRows = new ArrayList<Map>();
		List<Map> stepRows1 = new ArrayList<Map>();
		List<Map> stepRows2 = new ArrayList<Map>();
		System.out.println("Test Case Name : "+testName);
		
		iterRows = new ArrayList<Map>();
		iterRows.add(new HashMap());
		try{
			FileUtilities fileUtilities = new FileUtilities();
			File fXmlFile = fileUtilities.loadFile(
					ConfigParams.SINGLETON.properties
							.getProperty("TestDataXml"));
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();

			//System.out.println("Root element :"
					//+ doc.getDocumentElement().getNodeName());


			Element rootElement = doc.getDocumentElement();
			NodeList children = rootElement.getChildNodes();
			Node current = null;
			int count = children.getLength();
			//System.out.println("Count : " + count);

			for (int i = 0; i < count; i++) {
				current = children.item(i);
				String tagName=current.getNodeName();
				if (current.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) current;
					String secondLevelTagName = element.getAttribute("name");

					if (secondLevelTagName.equalsIgnoreCase(testName)) {
						NodeList children1 = current.getChildNodes();

						int count1 = children1.getLength();
						Map myData = new HashMap();
						for (int j = 0; j < count1; j++) {
							Node current1 = children1.item(j);
							if (current1.getNodeType() == Node.ELEMENT_NODE) {
								Element element1 = (Element) current1;
								System.out.println("Step Name : "
										+ element1.getAttribute("name"));
								myData.clear();
								myData.put("testCaseName", testName);
								myData.put("stepName",
										element1.getAttribute("name"));
								// Get all subnodes of stepName tag
								NodeList children2 = current1.getChildNodes();

								for (int k = 0; k < children2.getLength(); k++) {
									Node current2 = children2.item(k);
									if (current2.getNodeType() == Node.ELEMENT_NODE) {
										Element element2 = (Element) current2;
										System.out.println(element2.getTagName()); //Added by Q
										myData.put(element2.getTagName(),
												element2.getTextContent());

									}

								}

								Map myMap=Utils.Map2DataRow(myData);
								stepRows1.add(0, myMap);

							}
						}

					}

				}
			}
			
		}catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		final String sName=testName;
		for (int cnt = 0; cnt < stepRows1.size(); cnt++) {
			stepRows.add(0, stepRows1.get(cnt));
		}
		stepRows = substitute(stepRows, references);
		
		final List<TestIteration> iterations = makeIterations(iterRows,
				references, stepRows);
		
		if (iterations.size() == 0) {
			//logger.handleError("No iterations are selected from the "
					//+ SHN_ITERATIONS + " sheet");
			System.out.println("No iterations are selected from the Iterations sheet");
			return null;
		}

		return new TestCase() {
			public TestIteration iteration(int iterationIx) {
				return iterations.get(iterationIx);
			}

			public int iterationCount() {
				return iterations.size();
			}

			public Map masterReferences() {
				return references;
			}

			public String name() {
				return sName;
			}

			public List<Map> variables() {
				//return variables;
				return null;
			}

		};
	}//end of getTestCase()
	
	
	/****************************************************************
	 * @param stepRow
	 * @param substitutions
	 * @return
	 ****************************************************************/
	private List<Map> substitute(List<?> stepRow, Map substitutions) {
		List<Map> result = (List<Map>) stepRow;
		if (substitutions != null)
			result = new Substitutor(substitutions).substitute(stepRow);
		return result;
	}
	
	/****************************************************************
	 * @param iterRows
	 * @param references
	 * @param stepRows
	 * @return
	 * @throws Exception
	 ****************************************************************/
	private List<TestIteration> makeIterations(List<Map> iterRows,
			Map references, List<Map> stepRows) throws Exception {
		List<TestIteration> iterations = new ArrayList();
		boolean isSelected;
		for (Map iterRow : iterRows) {
			isSelected = true;
			if (!iterRow.isEmpty()) {
				isSelected = s2B(
						CONFIG.properties
								.getProperty("EnableIterationSelection"),
						true);
				if (isSelected) {
					isSelected = s2B((String) iterRow.get("_selectYN"), true);

				}
			}
			if (isSelected) {
				//System.out.println(references);
				TestIteration iteration = makeIteration(iterRow, references,
						stepRows);
				if (iteration.stepCount() < 1) {
					throw new Exception(
							"The selected test case is not available in data sheet.");
				}
				iterations.add(iteration);
			}
		}
		return iterations;
	}
	
	/****************************************************************
	 * @param String
	 * @param boolean
	 * @return
	 ****************************************************************/
	private boolean s2B(String s, boolean defb) {
		if (s == null || "".equals(s))
			return defb;
		return Utils.string2Bool(s);
	}
	
	/****************************************************************
	 * @param iterRow
	 * @param references
	 * @param stepRows
	 * @return
	 ****************************************************************/
	private TestIteration makeIteration(final Map iterRow, Map references,
			List<Map> stepRows) {
		Map iterParamsMap = new HashMap();
		if (iterRow != null) {
			iterParamsMap.put("ITERATION", iterRow);
		}
		List<Map> iterStepRows = substitute(stepRows, iterParamsMap);
		final List<TestStep> steps = new ArrayList<TestStep>();
		int stepIx = 0;
		for (Map stepRow : iterStepRows) {
			boolean isSelected = true;
			if (Utils.string2Bool(CONFIG.properties
					.getProperty("EnableStepSelection"))) {
				isSelected = s2B((String) stepRow.get("_selectYN"), true);
			}
			TestStep oneStep = null;
			if (isSelected) {
				/*if (ConfigParams.SINGLETON.properties.getProperty("TestDataMode").equalsIgnoreCase("excel")){
					oneStep = makeTestStep(stepRow, stepIx, iterParamsMap,
							references);
					} else*/
				if (ConfigParams.SINGLETON.properties.getProperty("TestDataMode").equalsIgnoreCase("xml")){
						oneStep = makeTestStepXML(stepRow, stepIx, iterParamsMap,
								references);
					}
			}
			if (oneStep == null) {
				//logger.trace("Step row skipped:"
						//+ StringUtils.mapToString(stepRow) + ":#" + stepIx);
				System.out.println("Step row skipped:"
						+ StringUtils.mapToString(stepRow) + ":#" + stepIx);
			} else {
				steps.add(oneStep);
				//logger.trace("Step added:" + StringUtils.mapToString(stepRow)
						//+ ":#" + stepIx);
				System.out.println("Step added:" + StringUtils.mapToString(stepRow)
						+ ":#" + stepIx);
				stepIx++;
			}
		}
		return new TestIteration() {
			public Map parameters() {
				return iterRow;
			}

			public TestStep step(int stepIx) {
				return steps.get(stepIx);
			}

			public int stepCount() {
				return steps.size();
			}
		};

	}
	
	/****************************************************************
	 * @param stepRow
	 * @param iCount
	 * @param iterParamsMap
	 * @param references
	 * @return
	 ****************************************************************/
	private TestStep makeTestStepXML(Map stepRow, int iCount, Map iterParamsMap,
			Map references) {
		final String stepName, moduleCode, actionCode, actionOutputValidation;
     	final DataRow actionParameters;
		
		Map paramSpec = null;

		if (Utils.string2Bool(CONFIG.properties
				.getProperty("EnableStepSelection"))) {
			boolean isExpected;
			isExpected = s2B((String) stepRow.get("_selectYN"), true);
			if (!isExpected)
				//logger.trace("Test Step Skipped!!");
				System.out.println("Test step skipped");
			else {
				moduleCode = (String) stepRow.get("moduleCode");
				actionCode = (String) stepRow.get("actionCode");
				if (moduleCode.equals("") && actionCode.equals("")) {
					//logger.handleError("Blank module and action codes in test file;\n step skipped at: "
							//+ (iCount + 1));
					System.out.println("Blank module and action codes in test file;\n step skipped at: "
							+ (iCount + 1));
					return null;
				}
				String name = (String) stepRow.get("stepName");
				if (name == null || name == "") {
					name = actionCode;
				}
				stepName = name;

						HashMap ParamMap = new HashMap();
						ParamMap.putAll(stepRow);
		
						// Remove all unwanted tags
						ParamMap.remove("moduleCode");
						ParamMap.remove("actionCode");
						ParamMap.remove("abortIfUnexpected");
						ParamMap.remove("_selectYN");
						ParamMap.remove("testCaseName");
						ParamMap.remove("stepName");
						actionParameters = Utils.Map2DataRow(ParamMap);

				final boolean bFailTest = Boolean.parseBoolean((String) stepRow
						.get("failTestIfUnexpected"));

				final boolean bAbortTest = Boolean
						.parseBoolean((String) stepRow
								.get("abortTestIfUnexpected"));

				actionOutputValidation = (String) stepRow
						.get("actionOutputValidation");

				return new TestStep() {
					public boolean abortTestIfUnexpected() {
						return bAbortTest;
					}

					public String actionCode() {
						return actionCode;
					}

					public String actionOutputValidation() {
						return actionOutputValidation;
					}

					public DataRow actionParameters() {

						return actionParameters;
					}

					public boolean failTestIfUnexpected() {
						return bFailTest;
					}

					public String moduleCode() {
						return moduleCode;
					}

					public String stepName() {
						return stepName;
					}

				};
			}
		}
		return null;
	}
	
	
	/*public static void main(String[] args) throws Exception{
		XmlReader xR=new XmlReader();
		/*for(String test:xR.tetsToExecute()){
			System.out.println(test);
		}*/
		//XmlReader
		/*TestCase testCase=xR.getTestCase("003_LoginTest");
		System.out.println(Integer.toString(testCase.iterationCount()));
		System.out.println(testCase.name());
		
		TestIteration testIteration=testCase.iteration(0);
		Map map=testIteration.parameters();
		int stepCount=testIteration.stepCount();
		System.out.println(stepCount);
		
		
	}*/
}//end of class
