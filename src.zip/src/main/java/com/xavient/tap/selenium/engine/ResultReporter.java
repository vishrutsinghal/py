package com.xavient.tap.selenium.engine;

import java.util.Map;

public interface ResultReporter extends TestResultTracker.Reporter {
	public void open(Map headers);

	public void close();
}
