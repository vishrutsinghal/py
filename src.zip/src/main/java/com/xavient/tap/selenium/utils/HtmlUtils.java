package com.xavient.tap.selenium.utils;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class HtmlUtils {
	String tblClass;

	public static HtmlUtils htmlUtils;

	public static synchronized HtmlUtils getInstance() {
		if (htmlUtils == null) {
			htmlUtils = new HtmlUtils();
		}
		return htmlUtils;
	}

	private HtmlUtils() {
		tblClass = "data";
	}

	/**
	 * @param Object
	 * @return
	 */
	public String toHtml(Object o) {
		try {
			return any2Html(o);
		} catch (Exception e) {
			return "#Error:" + e.getMessage().toString();
		}
	}

	/****************************************************************
	 * @param object
	 * @return
	 ****************************************************************/
	private String any2Html(Object object) {
		if (object == null) {
			return "";
		}
		String dataType = object.getClass().getName();
		String result = null;
		if (dataType == null) {
			result = "#Nothing#";
		} else if (dataType == "java.util.HashMap"
				|| dataType == "iTAF.utils.DataRow") {
			result = map2Table((Map<Object, Object>) object, tblClass);
		} else if (dataType == "java.lang.Object") {
			result = object.toString();
		} else {
			result = StringUtils.toString(object);
		}
		return result;
	}

	/****************************************************************
	 * @param object
	 * @param className
	 * @return
	 ****************************************************************/
	public String map2Table(Map<Object, Object> object, String className) {
		//To Fix the Sonar critical issue : Performance - Method concatenates strings using + in a loop
		StringBuilder s = new StringBuilder();
		s.append("<table class='" + className + "'><tr>");
		//String s = "<table class='" + className + "'><tr>";
		//Set<Object> keys = object.keySet();
		//Sonar Fix :  Performance - Inefficient use of keySet iterator instead of entrySet iterator
		Set<Entry<Object, Object>> keys = object.entrySet();
		for(Iterator<Entry<Object, Object>> i = keys.iterator(); i.hasNext(); ){
			Entry e = (Entry)i.next();
			Object key = e.getKey();
			s = s.append("<th>").append(key).append("</th>");
			//s = s + "<th>" + key + "</th>";
		}
		s = s.append("</tr>");
		s = s.append("<tr>");
		//s = s + "</tr>";
		//s = s + "<tr>";
		for(Iterator<Entry<Object, Object>> i = keys.iterator(); i.hasNext(); ){
			Entry e = (Entry)i.next();
			Object value = e.getValue();
			s = s.append("<td>").append(toHtml(value)).append("</td>");
			//s = s + "<td>" + toHtml(object.get(key)) + "</td>";
		}
		s = s.append("</tr></table>");
		//s = s + "</tr></table>";

		return s.toString();
	}
}
