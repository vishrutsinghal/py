package com.xavient.tap.selenium.harness;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.xavient.tap.selenium.harness.ConfigParams;

public class ResourcePaths {
	String autoHome;
	String testFile;
	String testName;

	/****************************************************************
	 * @param sAutoHome
	 ****************************************************************/
	public ResourcePaths(String sAutoHome) {
		this.autoHome = sAutoHome;
	}

	/****************************************************************
	 * @param sAutoHome
	 * @param sTestFile
	 * @param sTestName
	 ****************************************************************/
	public ResourcePaths(String sAutoHome, String sTestFile, String sTestName) {
		this.autoHome = sAutoHome;
		this.testFile = sTestFile;
		this.testName = sTestName;
	}

	/****************************************************************
	 * @param sFolderPath
	 * @param sFileName
	 * @return
	 ****************************************************************/
	public String makePath(String sFolderPath, String sFileName) {
		return makeLocalPath(sFolderPath, sFileName);
	}

	/****************************************************************
	 * @param sFolderPath
	 * @param sFileName
	 * @return
	 ****************************************************************/
	public String makeLocalPath(String sFolderPath, String sFileName) {
		return autoHome + "/" + sFolderPath + "/" + sFileName;
	}

	/****************************************************************
	 * @return
	 ****************************************************************/
	public String getTestFile() {
		updateExcelData(testName, "Yes");
		return ConfigParams.SINGLETON.properties.getProperty("DataTable");
	}

	public String getTestName() {
		return testName;
	}

	/****************************************************************
	 * @Method Name : updateExcelData
	 * @Method Description : updates '_selectYN' filed in excel to enable or disable the current row of execution
	 * @param strTestName
	 * @param sUpdateVal
	 ****************************************************************/
	public void updateExcelData(String strTestName, String sUpdateVal) {
		String sFileName, sSheetName, sUpdateFld, sConditionFld, sConditionVal;
		sFileName = ConfigParams.SINGLETON.properties.getProperty("DataTable");
		sSheetName = "[Steps$]";
		sConditionFld = "testCaseName";
		sConditionVal = strTestName;
		sUpdateFld = "_selectYN";
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		Connection con = null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager
					.getConnection("jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="
							+ sFileName + ";READONLY=false");

			
			String sMainQry = "UPDATE " + sSheetName + " SET " + sUpdateFld
					+ "=?";
			String sWhereClause = ";";
			pstmt = con.prepareStatement(sMainQry + sWhereClause);
			pstmt.setString(1, "No");
			int changedRows = pstmt.executeUpdate();

			sMainQry = "UPDATE " + sSheetName + " SET " + sUpdateFld + "=?";
			sWhereClause = ";";
			sWhereClause = " Where " + sConditionFld + "=?;";
			pstmt1 = con.prepareStatement(sMainQry + sWhereClause);
			pstmt1.setString(1, sUpdateVal);
			pstmt1.setString(2, sConditionVal);
			int changedRows1 = pstmt1.executeUpdate();
			System.out.println("Tcom.unionbank.qel Rows Updated= "
					+ changedRows1);

			//pstmt.close();
			//con.close();
		} catch (Exception ex) {
			System.err.print("Exception: " + ex);
		}finally{
			if(pstmt!=null){
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt1!=null){
				try {
					pstmt1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null){
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
