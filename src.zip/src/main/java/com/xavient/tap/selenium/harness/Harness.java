package com.xavient.tap.selenium.harness;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.xavient.tap.selenium.common.FileUtilities;
import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.engine.Engine;
import com.xavient.tap.selenium.engine.ResultReporter;
import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.engine.TestResultLogger;
import com.xavient.tap.selenium.engine.TestSet;
import com.xavient.tap.selenium.engine.TestCaseRunner.tcMaker;
import com.xavient.tap.selenium.engine.TestResultTracker.Reporter;
import com.xavient.tap.selenium.qcRESTConnection.qcRESTconnection;
import com.xavient.tap.selenium.reporting.ManagingReporter;
import com.xavient.tap.selenium.serializer.CDTAccess;
import com.xavient.tap.selenium.utils.FileUtils;
import com.xavient.tap.selenium.utils.Logger;

public class Harness {
	public ConfigParams CONFIG = ConfigParams.SINGLETON;
	public qcRESTconnection qcConnect = new qcRESTconnection();
	public Logger logger;
	public String G_AUTO_HOME = "";
	public TestResult qcResult;
	private ResourcePaths resourcePaths;
	public Reporter reporter;
	
	public static int passedCount=0;
	public static int failedCount=0;
	public static int warningCount=0;
	public static int notCompletedCount=0;


	/****************************************************************
	 * @Method Name : runHarness
	 * @Method Description : initialize the loggers, reports 
	 * @param runName
	 * @throws Exception
	 ****************************************************************/
	public void runHarness(String runName) throws Exception {
		try {
			initialize(runName);
			int interTcDelay;
			interTcDelay = Integer.parseInt(CONFIG.properties
					.getProperty("InterTestCaseDelay"));
			if (interTcDelay != 0) {
				try {
					Thread.sleep(interTcDelay * 1000);
					logger.trace("Test case delay:" + interTcDelay);
				} catch (InterruptedException e) {
					logger.handleError("Exception caught : " + e.getMessage());
				}
			}
			String message = run(runName);
			if (!message.equals("")) {
				logger.error("Harness Error:" + message);
			}
			logger.closeLoggers();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}

	/****************************************************************
	 * @Method Name : getAutoHome
	 * @Method Description : Load AutoHome from configuration properties 
	 * @return String 
	 ****************************************************************/
	private String getAutoHome() {

		if (!G_AUTO_HOME.equals("")) {
			return G_AUTO_HOME;
		}
		G_AUTO_HOME = CONFIG.properties.getProperty("AutoHome");
		return G_AUTO_HOME;
	}

	/****************************************************************
	 * @Method Name : determineResultsFolder
	 * @Method Description : returns result folder path
	 * @param resultsFolder
	 * @return String
	 ****************************************************************/
	private String determineResultsFolder(String resultsFolder) {
		if (resultsFolder.equals("")) {
			resultsFolder = FileUtils.getTempPath();
		}
		//To Fix the critical sonar issue : Dodgy - Redundant nullcheck of value known to be non-null 
		/*if (resultsFolder == null) {
			logger.error("Cant determine results folder");
			return null;
		}*/
		return resultsFolder;
	}

	private void initializeLogs(String resultsFolder) {
		logger.trace("InitializeLogs(" + resultsFolder + ")");
	}

	/****************************************************************
	 * @Method Name : makeReporter
	 * @Method Description : Creates 3 types of reports - ScreenDump, HtmlEvent, ExcelReport 
	 * @param resultFolder
	 * @return
	 ****************************************************************/
	private Reporter makeReporter(String resultFolder) {
		String reporterSelection = CONFIG.properties
				.getProperty("ReporterSelection");
		String[] reportsSelected = null;
		if (reporterSelection != null && !reporterSelection.equals("")) {
			reporterSelection = reporterSelection.trim();
			reportsSelected = reporterSelection.split(",");
		}
		return new ManagingReporter(resultFolder, reportsSelected,
				resourcePaths);
	}

	/****************************************************************
	 * @return
	 * @throws Exception
	 ****************************************************************/
	private TestCase getTestCase() throws Exception {
		logger.trace("GetTestCase()");
		CDTAccess oDataTableAccess = new CDTAccess(resourcePaths);
		TestCaseAccess oAccess = new TestCaseAccess(resourcePaths,
				oDataTableAccess);
		return oAccess.getTestCase();
	}

	/****************************************************************
	 * @param runName
	 * @return
	 ****************************************************************/
	public String run(String runName) {
		((ResultReporter) reporter).open(ConfigParams.getAllProperties());
		String result = runTest(runName, reporter);
		((ResultReporter) reporter).close();
		return result;
	}

	/****************************************************************
	 * @param runName
	 * @param reporter
	 * @return
	 ****************************************************************/
	public String runTest(final String runName, Reporter reporter) {
		AppDriver appDriver = null;
		String message = "";
		Engine engine = null;
		try {
			appDriver = new AppLoader().loadApp();
		} catch (Exception e) {
			e.printStackTrace();
			logger.handleError("Failed to LoadAppDriver" + e);
			message = "Failed to LoadAppDriver" + e;
		}

		// creating list of reporters
		List<Reporter> reporters = new ArrayList<Reporter>();
		reporters.add(reporter);
		try {
			engine = new Engine(runName, (AppDriver) appDriver, reporters);
		} catch (Exception e) {
			logger.handleError("FactoryEngine:" + e);
			message = "FactoryEngine:" + e;
		}

		tcMaker tcMaker = new tcMaker() {
			public TestCase make() throws Exception {
				return getTestCase();
			}

			public String toString() {
				return runName;
			}
		};
		try {

			qcResult = engine.runTestCase(tcMaker, runName);
			if(qcResult.finalRsType.toString().equalsIgnoreCase("Passed")){
				addPassCount();
				}else if(qcResult.finalRsType.toString().equalsIgnoreCase("Failed")){
				addFailCount();
				}else if(qcResult.finalRsType.toString().equalsIgnoreCase("WARNING")){
				addWaringCount();
				}
				else{
				addNotCompletedCount();
				}
			if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
				qcConnect.updateTestCaseStatus(qcResult);
				qcConnect.createDefect(qcResult);
				TestResultLogger.testSteps.clear();	
				assignStepNumber();
			}

		} catch (Exception e) {
			logger.handleError("RunTestCase:" + e);
			message = "RunTestCase:" + e;
		}
		return message;
	}
	
	
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	//**Start
	
	public static void addPassCount(){
		passedCount=passedCount+1;
	}
	public static void addFailCount(){
		failedCount=failedCount+1;
	}
	public static void addWaringCount(){
		warningCount=warningCount+1;
	}
	public static void addNotCompletedCount(){
		notCompletedCount=notCompletedCount+1;
	}
	public static void assignStepNumber(){
		TestResultLogger.stepNumber = 1;
	}
	//**End
	/****************************************************************
	 * @param testCaseToExecute
	 * @throws Exception 
	 ****************************************************************/
	public void runTestSet(String testCaseToExecute) throws Exception {
		try {
			runTestCase(testCaseToExecute);
		} finally {
			if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
			qcConnect.logout();
			}
		}
	}

	public void runTestSet() throws Exception {
		String currentTestCase="";
		
		String testCaseName = CONFIG.properties.getProperty(
				"testcasename");
		
        try {
        	
        	if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
        		System.out.println("Getting the test instance name from QC and executing");
        		//Using REST
        	HashMap<String,String> testCases = qcConnect.connectToQc();
        	Set set = testCases.entrySet();
        	Iterator i = set.iterator();
        	while(i.hasNext()) {
                Map.Entry me = (Map.Entry)i.next();
                currentTestCase = me.getValue().toString();
        		System.out.println("Executing "+currentTestCase);
        		runTestCase(currentTestCase);
        		}
        	
        	}
        	//Condition to execute scripts in XML Batch mode
        	else if(CONFIG.properties.getProperty("QCConnection").toLowerCase().equalsIgnoreCase("false") && CONFIG.properties.getProperty("TestDataMode").toLowerCase().equalsIgnoreCase("xml")) { 
					System.out.println("Executing from XML **********");
					try {
						FileUtilities fileUtilities = new FileUtilities();
						File fXmlFile = fileUtilities.loadFile(
								ConfigParams.SINGLETON.properties
										.getProperty("TestDataXml"));
						DocumentBuilderFactory dbFactory = DocumentBuilderFactory
								.newInstance();
						DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
						Document doc = dBuilder.parse(fXmlFile);
			
						doc.getDocumentElement().normalize();
			
						/*System.out.println("Root element :"
								+ doc.getDocumentElement().getNodeName());*/
			
			
						Element rootElement = doc.getDocumentElement();
						NodeList children = rootElement.getChildNodes();
						Node current = null;
						int count = children.getLength();
						//System.out.println("Count : " + count);
			
						for (int i = 0; i < count; i++) {
							current = children.item(i);
							if (current.getNodeType() == Node.ELEMENT_NODE) {
								Element element = (Element) current;
			
								String secondLevelTagName = element.getAttribute("name");
								
								//Execute the test case if the attribute "execute" of test case name is "yes" 
								if(element.getAttribute("execute").toString().equalsIgnoreCase("yes")){
									currentTestCase = element.getAttribute("name");
									//System.out.println("Executing " + currentTestCase);
									runTestCase(currentTestCase);
								}
								
							}
						}
					}catch (ParserConfigurationException e) {
						e.printStackTrace();
					} catch (SAXException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				
			}	
        	else if (null != testCaseName  && !testCaseName.equals("")) {
        	  System.out.println("Executing the give test case ");
        	  runTestCase(CONFIG.properties.getProperty(
						"testcasename"));
			
		}else{
			System.out.println("Executing from Excel");
        	  TestSet ts = new ExcelTestSet();
  			int tsCount = ts.testInstanceCount();

  			List<String> selectedTestCases = new ArrayList<String>();
  			for (int ix = 0; ix < tsCount; ix++) {
  				selectedTestCases.add(ts.testInstance(ix).getInstanceName()
  						.toString());
  			}
  			
  			for (String runTestName : selectedTestCases) {
  				System.out.println(runTestName);
				runTestCase(runTestName);
          }
         }
        } catch (Exception e) {
        	e.printStackTrace();
        	logger.error("Error while executing test case "+currentTestCase+", "+e.getMessage());
		}finally {
			if (Boolean.parseBoolean(CONFIG.properties.getProperty(
					"QCConnection").toLowerCase())) {
			boolean logOff= qcConnect.logout();
			if(logOff){
				System.out.println("Succesfully logged out from QC");
			}
			}
		}
	}

	/****************************************************************
	 * @param instanceName
	 ****************************************************************/
	public void runTestCase(String instanceName) {
		try {
			runHarness(instanceName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/****************************************************************
	 * @param testInstanceName
	 ****************************************************************/
	public void initialize(String testInstanceName) {
		CONFIG = ConfigParams.SINGLETON;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH-mm-ss");
		Date date = new Date();
		logger = Logger.getInstance(testInstanceName + "-"
				+ dateFormat.format(date).toString() + ".log");
		logger.trace("Initialize()");
		String autoHome = getAutoHome();
		logger.trace("AutoHome:" + autoHome);
		if (autoHome.equals("")) {
			logger.error("AUTO_HOME is invalid:" + autoHome);
			return;
		}
		resourcePaths = new ResourcePaths(autoHome, testInstanceName,
				testInstanceName);

		String resultsFolder = determineResultsFolder(CONFIG.properties
				.getProperty("ResultsRootFolder"));
		if (!FileUtils.makePath(resultsFolder)) {
			logger.error("Cant create/access results folder:" + resultsFolder);
		}
		CONFIG.properties.setProperty("ResultsFolder", resultsFolder);
		initializeLogs(resultsFolder);
		String workFolder = CONFIG.properties.getProperty("WorkFolder");
		if (workFolder == null || !(FileUtils.makePath(workFolder))) {
			logger.error("Can't create/access work folder:" + workFolder);

		}
		reporter = makeReporter(resultsFolder);
	}
}
