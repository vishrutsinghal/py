package com.xavient.tap.selenium.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.xavient.tap.selenium.harness.ConfigParams;

public class SleepUtils {

	public static synchronized SleepUtils getInstance() {
		if (SLEEP_UTILS == null) {
			SLEEP_UTILS = new SleepUtils();
		}
		return SLEEP_UTILS;
	}

	/****************************************************************
	 * @param level
	 * @return
	 ****************************************************************/
	public boolean sleep(TimeSlab level) {
		logger.trace("Sleep:" + level.toString());
		boolean sleep = false;
		int timer = interval(level.getLevel());
		if (timer > 0) {
			try {
				Thread.sleep(timer);
			} catch (InterruptedException e) {
				logger.handleError("Error caught : " + e.getMessage());
			}
			sleep = true;
		}
		logger.trace("Slept:" + level + "," + timer);
		return sleep;
	}

	public enum TimeSlab {
		YIELD("YIELD", 0), LOW("LOW", 1), MEDIUM("MEDIUM", 2), HIGH("HIGH", 3);

		private TimeSlab(String n, int lvl) {
			name = n;
			level = lvl;
		}

		public int getLevel() {
			return level;
		}

		public String toString() {
			return name;
		}

		public final int level;
		public final String name;
	}

	/****************************************************************
	 * @param int lvl
	 * @return
	 ****************************************************************/
	public int interval(int lvl) {
		int timer = 0;
		List<Integer> timerSlabs = getTimerSlabs();
		if (lvl >= 0) {
			if (lvl <= timerSlabs.size())
				timer = timerSlabs.get(lvl);
			else
				timer = timerSlabs.get(timerSlabs.size() - 1)
						* (lvl - timerSlabs.size() + 1);

		}
		if (timer < 0)
			timer = 0;
		return timer;
	}

	/**
	 * @return List
	 */
	public List<Integer> getTimerSlabs() {
		if (!this.timerSlabs.isEmpty()) {
			return this.timerSlabs;
		}
		String slabs = ConfigParams.SINGLETON.properties
				.getProperty("SleepTimerSlabs");
		//Sonar Fix : Broken Null Check
		if (slabs != "" || slabs != null) {
			for (String temp : slabs.trim().split(",")) {
				this.timerSlabs.add(Integer.parseInt(temp));
			}
		}
		if (this.timerSlabs.isEmpty()) {
			this.timerSlabs = Arrays.asList(new Integer[] { 500, 3000, 10000,
					20000 });
		}
		logger.trace("TimerSlabs Used=" + StringUtils.toString(this.timerSlabs));
		return this.timerSlabs;
	}

	public String toString() {
		return "SleepUtils()";
	}

	public Logger logger = new Logger(this);
	private static SleepUtils SLEEP_UTILS;
	private List<Integer> timerSlabs = new ArrayList<Integer>();

}
