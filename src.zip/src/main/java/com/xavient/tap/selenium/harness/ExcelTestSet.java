package com.xavient.tap.selenium.harness;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.engine.TestInstance;
import com.xavient.tap.selenium.engine.TestIteration;
import com.xavient.tap.selenium.engine.TestSet;
import com.xavient.tap.selenium.serializer.DTAccess;
import com.xavient.tap.selenium.utils.Utils;

public class ExcelTestSet implements TestSet {
	final static String testSetSheet = "TestSet";

	private class TestInstanceInfo {
		String testCaseName;
		int rowNum;

		/****************************************************************
		 * @param testInstances
		 ****************************************************************/
		public TestInstanceInfo(List<Map> testInstances) {
			for (int ix = 0; ix < testInstances.size(); ix++) {
				if (!Utils.string2Bool(((String) testInstances.get(ix).get(
						"SelectYN")))) {
					continue;
				}
				TestInstanceInfo testInstance = new TestInstanceInfo();
				testInstance.rowNum = ix + 1;
				testInstance.testCaseName = (String) testInstances.get(ix).get(
						"TestCase Name");
				testInstanceInfo.add(testInstance);
			}
		}

		public TestInstanceInfo() {
		}
	}

	private List<TestInstanceInfo> testInstanceInfo = new ArrayList<TestInstanceInfo>();

	static List<Map> testInstances = new ArrayList<Map>();

	public ConfigParams CONFIG = ConfigParams.SINGLETON;

	public TestInstance testInstance(final int ix) {
		testInstanceInfo.get(ix);
		return new TestInstance() {

			public TestCase testCase() {
				return null;
			}

			public String description() {
				return null;
			}

			public String getInstanceName() {
				return testInstanceInfo.get(ix).testCaseName;
			}

			public TestIteration[] iterations() {
				return null;
			}
		};
	}

	
	public int testInstanceCount() {
		int ix = 0;
		DTAccess dtAccess = new DTAccess(
				CONFIG.properties.getProperty("ExcelTestSet"));
		readTestSheet(dtAccess);
		new TestInstanceInfo(testInstances);
		return testInstanceInfo.size();
	}
	
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void readTestSheet(DTAccess dtAccess){
		testInstances = dtAccess.readSheet(testSetSheet);
	}
}
