package com.xavient.tap.selenium.tstng;

import java.util.ArrayList;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;

import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.harness.AppLoader;
import com.xavient.tap.selenium.utils.DataRow;

public class TestFactory2 {
	
	
	
	
	  
	  @Factory(dataProvider="dp")
	  public Object[] createInstances(AppDriver appDriver,String moduleN,String actionCode,DataRow in,DataRow out) {
		
		
		
		
		return new Object[] {new WebStepRunner(0,appDriver,moduleN,"",actionCode,in,out)};
	  }
	
	@DataProvider(name="dp")
	public static Object[][] dataProvider(ITestContext context) {
		DataRow dr1=new DataRow();
		DataRow dr2=new DataRow();
		DataRow dr3=new DataRow();
		DataRow dr4=new DataRow();
		DataRow dr5=new DataRow();
		String param = context.getCurrentXmlTest().getParameter("testName");
		AppDriver appDriver=null;
		if(param.equals("LoginTest_001")){
			
			appDriver=new AppLoader().loadApp();
			dr1.put("url", "https://www.gmail.com");
			//result2.add(new WebStepRunner(appDriver,"UB","launchApp",dr1,dr2));
			
			 dr3.put("Login-password", "1@34567f");
			 dr3.put("Login-userID", "qy92614");
			//result2.add(new WebStepRunner(appDriver,"UB","login",dr3,dr2));
			
			 dr4.put("SignOut", "Sign Out");
			//result2.add(new WebStepRunner(appDriver,"UB","logout",dr4,dr2));
			 Object[][] dataArray= {
						{appDriver,"UB","launchApp",dr1,dr2},
						{appDriver,"UB","login",dr3,dr2},
						{appDriver,"UB","logout",dr4,dr2},
						
				};
			 return dataArray;
		}else{
			appDriver=new AppLoader().loadApp();
			dr5.put("url", "https://www.google.com");
			Object[][] dataArray= {
					{appDriver,"UB1","launchApp",dr5,dr2},
					
			};
		 return dataArray;
		}
		
		
		
		
	}


}
