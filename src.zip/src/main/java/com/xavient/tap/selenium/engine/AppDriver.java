package com.xavient.tap.selenium.engine;

import java.util.Map;

import com.xavient.tap.selenium.utils.DataRow;

public interface AppDriver {
	public void initialize(TestResultLogger resultLogger);

	public void perform(String moduleCode, String actionCode, DataRow input,
			Map<String, String> output);

	public void recover();

}