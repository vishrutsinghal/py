package com.xavient.tap.selenium.utils;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Pattern;


public class StringUtils {

	/****************************************************************
	 * @param Object o
	 * @return
	 ****************************************************************/
	public static String toString(Object o) {
		String result = "";
		if (o == null) {
			return null;
		}
		try {
			//Convert Map to String 
			result = mapToString((Map<Object, Object>) o);
		} catch (ClassCastException oEx) {
			try {
				//Convert object array to string
				result = objectArrayToString((Object[]) o);
			} catch (ClassCastException e) {
				try {
					result = o.toString();
				} catch (ClassCastException ex) {
					result = exceptionToString((Exception[]) o);
				}
			}
		}
		return result;
	}

	/****************************************************************
	 * @Method Name : mapToString
	 * @Method Description : Convert Map to String Value
	 * @param Object o
	 * @return String
	 ****************************************************************/
	public static String mapToString(Map<Object, Object> o) {
		//String resultStr = "";
		StringBuilder resultStr = new StringBuilder();
		if (!o.isEmpty()) {
			//Sonar Fix :  Performance - Inefficient use of keySet iterator instead of entrySet iterator
			Set<Entry<Object, Object>> keys = o.entrySet();
			//Set<Object> keys = o.keySet();
			//for (Object key : keys) {
			for(Iterator<Entry<Object, Object>> i = keys.iterator(); i.hasNext(); ){
				Entry e = (Entry)i.next();
				//To Fix the Sonar critical issue : Performance - Method concatenates strings using + in a loop 
				resultStr = resultStr.append(e.getKey().toString()).append("=").append(e.getValue().toString()).append(" , ");
				//resultStr = resultStr + key.toString() + " = " + o.get(key)
					//	+ " , ";
			}
			return "{ " + resultStr.substring(0, resultStr.length() - 3).toString() + " }";
		}
		return "";
	}

	/****************************************************************
	 * @Method Name : objectArrayToString
	 * @Method Description : Convert Object Array  to String Value
	 * @param objArray
	 * @return String
	 ****************************************************************/
	public static String objectArrayToString(Object[] objArray) {
		//String resultStr = "";
		StringBuilder resultStr = new StringBuilder();
		for (Object obj : objArray) {
			//To Fix the Sonar critical issue : Performance - Method concatenates strings using + in a loop
			resultStr = resultStr.append( obj.toString()).append(" , ");
			//resultStr = resultStr + obj.toString() + " , ";
		}
		return resultStr.substring(0, resultStr.length() - 3).toString();
	}

	/****************************************************************
	 * @Method Name : stringArrayToString
	 * @Method Description : Convert String Array  to String Value
	 * @param inputs
	 * @return String
	 ****************************************************************/
	public static String stringArrayToString(String... inputs) {
		//String conCatValue = "";
		StringBuilder conCatValue = new StringBuilder();
		for (String input : inputs) {
			//To Fix the Sonar critical issue : Performance - Method concatenates strings using + in a loop
			conCatValue = conCatValue.append(input);
			//conCatValue = conCatValue + input;
		}
		return conCatValue.toString();

	}

	/****************************************************************
	 * @Method Name : exceptionToString
	 * @Method Description : Convert Exception to String
	 * @param exception
	 * @return
	 ****************************************************************/
	public static String exceptionToString(Exception... exception) {
		//return exception.toString();
		return Arrays.toString(exception);
	}

	/****************************************************************
	 * @Method Name : pattern
	 * @Method Description : 
	 * @param patternStr
	 * @param isExactMatch
	 * @param bIgnoreCase
	 * @return Pattern
	 ****************************************************************/
	public static Pattern pattern(String patternStr, boolean isExactMatch,
			boolean bIgnoreCase) {
		Pattern regEx;
		if (isExactMatch) {
			regEx = Pattern.compile("^" + patternStr + "$");
		} else {
			regEx = Pattern.compile(patternStr);
		}
		return regEx;
	}

	/****************************************************************
	 * @param valueToBeMatched
	 * @param pattern
	 * @return
	 ****************************************************************/
	public static boolean match(String valueToBeMatched, Pattern pattern) {
		return pattern.matcher(valueToBeMatched).find();
	}

	/****************************************************************
	 * @Method Name : isValidString
	 * @Method Description : Check if the string is empty
	 * @param cString
	 * @return True or False based on the string is empty or not
	 ****************************************************************/
	public static boolean isValidString(String cString) {
		boolean isValidString = true;
		try {
			if (cString.isEmpty()) {
				isValidString = false;
			}
		} catch (NullPointerException e) {
			isValidString = false;
		}
		return isValidString;
	}

	/****************************************************************
	 * @Method Name : isStringArrayIsSorted
	 * @Method Description : Check if the String array is sorted or not
	 * @param stringArray
	 * @return True or False based on the string array is sorted or not
	 ****************************************************************/
	public boolean isStringArrayIsSorted(String[] stringArray) {
		boolean isSorted = true;
		for (int i = 0; i < stringArray.length - 1; i++) {
			if (stringArray[i].compareToIgnoreCase(stringArray[i + 1]) > 0) {
				isSorted = false;
			}
		}
		return isSorted;
	}

	/****************************************************************
	 * @Method Name : compareTwoArrays
	 * @Method Description : Compares Expected Array and Actual Array
	 * @param expectedArray
	 * @param actualArray
	 * @return True or False 
	 ****************************************************************/
	public boolean compareTwoArrays(String[] expectedArray, String[] actualArray) {
		boolean result = true;
		boolean foundActual = false;
		for (int i = 0; i < actualArray.length; i++) {
			in: for (int j = 0; j < expectedArray.length; j++) {
				if (actualArray[i].trim().equalsIgnoreCase(
						expectedArray[j].trim())) {
					foundActual = true;
					break in;
				}
			}
			if (!foundActual) {
				result = false;
			}
		}

		return result;
	}

	/****************************************************************
	 * @Method Name : compareTwoArraysOrder
	 * @Method Description : Compares Expected Array and Actual Array order
	 * @param expectedArray
	 * @param actualArray
	 * @return True or False based on the order of two arrays is same or not
	 ****************************************************************/
	public boolean compareTwoArraysOrder(String[] expectedArray,
			String[] actualArray) {
		boolean foundActual = true;
		if (expectedArray.length != actualArray.length) {
			foundActual = false;
		} else {
			for (int j = 0; j < expectedArray.length; j++) {
				if (!actualArray[j].equalsIgnoreCase(expectedArray[j])) {
					foundActual = false;
					break;
				}
			}
		}
		return foundActual;
	}

	
	/****************************************************************
	 * @Method Name : getRandomAlphaNumericValue
	 * @param numberOfChar
	 * @return String
	 ****************************************************************/
	public String getRandomAlphaNumericValue(int numberOfChar) {
		StringBuilder abc = new StringBuilder();
		abc.append("abcdefghij1234klmnopqrstuvwxyz");
		//String abc = "abcdefghij1234klmnopqrstuvwxyz";
		StringBuilder xyz = new StringBuilder();
		xyz.append("");
		//String xyz = "";
		int ilength = numberOfChar / 30;
		int j = numberOfChar % 30;
		for (int i = 0; i < ilength; i++) {
			xyz = xyz.append(abc);
		}
		xyz = xyz.append(abc.substring(0, j));
		return xyz.toString();
	}

	/****************************************************************
	 * @Method Name : getIntegerValue
	 * @param numberOfChar
	 * @return String
	 ****************************************************************/
	public String getIntegerValue(int numberOfChar) {
		StringBuilder abc = new StringBuilder();
		abc.append("1234567890");
		//String abc = "1234567890";
		StringBuilder xyz = new StringBuilder();
		xyz.append("");
		//String xyz = "";
		int ilength = numberOfChar / 10;
		int j = numberOfChar % 10;
		for (int i = 0; i < ilength; i++) {
			xyz = xyz.append(abc);
		}
		xyz = xyz.append(abc.substring(0, j));
		return xyz.toString();
	}

	/****************************************************************
	 * @Method Name : dolloarStringToDouble
	 * @Method Description : Convert dollar string to Double value 
	 * @param dollarValue
	 * @return
	 ****************************************************************/
	public double dolloarStringToDouble(String dollarValue) {
		Double dollarAmt = 0.0;
		try {
			String removingDollarValue = dollarValue.replace("$", "");
			String removingAUDValue = removingDollarValue.replaceAll("AUD", "");
			String value = removingAUDValue.replace(",", "");
			dollarAmt = Double.parseDouble(value);
		} catch (Exception e) {

		}
		return dollarAmt;
	}
}
