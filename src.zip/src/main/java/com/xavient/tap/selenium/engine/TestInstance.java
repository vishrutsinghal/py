package com.xavient.tap.selenium.engine;

public interface TestInstance {
	public TestCase testCase();

	public TestIteration[] iterations();

	public String description();

	public String getInstanceName();
}
