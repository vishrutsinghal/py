package com.xavient.tap.selenium.harness;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.xavient.tap.selenium.common.FileUtilities;

public class TitleParams {
	public final Properties properties = new Properties();
	public static final TitleParams SINGLETON = new TitleParams();
	FileInputStream fileIn = null;
	FileUtilities fileUtilities = new FileUtilities();

	public TitleParams() {
		String workingDir = System.getProperty("user.dir");
		File f = fileUtilities.loadFile(workingDir+"\\src\\main\\config\\Titles.properties");
		if(f.exists()){	
		load(workingDir+"\\src\\main\\config\\Titles.properties");
		}
	}

	/****************************************************************
	 * @param sFileName
	 ****************************************************************/
	public void load(String sFileName) {
		try {
			//load the PageTitle.properties file
			//To Fix Sonar Critical issue : Bad practice - Method may fail to close stream 
			fileIn = new FileInputStream(sFileName);
			properties.load(fileIn);
		} catch (IOException e) {
			System.err.println("get property error:" + e.getMessage() + ":"
					+ sFileName);
		}finally{
			try {
				fileIn.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/****************************************************************
	 * @return Map
	 ****************************************************************/
	public static Map<String, String> getAllProperties() {
		HashMap<String, String> propertyMap = new HashMap<String, String>();
		//load each property and puti it in a hashmap
		Collection<Object> keys = SINGLETON.properties.keySet();
		for (Object key : keys) {
			propertyMap.put(key.toString(), SINGLETON.properties.get(key)
					.toString());
		}
		return propertyMap;
	}
}
