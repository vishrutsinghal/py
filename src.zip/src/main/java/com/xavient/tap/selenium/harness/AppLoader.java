package com.xavient.tap.selenium.harness;

import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.utils.Logger;

public class AppLoader {

	Logger logger = new Logger(this);
	ConfigParams CONFIG = ConfigParams.SINGLETON;

	/****************************************************************
	 * @Method Name : loadApp
	 * @Method Description : Load the AppDriver 
	 * @return
	 ****************************************************************/
	public AppDriver loadApp() {
		AppDriver driver = null;

		//logger.trace("LoadApp()");
		//Get the driver name from configuration properties
		String startUp = CONFIG.properties.getProperty("AppDriverBootStrap");
		//logger.debug("AppDriverBootStrap: " + startUp);
		try {
			ClassLoader appLoader = ClassLoader.getSystemClassLoader();
			Class appDriver = appLoader.loadClass(startUp);
			//create a new instance of AppDriver class
			driver = (AppDriver) appDriver.newInstance();
		} catch (Exception e) {
			//logger.handleError("Error in loading AppDriver:" + startUp, e);
		}
		return driver;
	}

	public String toString() {
		return "AppLoader()";
	}

}
