package com.xavient.tap.selenium.engine;

import java.util.Arrays;
import java.util.List;

import com.xavient.tap.selenium.engine.TestCaseRunner.tcMaker;
import com.xavient.tap.selenium.engine.TestResultTracker.Reporter;
import com.xavient.tap.selenium.utils.Logger;

@SuppressWarnings("unused")
public class Engine {
	AppDriver appDriver;
	TestResultTracker resultTracker;
	TestResultLogger RPT;
	Logger logger;

	public Engine(String runName, AppDriver appDriver,
			List<Reporter> resultReporter) {
		this.appDriver = appDriver;
		this.resultTracker = new TestResultTracker(resultReporter);
		this.RPT = new TestResultLogger(this.resultTracker);
		appDriver.initialize(this.RPT);
	}

	/****************************************************************
	 * @Method Name : runTestCase
	 * @param tcMaker
	 * @param TCName
	 * @return
	 ****************************************************************/
	public TestResult runTestCase(tcMaker tcMaker, String TCName) {
		TestCaseRunner oTestCaseRunner = new TestCaseRunner(appDriver,
				resultTracker, RPT);
		return oTestCaseRunner.runTestCase(tcMaker, TCName);

	}
}
