package com.xavient.tap.selenium.serializer;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.harness.ResourcePaths;
import com.xavient.tap.selenium.utils.FileUtils;
import com.xavient.tap.selenium.utils.FrameworkException;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.Utils;

import jxl.read.biff.BiffException;

public class CDTAccess {

	public CDTAccess(ResourcePaths resourcePaths) {
		this.resourcePaths = resourcePaths;
	}

	/****************************************************************
	 * @param moduleCode
	 * @return
	 ****************************************************************/
	public ModuleDataTableAccess getModuleDataTableAccess(String moduleCode) {
		moduleDataTableAccess = new ModuleDataTableAccess();
		moduleDataTableAccess.moduleCode = moduleCode;
		return moduleDataTableAccess;
	}

	class ModuleDataTableAccess {
		String moduleCode;

		/****************************************************************
		 * @param actionCode
		 * @param rowSelector
		 * @return
		 ****************************************************************/
		public List<Map> selectRows(String actionCode, String rowSelector) {
			logger.trace("SelectRows(" + actionCode + "," + rowSelector + ")");
			List<Map> data = null;
			try {
				String filePath = getFilePath(actionCode);
				if (filePath == null) { // changed .equals to ==
					throw new FrameworkException("");
				}
				data = new DTAccess(filePath).readSelectedRows(actionCode,
						rowSelector);
			} catch (FrameworkException e) {
				logger.handleError("Exception caught when reading row with selector "
						+ rowSelector);
			}
			return data;
		}

		/****************************************************************
		 * @param actionCode
		 * @return
		 ****************************************************************/
		public List<Map> readRows(String actionCode) {
			List<Map> data = null;
			try {
				logger.trace("ReadRows(" + actionCode + ")");
				String sFilePath = getFilePath(actionCode);
				if (sFilePath == null) {
					throw new Exception();
				}
				DTAccess dtAccess = new DTAccess(sFilePath);
				if (dtAccess.isSheetExists(actionCode)) {
					data = dtAccess.readSheet(actionCode);
				}
			} catch (BiffException e) {
				logger.handleError("Exception caught : " + e.getMessage());
			} catch (IOException e) {
				logger.handleError("Exception caught : " + e.getMessage());
			} catch (Exception e) {
				logger.handleError("Exception caught : " + e.getMessage());
			}
			return data;
		}

		/****************************************************************
		 * @param actionCode
		 * @return
		 ****************************************************************/
		public String getFilePath(String actionCode) {
			String filePath = null;
			if (Utils.string2Bool(ConfigParams.SINGLETON.properties
					.getProperty("SearchCDTActionFiles"))) {
				filePath = tryFilePath(moduleCode, actionCode + ".xls");

			}
			if (filePath == null) {
				filePath = tryFilePath("", moduleCode + "Data.xls");
			}
			return filePath;
		}

		/****************************************************************
		 * @param branchPath
		 * @param fileName
		 * @return
		 ****************************************************************/
		public String tryFilePath(String branchPath, String fileName) {
			logger.trace("TryFilePath(" + branchPath + "," + fileName + ")");
			String folderPath = "Data", filePath;
			if (!(branchPath.equals(""))) {
				folderPath = folderPath + "/" + branchPath;
			}
			filePath = resourcePaths.makePath(folderPath, fileName);
			if ((filePath == null) || !(FileUtils.fileExists(filePath))) {
				return filePath;
			}
			logger.trace("TryFilePath(" + branchPath + "," + fileName + ")="
					+ filePath);
			return filePath;
		}
	}

	public String toString() {
		return "CDTAccess()";
	}

	private Logger logger = new Logger(this);
	private DTAccess dtAccess;
	private ResourcePaths resourcePaths;
	private ModuleDataTableAccess moduleDataTableAccess;
}
