package com.xavient.tap.selenium.utils;

@SuppressWarnings("serial")
public class FrameworkException extends RuntimeException {

	public final Object data;
	public final String msg;

	public FrameworkException(String msg, Object... data) {
		this(msg, null, data);
	}

	/**
	 * @param String msg
	 * @param Exception e
	 * @param Object data
	 */
	public FrameworkException(String msg, Exception e, Object... data) {
		super(msg, e);
		this.data = data;
		this.msg = msg;
	}

	public String toString() {
		return super.toString() + "<" + msg + "> caused by " + super.getCause();
	}
}