package com.xavient.tap.selenium.utils;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class RegExUtils {
	public interface Handler {
		public boolean handle(Matcher m);
	};

	public interface Replacements {
		public String replacement(Matcher m);
	}

	/****************************************************************
	 * @param src
	 * @param p
	 * @param r
	 * @return
	 ****************************************************************/
	public static String replace(String src, Pattern p, Replacements r) {
		StringBuffer sb = new StringBuffer();
		Matcher m = p.matcher(src);
		while (m.find()) {
			String s = r.replacement(m);
			if (s == null)
				s = m.group();
			if (s.contains("$"))
				s = "\\" + s;
			m.appendReplacement(sb, s);
		}
		m.appendTail(sb);
		return sb.toString();
	}

	/****************************************************************
	 * @param map
	 * @return
	 ****************************************************************/
	public static Replacements map2Replacements(final Map<String, String> map) {
		return new Replacements() {
			public String replacement(Matcher m) {
				return map.get(m.group());
			}
		};
	}

	/****************************************************************
	 * @param String
	 * @return
	 ****************************************************************/
	public static Pattern string2Pattern(String s) {
		Pattern patt = null;
		try {
			patt = Pattern.compile(s);
		} catch (PatternSyntaxException synexc) {
		}
		return patt;
	}

}
