package com.xavient.tap.selenium.harness;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class ConfigParams {
	public final Properties properties = new Properties();
	public static final ConfigParams SINGLETON = new ConfigParams();
	FileInputStream fileIn = null;

	public ConfigParams() {	
		String workingDir = System.getProperty("user.dir");
		System.out.println("Current working directory : " + workingDir);
		load(workingDir+"\\src\\main\\config\\configuration.properties");
	}
	
	/****************************************************************
	 * @Method Name : load
	 * @Method Description : Load all the properties from configuration.properties file
	 * @param sFileName
	 ****************************************************************/
	public void load(String sFileName) {
		try {
			//To Fix Sonar Critical issue : Bad practice - Method may fail to close stream 
			fileIn = new FileInputStream(sFileName);
			properties.load(fileIn);
		} catch (IOException e) {
			System.err.println("get property error:" + e.getMessage() + ":"
					+ sFileName);
		}finally{
			if(fileIn!=null){
				try {
					fileIn.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/****************************************************************
	 * @Method Name : getAllProperties
	 * @Method Description : Iterates through each property in configuration.properties file and put each property in Property Map
	 * @return
	 ****************************************************************/
	public static Map<String, String> getAllProperties() {
		HashMap<String, String> propertyMap = new HashMap<String, String>();
		Collection<Object> keys = SINGLETON.properties.keySet();
		for (Object key : keys) {
			propertyMap.put(key.toString(), SINGLETON.properties.get(key)
					.toString());
		}
		return propertyMap;
	}
}
