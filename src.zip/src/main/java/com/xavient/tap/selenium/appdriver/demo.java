package com.xavient.tap.selenium.appdriver;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import jxl.read.biff.BiffException;

import com.xavient.tap.selenium.actions.AppDriver;
import com.xavient.tap.selenium.engine.TestResultLogger;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.DataRow;

public class demo extends AppDriver {
	
	
	public demo() throws BiffException, IOException {
		
		super();
		
		// TODO Auto-generated constructor stub
	}
	
	String xpathobj = null;
	
	public void function(DataRow input, DataRow output) throws InterruptedException
	{
	
		
		WebDriverWait wait = new WebDriverWait(driver,180);
		
		if(driver.getTitle().contains(input.get("PageTile")))
		{
			oRPT.log("Page title","Page title", ResultType.PASSED,
					"Expected title",
					"Expected title matched", true);
		}else
		{
			oRPT.log("Page title ", "Page title ", ResultType.FAILED,
					"Expected title",
					"Expected title not matched", true);	
		}
		xpathobj="/html/body/div[3]/div[3]/div/div[1]/div/a/img";
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathobj)));
		driver.findElement(By.xpath(xpathobj)).click();
		
		if(driver.getTitle().contains(input.get("Tutorialtitle")))
		{
			oRPT.log("Page title ", "Page title ", ResultType.PASSED,
					"Tutorial point",
					"Tutorial point mathched", true);
		}else
		{
			oRPT.log("Page title ", "Page title ", ResultType.FAILED,
					"Expected title",
					"Tutorial point not mathched", true);	
		}
		Thread.sleep(5000);
		xpathobj="//*[@id='java_technologies']/li[1]/a";
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathobj)));
		driver.findElement(By.xpath(xpathobj)).click();
	
		if(driver.getTitle().contains(input.get("Subjecttitle")))
		{
			oRPT.log("Page title ", "Page title ", ResultType.PASSED,
					"Subject page",
					"Subject page", true);
		}else
		{
			oRPT.log("Page title ", "Page title ", ResultType.FAILED,
					"Subject page",
					"Subject page not available", true);	
		}	
	
	}
	
	
	
	public void tearoff(DataRow input, DataRow output)
	{
		if(driver.getTitle().contains(input.get("Subjecttitle")))
		{
			oRPT.log("Page title ", "Page title ", ResultType.PASSED,
					"Tear Off",
					"Tear Off successfully", true);
		}else
		{
			oRPT.log("Page title ", "Page title ", ResultType.FAILED,
					"Subject page",
					"Subject page not available", true);	
		}	
		driver.quit();
	}

}
