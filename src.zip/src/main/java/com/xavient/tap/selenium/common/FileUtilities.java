package com.xavient.tap.selenium.common;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;

import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.qcRESTConnection.qcRESTconnection;

public class FileUtilities {
	ConfigParams CONFIG = ConfigParams.SINGLETON;
	String zipFile = CONFIG.properties.getProperty("LogZipFolder");
	private static final int BUFFER_SIZE = 4096;
	String rootFolder = CONFIG.properties.getProperty("workingDir");
	String testRunner = CONFIG.properties.getProperty("TestRunner");
	String folderPath = CONFIG.properties.getProperty("FolderPath");

	/****************************************************************
	 * @param in
	 * @param outdir
	 * @param name
	 * @throws IOException
	 ****************************************************************/
	private static void extractFile(ZipInputStream in, File outdir, String name)
			throws IOException {
		byte[] buffer = new byte[BUFFER_SIZE];
		BufferedOutputStream out = new BufferedOutputStream(
				new FileOutputStream(new File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
			out.write(buffer, 0, count);
		out.close();
	}

	/****************************************************************
	 * @param folderPath
	 * @return true or false based on the folder creation
	 ****************************************************************/
	public static boolean createFolder(String folderPath) {
		boolean isCreated = false;
		//Create a folder if it does not exist.
		File saveDir = new File(folderPath);
		if (!saveDir.exists()) {
			isCreated = saveDir.mkdirs();
		}
		return isCreated;
	}

	/****************************************************************
	 * @param outdir
	 * @param path
	 ****************************************************************/
	private static void mkdirs(File outdir, String path) {
		File d = new File(outdir, path);
		if (!d.exists())
			d.mkdirs();
	}

	/****************************************************************
	 * @param name
	 * @return
	 ****************************************************************/
	private static String dirpart(String name) {
		int s = name.lastIndexOf(File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}

	/****************************************************************
	 * @param sourceDirectory
	 * @param testCase
	 *            - to create the zip folder with testcase name.
	 * @return name of the zip folder created
	 ****************************************************************/
	public String zipFolder(String sourceDirectory, String testCase) {
		try {
			System.out.println(sourceDirectory);
			String[] FolderName = sourceDirectory.split("/");
			System.out.println(FolderName.length);
			File f = new File(zipFile);
			if (!f.exists()) {
				f.mkdir();
			}
			zipFile = zipFile + FolderName[FolderName.length - 1] + "_"
					+ testCase + ".zip";

			// create object of FileOutputStream
			FileOutputStream fout = new FileOutputStream(zipFile);

			// create object of ZipOutputStream from FileOutputStream
			ZipOutputStream zout = new ZipOutputStream(fout);

			// create File object from source directory
			File fileSource = new File(sourceDirectory);
			addDirectory(zout, fileSource, testCase);

			// close the ZipOutputStream
			zout.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.out.println("IOException :" + ioe);
		}
		return zipFile;
	}

	/****************************************************************
	 * @param zout
	 * @param fileSource
	 * @param testCase
	 ****************************************************************/
	private static void addDirectory(ZipOutputStream zout, File fileSource,
			String testCase) {

		// get sub-folder/files list
		try {
			File[] files = fileSource.listFiles();
			System.out.println("Adding directory " + fileSource.getName());
			for (int i = 0; i < files.length; i++) {
				// if the file is directory, call the function recursively
				if (files[i].isDirectory()) {
					addDirectory(zout, files[i], testCase);
					continue;
				}

				try {
					if (!files[i].getName().contains(".lck")) {
						if (files[i].getName().contains(testCase)
								|| files[i].getName().contains(
										"ExecutionReport")) {
							System.out.println("Adding file "
									+ files[i].getName());
							// create byte buffer
							byte[] buffer = new byte[1024];

							// create object of FileInputStream
							FileInputStream fin = new FileInputStream(files[i]);
							zout.putNextEntry(new ZipEntry(files[i].getName()));

							int length;
							while ((length = fin.read(buffer)) > 0) {
								zout.write(buffer, 0, length);
							}

							zout.closeEntry();

							// close the InputStream
							fin.close();
						}
					}
				} catch (IOException ioe) {
					System.out.println("IOException :" + ioe);

				}

			}
		} catch (NullPointerException e) {
		}
	}

	/****************************************************************
	 * @function Check if the folder exist or not
	 * @param folderPath
	 * @return True or False based on the Folder Exist or not
	 ****************************************************************/
	public static boolean isFolderExist(String folderPath) {
		File f = new File(folderPath);
		return f.isDirectory();
	}

	/****************************************************************
	 * @function Create a folder 
	 * 
	 ****************************************************************/
	public void createFolder() {
		//Create a folder if the folder does not exists.
		File f = new File(folderPath);
		if (!f.exists()) {
			f.mkdir();
		}
		File f1 = new File(rootFolder+"/UBTemp");
		if (!f1.exists()) {
			f1.mkdir();
		}
	}

	/****************************************************************
	 * @function create a text file inside a folder and write into the file
	 ****************************************************************/
	public void createTxtFile() {
		Writer writer = null;
		try {
			String strDate;
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
			strDate = ft.format(dNow);
			//Fetch LogFolder path from properties file
			String logFolderPath = CONFIG.properties.getProperty("LogFolder");
			File f = loadFile(logFolderPath);
			if (!f.exists()) {
				f.mkdir();
			}
			setResultFolder(logFolderPath,strDate);
			
			File file1 = new File(qcRESTconnection.resultsFolder);
			System.out.println(qcRESTconnection.resultsFolder);
			file1.mkdir();
			//Retrieve the result folder name from QC and write the folder name into txt file
			File file = new File(folderPath+"/FolderName.txt");
			writer = new BufferedWriter(new FileWriter(file));
			writer.write(qcRESTconnection.resultsFolder);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (writer != null) {
					writer.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void setResultFolder(String logFolderPath, String strDate){
		qcRESTconnection.resultsFolder = logFolderPath + "/Report_" + strDate;
	}

	/****************************************************************
	 * @function delete a folder
	 ****************************************************************/
	public void deleteFolder() {
		File folder = new File(folderPath);
		//Delete the folder and files inside the folder.
		if (folder.exists()) {
			File[] files = folder.listFiles();
			if (files != null) {
				for (File f : files) {
					f.delete();
				}
			}
			folder.delete();
		}
	}

	/****************************************************************
	 * @function delete a folder
	****************************************************************/
	public void deleteTempFolder() {
		File folder = new File(rootFolder+"/UBTemp");
		//Delete the folder and files inside the folder.
		if (folder.exists()) {
			File[] files = folder.listFiles();
			if (files != null) {
				for (File f : files) {
					f.delete();
				}
			}
			folder.delete();
		}
	}

	/****************************************************************
	 * @function copy files from one location to other location.
	 * @param srcPath
	 * @param destPath
	 ****************************************************************/
	public static void copyFile(String srcPath, String destPath) {
		File srcFile = new File(srcPath);
		File targetFile = new File(destPath);
		boolean isExists = targetFile.exists();
		if (!isExists) {
			try {
				//Copy the file from source folder to destination folder.
				FileUtils.copyFile(srcFile, targetFile);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error while copying file");
			}
		}
	}

	/****************************************************************
	 * @function creates the folder structure to copy the files from QC.
	 ****************************************************************/
	public void makeLibAndResourcesReady() {
		try {
			String resourceFolder = rootFolder+"/src/main/";
			String resourceZipFile = rootFolder+"/src/main/resources.zip";
			createFolder(resourceFolder);
			FileUtilities.unZipIt(new File(resourceZipFile), new File(
					resourceFolder));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/****************************************************************
	 * @function Unzip the folder
	 * @param zipfile
	 * @param outdir
	 ****************************************************************/
	public static void unZipIt(File zipfile, File outdir) {
		try {
			ZipInputStream zin = new ZipInputStream(
					new FileInputStream(zipfile));
			ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null) {
				name = entry.getName();
				if (entry.isDirectory()) {
					mkdirs(outdir, name);
					continue;
				}

				dir = dirpart(name);
				if (dir != null)
					mkdirs(outdir, dir);

				extractFile(zin, outdir, name);
			}
			zin.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	/****************************************************************
	 * @function Set the configuration properties.
	 * @param userID
	 * @param Password
	 * @param Domain
	 * @param Project
	 * @param ALMTestSetFolder
	 * @param testSetName
	 * @param selectedBrowser
	 * @param seletedEnvironement
	 ****************************************************************/
	public void setValues(String userID, String Password, String Domain,
			String Project, String ALMTestSetFolder, String testSetName,
			String selectedBrowser, String seletedEnvironement) {
		CONFIG.properties.setProperty("ALMUserID", userID);
		CONFIG.properties.setProperty("ALMPassword", Password);
		CONFIG.properties.setProperty("ALMDomainName", Domain);
		CONFIG.properties.setProperty("ALMProjectName", Project);
		CONFIG.properties.setProperty("ALMTestSetFolder", ALMTestSetFolder);
		CONFIG.properties.setProperty("ALMTestSet", testSetName);
	}
	
	/****************************************************************
	 * @Method Name : loadFile
	 * @Method Description : 
	 * @param args
	 *            :File Name
	 * @param Sample
	 *            Usage : loadFile(String);
	 * @return boolean
	 ****************************************************************/
	public File loadFile(String filePath){
		File inputWorkbook = new File(filePath);		
		return inputWorkbook;
	}
}
