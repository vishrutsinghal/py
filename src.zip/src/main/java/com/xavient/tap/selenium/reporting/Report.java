package com.xavient.tap.selenium.reporting;

import java.util.Random;

import org.testng.Reporter;

public class Report {
	
	static public void printReport(String message) 
	{
//		Reporter.log("<tr><td >"+message + "</td><td/></tr>");
		String style = "style=\"padding-left: 5px; padding-bottom: 3px;\" ><br />"+message;
		Reporter.log("<tr bgcolor=\"#E4D4C8\"><td "+style + "</tr>");
	}
	
	static public void printReport(String status,String message) 
	{
		String style="";
		if(status.equalsIgnoreCase("warn"))
		 style= "style=\"padding-left: 5px; padding-bottom: 3px;\" bgcolor=\"#E8F806\"><br />"+message;
		if(status.equalsIgnoreCase("error"))
			style= "style=\"padding-left: 5px; padding-bottom: 3px;\" bgcolor=\"#F11158\"><br />"+message;
		else
			style= "style=\"padding-left: 5px; padding-bottom: 3px;\" bgcolor=\"#06F826\"><br />"+message;
		Reporter.log("<tr><td "+style + "</td><td/></tr>");
	}
	
	static public void start(String testCaseName) 
	{
		 Random randomGenerator = new Random();
		 int intNo = randomGenerator.nextInt();
		 String tableID = "table_"+intNo;
		 Reporter.log("<a href=\"javascript:toggleElement('"+tableID+"', 'block')\" title=\"Click to expand/collapse\"><b>Test Case Name : "+testCaseName+"</b></a><br />");
		 Reporter.log("<table class=\"stackTrace\" id=\""+tableID+"\" border=\"1\"><tbody>");
	}
	
	static public void end()
	{
		Reporter.log("</tbody></table>");
	}

}
