package com.xavient.tap.selenium.utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;

import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.reporting.ManagingReporter;

public class Logger {
	private final int LOG_LEVEL = 0;
	private final static String[] LOG_LEVEL_NAMES = { "DEBUG", "TRACE",
			"DETAIL", "WARNING", "ERROR" };
	private static int level;
	private static Object context;
	private static FileHandler logFileHandler;
	public static Properties properties;
	private static java.util.logging.Logger log;
	private static Map<String, String> logFileDetails;
	private static Object owner;
	static ConfigParams CONFIG = ConfigParams.SINGLETON;

	private static Logger oLOGGER;

	public static synchronized Logger getInstance() {
		return getInstance("Test");
	}

	/****************************************************************
	 * @param logFileName
	 * @return
	 ****************************************************************/
	public static synchronized Logger getInstance(String logFileName) {
		if (oLOGGER == null) {
			oLOGGER = new Logger();
			logFileDetails = createLoggers(logFileName);
		}
		return oLOGGER;

	}

	public Logger(Object owner) {
		setOwner(owner);
	}
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void setOwner(Object owner){
		Logger.owner = owner;
	}
	
	public Logger() {
		this("<Null>");
	}

	public interface LogWriter {
		public void write(int level, Object... varargs);
	}

	public static class ConsoleWriter implements LogWriter {
		public void write(int level, Object... varargs) {
			write(LOG_LEVEL_NAMES[level], StringUtils.toString(varargs));
		}

		public void write(String levelName, String lines) {
			String time = new SimpleDateFormat("yyyy,MMM dd HH:mm:ss").format(
					new Date()).toString();
			log.info(time + "|" + levelName + "|" + owner.toString() + "|"
					+ lines);
		}
	}

	private LogWriter writer = new ConsoleWriter();

	public void setWriter(LogWriter w) {
		writer = w;
	}

	/****************************************************************
	 * @param context
	 * @param level
	 ****************************************************************/
	public void initialize(Object context, int level) {
		try {
			setContextandLevel(context, level);
		} catch (Exception e) {

		}
	}
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void setContextandLevel(Object context, int level){
		Logger.context = context.toString();
		Logger.level = level;
	}

	/****************************************************************
	 * @param level
	 * @param varargs
	 ****************************************************************/
	public void log(int level, Object... varargs) {
		if (level < this.level) {
			return;
		}
		writer.write(level, varargs);
	}

	public void debug(Object... varargs) {
		log(0, varargs);
	}

	public void trace(Object... varargs) {
		log(1, varargs);
	}

	public void detail(Object... varargs) {
		log(2, varargs);
	}

	public void warning(Object... varargs) {
		log(3, varargs);
	}

	public void error(Object... varargs) {
		log(4, varargs);
	}

	/****************************************************************
	 * @param varargs
	 ****************************************************************/
	public void handleError(Object... varargs) {
		error(varargs);
		throw new FrameworkException("Exception caught : ", varargs);
	}

	/****************************************************************
	 * @param logFileName
	 * @return
	 ****************************************************************/
	private static Map createLoggers(String logFileName) {
		Map logFileDetails = null;
		try {
			log = java.util.logging.Logger.getLogger("log");
			loadProperty();

			if (!FileUtils.makeFolder(CONFIG.properties
					.getProperty("ResultsRootFolder")))
				System.out
						.println("Can't create/access Logs folder; these will not be generated: "
								+ logFileName + "");
			String filePath = CONFIG.properties
					.getProperty("ResultsRootFolder");
			filePath = ManagingReporter.readTxtFile();// filePath+"\\"+"Report_"+strDate;
			filePath = filePath + "/" + logFileName;
			logFileHandler = new FileHandler(filePath);
			logFileHandler.setFormatter(new SimpleFormatter());
			log.addHandler(logFileHandler);
			logFileDetails = new HashMap();
			logFileDetails.put("fileName", logFileName);
			logFileDetails.put("filePath", filePath);
		} catch (IOException e) {
			System.out.println("Unable to create log File for " + logFileName);
		}
		return logFileDetails;
	}

	public void closeLoggers() {
		log.removeHandler(logFileHandler);
		logFileHandler.flush();
		logFileHandler.close();
		setLoggerObjtoNull();
		
	}
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void setLoggerObjtoNull(){
		oLOGGER = null;
	}
	

	public static void loadProperty() {
	}

	public Map<String, String> getLogFileDetails() {
		return logFileDetails;
	}

	public String toString() {
		return "Logger(" + logFileDetails.get("filePath") + ")";
	}

}
