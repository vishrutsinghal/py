package com.xavient.tap.selenium.engine;

public interface TestSet {
	public int testInstanceCount();

	public TestInstance testInstance(int ix);
}
