/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xavient.tap.selenium.common;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 *
 * @author dv81650
 */
class ServerAppUtil {
    
     /** Creates a new instance of ServerAppUtil */
    public ServerAppUtil() {
    }
    
	public static void postMail( String recipients[ ],String subject, String message , String from, String filePath) throws MessagingException
{
    try {
		boolean debug = false;

		 //Set the host smtp address
		 Properties props = new Properties();
		 props.put("mail.smtp.host", "smtp.uboc.com");

		// create some properties and get the default Session
		Session session = Session.getDefaultInstance(props, null);
		session.setDebug(debug);

		// create a message
		Message msg = new MimeMessage(session);

		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(from);
		msg.setFrom(addressFrom);

		InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
		for (int i = 0; i < recipients.length; i++)
		{
		    addressTo[i] = new InternetAddress(recipients[i]);
		}
		msg.setRecipients(Message.RecipientType.TO, addressTo);
		// create and fill the first message part
		  MimeBodyPart mbp1 = new MimeBodyPart();
		  mbp1.setText(message);

   // create the second message part
		  MimeBodyPart mbp2 = new MimeBodyPart();

  // attach the file to the message
		  FileDataSource fds = new FileDataSource(filePath);
		  mbp2.setDataHandler(new DataHandler(fds));
//		  mbp2.setFileName(fds.getName());
   
		  // create the Multipart and add its parts to it
		  Multipart mp = new MimeMultipart();
		  mp.addBodyPart(mbp1);
//		  mp.addBodyPart(mbp2);
		  

		// Optional : You can also set your custom headers in the Email if you Want
		msg.addHeader("MyHeaderName", "myHeaderValue");

		// Setting the Subject and Content Type
		msg.setSubject(subject);
		msg.setContent(mp, "text/plain");
		Transport.send(msg);
	} catch (Exception e) {
		e.printStackTrace();
	}
}
    
}
