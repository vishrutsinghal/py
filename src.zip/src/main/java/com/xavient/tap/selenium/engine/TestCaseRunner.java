package com.xavient.tap.selenium.engine;

import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.engine.TestResultTracker.Trackable;
import com.xavient.tap.selenium.harness.ParameterAccess;
import com.xavient.tap.selenium.utils.DataRow;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.StringUtils;
import com.xavient.tap.selenium.utils.Utils;

/*	TestCaseRunner will run the each testCase i.e. steps and
 will inform start/failure of test case to the tracker,
 this class will in turn pass this for display or report manager etc*/

public class TestCaseRunner {
	TestResultTracker oResultsTracker;
	AppDriver oAppDriver;
	private ParameterAccess paramsAccess;
	private Logger logger = new Logger(this);

	private BuiltinActionsDriver biActionsDriver;
	private TestResultLogger RPT;

	public TestCaseRunner(AppDriver oAppDriver,
			TestResultTracker oResultTracker, TestResultLogger oRPT) {
		this.oAppDriver = oAppDriver;
		this.oResultsTracker = oResultTracker;
		this.RPT = oRPT;
	}

	/*
	 * Run test case Pass or fail status of the test case that is executed
	 */
	public interface tcMaker {
		public TestCase make() throws Exception;
	}

	/****************************************************************
	 * @Method Name : runTestCase
	 * @param tcMaker
	 * @param name
	 * @return
	 ****************************************************************/
	public TestResult runTestCase(final tcMaker tcMaker, String name) {
		return oResultsTracker.track(new Trackable() {
			public void run(TestResult result) throws Exception {
				TestCase oTestCase;
				try {
					oTestCase = tcMaker.make();
				} catch (Exception e) {
					RPT.error("RunTestCase():", "", e.toString(),
							"Initialization error in test case:" + e);
					return;
				}

				// fire an artificial log event with the deserialized testCase
				oResultsTracker.log(ResultType.DONE, oTestCase);

				paramsAccess = new ParameterAccess();
				biActionsDriver = new BuiltinActionsDriver(paramsAccess);
				paramsAccess.declareVariables(oTestCase);
				oResultsTracker.addReporter(paramsAccess);

				int iterationCount = oTestCase.iterationCount();
				for (int i = 0; i < iterationCount; i++) {
					TestResult iterRs = runIteration(oTestCase.iteration(i));
					if (iterRs.miscInfo.containsKey("abortRs")) {
						try {
							logger.trace("actionDriver.recover()");
							oAppDriver.recover();
						} catch (Exception e) {
						}
					}
				}
			}
		}, TestResult.EntityType.TESTCASE, name, tcMaker);
	}

	/***************************************************************
	 * @method Name - runIteration
	 * @method Description - Run test case for the given iteration
	 * @param iteration
	 * @return
	 ***************************************************************/
	private TestResult runIteration(final TestIteration iteration) {
		return oResultsTracker.track(new Trackable() {
			@SuppressWarnings("unchecked")
			public void run(TestResult result) throws Exception {
				int stepCount = iteration.stepCount();
				//Iterates through each step and execute it
				for (int stepIx = 0; stepIx < stepCount; stepIx++) {

					TestStep oTestStep = iteration.step(stepIx);

					TestResult stepRs = runStep(oTestStep);

					if (stepRs.miscInfo.containsKey("abortRs")) {
						result.miscInfo.put("abortRs", stepRs);
						logger.trace("aborting at:" + stepIx);
						break;
					}
				}
			}
		}, TestResult.EntityType.ITERATION, "#IterIx#", iteration);
	}

	/****************************************************************
	 * @method runStep
	 * @param oTestStep
	 * @return
	 ****************************************************************/
	public TestResult runStep(final TestStep oTestStep) {
		return oResultsTracker.track(new Trackable() {
			@SuppressWarnings("unchecked")
			public void run(TestResult result) throws Exception {
				DataRow input = oTestStep.actionParameters();
				if (paramsAccess != null) {
					input = Utils.Map2DataRow(paramsAccess.resolve(input));
				}

				DataRow output = new DataRow();
				TestResult actionRs = runAction(oTestStep, input, output);
				ResultType actionRsType = actionRs.finalRsType;
				boolean bAbortTest = false, bFailTest = false;
				if (!actionRsType.isPassed()) {
					bAbortTest = oTestStep.abortTestIfUnexpected();
					bFailTest = oTestStep.failTestIfUnexpected();

					// indication: unexpected result was ignored as per flag
					String warnMsg = null;
					if (!bFailTest) {
						warnMsg = "Step Failed";
						result.finalRsType = ResultType.WARNING;
					}

					if (bAbortTest) {
						result.miscInfo.put("abortRs", actionRs);
					} else {
						if (warnMsg == null) {
							warnMsg = "Execution continued";
						} else {
							warnMsg = " and execution continued";
						}
					}

					if (warnMsg != null) {
						RPT.warning("", "", "", warnMsg
								+ " despite unexpected result in action");
					}
				}
			}
		}, TestResult.EntityType.TESTSTEP, oTestStep.stepName(), oTestStep);
	}

	/****************************************************************
	 * @param oTestStep
	 * @param input
	 * @param output
	 * @return
	 ****************************************************************/
	public TestResult runAction(final TestStep oTestStep, final DataRow input,
			final DataRow output) {
		//fetch the modulecode and actioncode from excel and call perform action method
		final String moduleCode = oTestStep.moduleCode();
		final String actionCode = oTestStep.actionCode();
		return oResultsTracker.track(
				new Trackable() {
					@SuppressWarnings("unchecked")
					public void run(TestResult result) throws Exception {
						result.miscInfo.put("input", input);

						try {
							performAction(moduleCode, actionCode, input, output);
							result.miscInfo.put("output", output);
						} catch (Exception e) {
							RPT.error("", "", "", "Error during perform:"
									+ StringUtils.toString(e));
						}
					}
				}, TestResult.EntityType.ACTION, moduleCode + "-" + actionCode,
				oTestStep);
	}

	/****************************************************************
	 * @param moduleCode
	 * @param actionCode
	 * @param input
	 * @param output
	 * @throws Exception
	 ****************************************************************/
	private void performAction(String moduleCode, String actionCode,
			DataRow input, DataRow output) throws Exception {
		logger.trace("performAction()");
		logger.trace("appdriver.perform( " + moduleCode + " , " + actionCode
				+ " , " + StringUtils.toString(input) + " ) ");
		//calls perform method based on the module code
		if (moduleCode.equals("_FW"))
			biActionsDriver.perform(actionCode, input, output);
		else
			oAppDriver.perform(moduleCode, actionCode, input, output);

	}

	public String toString() {
		return "TestCaseRunner()";
	}
}
