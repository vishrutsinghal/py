package com.xavient.tap.selenium.tstng;

import java.lang.reflect.Method;
import java.util.List;

import org.testng.ITest;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

//import com.xavient.tap.selenium.actions.AppDriver;




import com.xavient.tap.selenium.appdriver.TAPDriver1;
import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.harness.AppLoader;
import com.xavient.tap.selenium.utils.DataRow;

public class WebTest {
	
	DataRow dr1;
	DataRow dr2;
	
	 public static void main(String[] args){
		 TestNG testng = new TestNG();
	        List<String> suites = Lists.newArrayList();
	        suites.add("./factory-testng.xml");
	        testng.setTestSuites(suites);
	        testng.run();
		/* WebTest wT=new WebTest();
		 AppDriver appDriver=null;
		 appDriver=new AppLoader().loadApp();
		 
		 
		 
		  wT.dr1=new DataRow();
		 wT.dr1.put("url", "https://www.gmail.com");
		wT.dr2=new DataRow();
		 
		 //System.out.println(dr1);
		 //System.out.println(dr2);
		 
		 
		 //AppDriver aD=new AppDriver();
		 //aD.launchApp(wT.dr1, wT.dr2);
		 appDriver.perform("UB", "launchApp", wT.dr1, wT.dr2);
		 wT.dr1.clear();
		 wT.dr1.put("Login-password", "1@34567f");
		 wT.dr1.put("Login-userID", "qy92614");
		 
		 //TAPDriver tD=new TAPDriver();
		 //tD.login(wT.dr1, wT.dr2);
		 
		 appDriver.perform("UB","login",wT.dr1, wT.dr2);
		 
		 wT.dr1.clear();
		 wT.dr1.put("SignOut", "Sign Out");
		 
		 appDriver.perform("UB","logout",wT.dr1, wT.dr2);*/
		 
		 
		 
	 }
	
	
	
	
	
	  
	
	
}