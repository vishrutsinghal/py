package com.xavient.tap.selenium.engine;

import com.xavient.tap.selenium.utils.DataRow;

public interface TestStep {
	public String stepName();

	public String moduleCode();

	public String actionCode();

	public DataRow actionParameters();

	public String actionOutputValidation();

	public boolean failTestIfUnexpected();

	public boolean abortTestIfUnexpected();
}