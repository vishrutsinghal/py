package com.xavient.tap.selenium.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.xavient.tap.selenium.harness.ConfigParams;

public class PersistentMap extends HashMap<String, String> {
	public Logger logger = new Logger(this);
	private PersistentDataAccess globalDataAccess;
	private File file;

	/****************************************************************
	 * @param groupName
	 ****************************************************************/
	public PersistentMap(String groupName) {
		String globalDataFolder = ConfigParams.SINGLETON.properties
				.getProperty("WorkFolder") + "/Params";
		if (!FileUtils.makeFolder(globalDataFolder)) {
			logger.handleError("Can't create/access global data folder:"
					+ globalDataFolder);
		}
		globalDataAccess = new PersistentDataAccess(globalDataFolder, groupName);
		this.putAll(globalDataAccess.retrieve());
	}

	public String put(String key, String value) {
		super.put(key, value);
		globalDataAccess.save(this);
		return value;
	}

	public void putAll(Map m) {
		super.putAll(m);
		globalDataAccess.save(m);
	}

	public String remove(Object key) {
		String value = (String) super.get(key);
		super.remove(key);
		globalDataAccess.save(this);
		return value;
	}

	private class PersistentDataAccess {
		private String fileName;

		/****************************************************************
		 * @param folderPath
		 * @param dataName
		 ****************************************************************/
		public PersistentDataAccess(String folderPath, String dataName) {
			String fileName = folderPath + "/" + dataName + ".dat";
			this.fileName = fileName;
			if (!FileUtils.fileExists(fileName)) {
				file = new File(fileName);
				try {
					file.createNewFile();
				} catch (IOException e) {
					logger.handleError("Can't create persistent data file ",
							fileName, e);
				}
			}
		}

		/****************************************************************
		 * @param fileName
		 ****************************************************************/
		private void fileName(String fileName) {
			this.fileName = fileName;
		}

		/****************************************************************
		 * @param values
		 ****************************************************************/
		public void save(Map values) {
			try {
				intSave(fileName, values);
			} catch (IOException e) {
				logger.handleError("Save data dailed", e);
			}

		}

		/****************************************************************
		 * @param fileName
		 * @param values
		 * @throws IOException
		 ****************************************************************/
		private void intSave(String fileName, Map values) throws IOException {
			PrintWriter out = new PrintWriter(new FileWriter(fileName));
			//Sonar Fix :  Performance - Inefficient use of keySet iterator instead of entrySet iterator
			//Collection<String> keys = values.keySet();
			Set<Entry> entries = values.entrySet();
			//for (String key : keys) {
			for(Iterator<Entry> i = entries.iterator(); i.hasNext(); ){
				Entry e = (Entry)i.next();
				String key = (String) e.getKey();
				String value = (String) e.getValue();
				if (!key.equals("")) {
					out.write(key + " = " + value);
					out.println();
				}
			}
			out.close();
		}

		public Map retrieve() {
			try {
				return intRetrieve(fileName);
			} catch (Exception e) {
				logger.handleError("Retrieve data failed: ", e.getMessage());
			}
			return null;
		}

		/****************************************************************
		 * @param fileName
		 * @return
		 * @throws IOException
		 ****************************************************************/
		private Map intRetrieve(String fileName) throws IOException {
			Map values = new HashMap();
		/*	if (!FileUtils.fileExists(fileName)) {
				return values;
			}
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String text;
			while ((text = reader.readLine()) != null) {
				text = text.trim();

				int separatorIndex = text.contains("=") ? text.indexOf("=") : 0;
				if (separatorIndex != 0)
					values.put(text.substring(0, separatorIndex - 1),
							text.substring(separatorIndex + 1, text.length()));
			}
			reader.close();*/
			return values;
		}

		public String toString() {
			return "PersistentDataAccess(" + fileName + ")";
		}
	}
}
