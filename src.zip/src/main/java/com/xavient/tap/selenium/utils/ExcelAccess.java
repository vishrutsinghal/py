package com.xavient.tap.selenium.utils;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.CellView;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 * 
 * @class handles all the function related to Excel Data sheet like reading
 *        sheet,reading row,etc..
 * 
 */
public class ExcelAccess {
	private ExcelAccess() {
	}

	public interface RowHandler {
		boolean handleRow(RowAccess rowAccess, int rowIx);
	}

	public interface RowAccess {
		String[] get();

		void set(String[] values);

		void set(int colIx, String value);
	};

	/****************************************************************
	 * @param fileName
	 * @param sheetName
	 * @param rowHandler
	 * @return
	 * @throws BiffException
	 * @throws IOException
	 ****************************************************************/
	public static int accessSheet(String fileName, String sheetName,
			RowHandler rowHandler) throws BiffException, IOException {
		Workbook workbook = Workbook.getWorkbook(new File(fileName));
		Sheet sheet = workbook.getSheet(sheetName);
		return access(sheet, rowHandler);
	}

	private static class SimpleRowAccess implements RowAccess {
		final Cell[] cells;
		SimpleRowAccess(Cell[] newCells) {
			//To fix the sonar critical issue : Security - Array is stored directly 
			if(newCells == null) { 
			    this.cells = new Cell[0]; 
			  }else{
				  this.cells = Arrays.copyOf(newCells, newCells.length);
			  }
			//this.cells = cells;
		}

		public String[] get() {
			String[] colValues = new String[cells.length];
			for (int j = 0; j < cells.length; j++) {
				colValues[j] = cells[j].getContents().trim();
			}
			return colValues;
		}

		public void set(String[] values) {
			for (int i = 0; i < cells.length; ++i) {
				if (i >= values.length)
					break;
			}
		}

		public void set(int colIx, String value) {
		}
	}

	/****************************************************************
	 * @param sheet
	 * @param rowHandler
	 * @return
	 ****************************************************************/
	public static int access(Sheet sheet, RowHandler rowHandler) {
		int count = 0;
		for (int i = 0; i < sheet.getRows(); i++) {
			Cell cells[] = sheet.getRow(i);
			CellView c = sheet.getRowView(i);

			boolean rc = rowHandler.handleRow(new SimpleRowAccess(cells), i);
			if (!rc)
				break;
			++count;
		}
		return count;
	}

	public interface NamedRowAccess {
		public DataRow get();

		public void set(DataRow namedValues);

		public void set(String colName, String value);
	}

	public static abstract class NamedRowHandler implements RowHandler {
		private String[] colNames;
		private Map<String, Integer> colName2IxMap = new HashMap<String, Integer>();

		private final class Access implements NamedRowAccess {
			private RowAccess rowAccess;

			private Access(RowAccess rowAccess) {
				this.rowAccess = rowAccess;
			}

			public DataRow get() {
				String[] values = rowAccess.get();
				HashMap namedValues = new HashMap();
				for (int ix = 0; ix < values.length; ix++) {
					if (ix >= colNames.length) {
						break;
					}
					String colName = colNames[ix];
					namedValues.put(colName, values[ix]);
				}

				return new DataRow(namedValues);
			}

			public void set(DataRow namedValues) {
				String[] values = new String[colNames.length];
			}

			public void set(String colName, String value) {
				int ix = colName2IxMap.get(colName);
			}
		}

		public abstract boolean handleRow(NamedRowAccess namedRowAccess,
				int rowIx);

		final public boolean handleRow(RowAccess rowAccess, int rowIx) {
			String[] colValues = rowAccess.get();
			if (rowIx == 0) { // header row
				setColNames(colValues);
				return true;
			}
			return handleRow(new Access(rowAccess), rowIx - 1);
		}

		/****************************************************************
		 * @param colNames
		 ****************************************************************/
		private void setColNames(String[] newColNames) {
			//To fix the sonar critical issue : Security - Array is stored directly 
			if(newColNames == null){
				this.colNames = new String[0];
			}else{
				this.colNames = Arrays.copyOf(newColNames, newColNames.length);
			}
			//this.colNames = colNames;
			for (int ix = 0; ix < colNames.length; ix++)
				colName2IxMap.put(colNames[ix], ix);
		}
	}

	public static abstract class MapReader extends NamedRowHandler {
		public abstract boolean handleRow(DataRow row, int rowIx);

		final public boolean handleRow(NamedRowAccess namedRowAccess, int rowIx) {
			return handleRow((DataRow) namedRowAccess.get(), rowIx);
		}
	}

	public static class RowArrayBuilder extends MapReader {
		private List<Map> rows;

		public RowArrayBuilder(List<Map> rows) {
			this.rows = rows;
		}

		public boolean handleRow(DataRow row, int rowIx) {
			rows.add(row);
			return true;
		}
	}
}
