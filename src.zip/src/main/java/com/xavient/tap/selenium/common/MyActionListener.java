package com.xavient.tap.selenium.common;

import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyActionListener implements ActionListener {

	JTextField textfield;

	MyActionListener(JTextField textfield) {
		this.textfield = textfield;
	}

	public void actionPerformed(ActionEvent e) {

		//Set encrypted data into the text box.
		try {
			textfield.setText(Encryption.encrypt(textfield.getText()));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}
