package com.xavient.tap.selenium.tstng;

import java.util.ArrayList;
import java.util.List;

import org.testng.ITest;
import org.testng.Reporter;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;

import com.xavient.tap.selenium.engine.AppDriver;
import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.engine.TestIteration;
import com.xavient.tap.selenium.engine.TestStep;
import com.xavient.tap.selenium.harness.AppLoader;
import com.xavient.tap.selenium.utils.DataRow;
import com.xavient.tap.selenium.xmlparser.XmlReader;


public class TestFactory3  {
	public String teststep;
	
	
	 @Parameters({ "testName" })
	  @Factory
	  public Object[] createInstances(String param) throws Exception{
		
		 AppDriver appDriver=null;
		 appDriver=new AppLoader().loadApp();
		 XmlReader xmlReader=new XmlReader();
		 TestCase testCase=xmlReader.getTestCase(param);
		 TestIteration testIteration=testCase.iteration(0);
		 
		 int stepCount=testIteration.stepCount();
		 TestStep testStep;
		 List<Object> resultStep=new ArrayList<Object>();
		 for(int i=0;i<stepCount;i++){
			 testStep=testIteration.step(i);
			 Reporter.log(testStep.moduleCode());
			 teststep=testStep.moduleCode();
			 resultStep.add(new WebStepRunner(i,appDriver,testStep.moduleCode(),testStep.stepName(),
					 testStep.actionCode(),testStep.actionParameters(),null));
		 }
		 Object[] result=resultStep.toArray(new Object[resultStep.size()]);
		// System.out.println(result[]);
		System.out.println(result.length);
		return result;
	 }

	
	
}
