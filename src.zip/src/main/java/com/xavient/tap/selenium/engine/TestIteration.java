package com.xavient.tap.selenium.engine;

import java.util.Map;

public interface TestIteration {
	public int stepCount();

	public TestStep step(int stepIx);

	public Map parameters();
}