package com.xavient.tap.selenium.common;

import java.io.IOException;

import jxl.read.biff.BiffException;

import com.xavient.tap.selenium.actions.AppDriver;
import com.xavient.tap.selenium.engine.TestResult.ResultType;

public class TAPException extends AppDriver {
	
	public TAPException() throws BiffException, IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public void HandleTAPException(Exception e, String methodName){
		
		System.out.println(e.getMessage());
		
		oRPT.log("Exception during : "+methodName+" Action.", "Exception during : "+methodName+" Action.", ResultType.FAILED,
				methodName+" action should be performed", e.getMessage(), true);
	}

}
