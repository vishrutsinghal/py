package com.xavient.tap.selenium.harness;

import com.xavient.tap.selenium.engine.TestCase;
import com.xavient.tap.selenium.serializer.CDTAccess;
import com.xavient.tap.selenium.serializer.DTAccess;
import com.xavient.tap.selenium.serializer.Serializer;
import com.xavient.tap.selenium.utils.FrameworkException;
import com.xavient.tap.selenium.utils.Logger;

public class TestCaseAccess {
	private Logger logger = new Logger(this);
	private ResourcePaths resourcePaths;
	private CDTAccess dataTableAccess;
	private DTAccess dtAccess;

	/****************************************************************
	 * @param resourcePaths
	 * @param dataTableAccess
	 ****************************************************************/
	public TestCaseAccess(ResourcePaths resourcePaths, CDTAccess dataTableAccess) {
		this.resourcePaths = resourcePaths;
		this.dataTableAccess = dataTableAccess;
	}

	/****************************************************************
	 * @param dtAccess
	 ****************************************************************/
	public void dataTableAccess(DTAccess dtAccess) {
		this.dtAccess = dtAccess;
	}

	/****************************************************************
	 * @return
	 * @throws Exception
	 ****************************************************************/
	public TestCase getTestCase() throws Exception {
		logger.trace("getTestCase()");
		String testName = resourcePaths.getTestName();
		String testFile;
		if(ConfigParams.SINGLETON.properties.getProperty("TestDataMode").equalsIgnoreCase("excel")){
			testFile = resourcePaths.getTestFile();
		} else {
			testFile = "";
		}
		if (testFile == null) {
			logger.handleError("Deserializing test step file: : can not find it");
		}
		TestCase oTestCase = null;
		try {
			oTestCase = deserializeTest(testName, testFile);
		} catch (FrameworkException e) {
			logger.handleError("Deserializing test step file:" + testFile);
		}

		return oTestCase;
	}

	/****************************************************************
	 * @param testName
	 * @param serializedFileName
	 * @return
	 * @throws Exception
	 ****************************************************************/
	private TestCase deserializeTest(String testName, String serializedFileName)
			throws Exception {
		logger.trace("DeserializeTest(" + testName + "," + serializedFileName
				+ ")");
		return Serializer.serialize(dataTableAccess, testName,
				serializedFileName);

	}

	public String toString() {
		return "TestCaseAccess(" + resourcePaths.getTestName() + ")";
	}
}
