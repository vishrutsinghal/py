package com.xavient.tap.selenium.engine;

import java.util.HashMap;
import java.util.Map;

import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.utils.Utils;

public class TestResultLogger {
	private TestResultTracker tracker;
	private Map<String, String> step = null;
	public static Map<String, Map<String, String>> testSteps = new HashMap<String, Map<String, String>>();
	public static int stepNumber = 1;
	ConfigParams CONFIG = ConfigParams.SINGLETON;

	public TestResultLogger(TestResultTracker tracker) {
		this.tracker = tracker;
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 ****************************************************************/
	public void passed(String name, String description, String expected,
			String actual) {
		//saveTestStep(name, description, expected, actual, ResultType.PASSED);
		log(name, description, ResultType.PASSED, expected, actual, false);
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 ****************************************************************/
	public void failed(String name, String description, String expected,
			String actual) {
		//saveTestStep(name, description, expected, actual, ResultType.FAILED);
		log(name, description, ResultType.FAILED, expected, actual, true);
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 ****************************************************************/
	public void error(String name, String description, String expected,
			String actual) {
		saveTestStep(name, description, expected, actual, ResultType.FAILED);
		log(name, description, ResultType.FAILED, expected, actual, true);
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 ****************************************************************/
	public void done(String name, String description, String expected,
			String actual) {
		saveTestStep(name, description, expected, actual, ResultType.PASSED);
		log(name, description, ResultType.PASSED, expected, actual, false);
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 ****************************************************************/
	public void warning(String name, String description, String expected,
			String actual) {
		saveTestStep(name, description, expected, actual, ResultType.PASSED);
		log(name, description, ResultType.PASSED, expected, actual, true);
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param rsType
	 * @param expected
	 * @param actual
	 * @param screenDump
	 ****************************************************************/
	public void log(String name, String description, ResultType rsType,
			String expected, String actual, boolean screenDump) {
		saveTestStep(name, description, expected, actual, rsType);
		tracker.log(rsType, Utils.toMap(new Object[] { "name", name,
				"expected", expected, "actual", actual, "screenDump",
				new Boolean(screenDump) }));
	}

	/****************************************************************
	 * @param name
	 * @param description
	 * @param expected
	 * @param actual
	 * @param stepResult
	 ****************************************************************/
	public void saveTestStep(String name, String description, String expected,
			String actual, ResultType stepResult) {
		//Save test steps to QC if the QCConnecton property is set to True
		if (Boolean.parseBoolean(CONFIG.properties.getProperty("QCConnection")
				.toLowerCase())) {
			step = new HashMap<String, String>();
			step.put("description", description);
			step.put("name", name);
			step.put("expected", expected);
			step.put("actual", actual);
			step.put("StepResult", stepResult.name);
			testSteps.put("Step" + stepNumber, step);
			System.out.println(testSteps.get("Step" + stepNumber));
			addStepNumber();
		}
	}
	//To fix the Sonar Critical issue -   "Dodgy - Write to static field from instance method"
	public static void addStepNumber(){
		stepNumber = stepNumber + 1;
	}
}
