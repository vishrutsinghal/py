package com.xavient.tap.selenium.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import com.xavient.tap.selenium.harness.ParameterAccess;
import com.xavient.tap.selenium.utils.DataRow;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.SleepUtils;
import com.xavient.tap.selenium.utils.SleepUtils.TimeSlab;

class BuiltinActionsDriver {
	private ParameterAccess paramsAccess;
	Logger logger = new Logger(this);

	public BuiltinActionsDriver(ParameterAccess paramsAccess) {
		this.paramsAccess = paramsAccess;
	}

	public void perform(String actionCode, DataRow input,
			Map<String, String> output) {
		eval(actionCode, input, output);
	}

	@SuppressWarnings("unused")
	private void save(DataRow input, DataRow output) {
		paramsAccess.copyRecentParameters(input.get("inputName"),
				input.get("output"));

	}

	/****************************************************************
	 * @method name - sleep
	 * @param input
	 * @param output
	 ****************************************************************/
	@SuppressWarnings("unused")
	private void sleep(DataRow input, DataRow output) {
		String level = input.get("level");
		if (level.equals(""))
			logger.handleError("Parameter level must be specified");
		TimeSlab sleepLevel = null;
		switch (level.charAt(0)) {
		case 'Y':
			sleepLevel = TimeSlab.YIELD;
			break;
		case 'L':
			sleepLevel = TimeSlab.LOW;
			break;
		case 'M':
			sleepLevel = TimeSlab.MEDIUM;
			break;
		case 'H':
			sleepLevel = TimeSlab.HIGH;
			break;
		default:
			logger.handleError("Invalid level : ", sleepLevel);

		}
		SleepUtils.getInstance().sleep(sleepLevel);
	}

	/****************************************************************
	 * @method Name - eval
	 * @method Description - invokes the execution based on acton code
	 * @param actionCode
	 * @param input
	 * @param output
	 ****************************************************************/
	public void eval(String actionCode, DataRow input,
			Map<String, String> output) {
		@SuppressWarnings("unused")
		Method method = null;
		try {
			Class<?> clazz = this.getClass();
			// Trace debugging, see output
			for (Method m : clazz.getDeclaredMethods())
				if (m.getName().equals(actionCode)) {
					try {
						logger.trace("Executing............." + actionCode);
						m.invoke(this, input, output);
					} catch (IllegalArgumentException e) {
						logger.handleError("Exception Caught : "
								+ e.getMessage());
					} catch (IllegalAccessException e) {
						logger.handleError("Exception Caught : "
								+ e.getMessage());
					} catch (InvocationTargetException e) {
						logger.handleError("Exception Caught : "
								+ e.getMessage());
					}
				}
		} catch (SecurityException e) {
			logger.trace(e.getMessage());
		}
	}

	public String toString() {
		return "BuiltinActionsDriver()";
	}
}
