package com.xavient.tap.selenium.utils;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class FileUtils {

	public List<File> fileList(String folder) {
		return null;

	}

	/****************************************************************
	 * @param sPath
	 * @return
	 ****************************************************************/
	public static boolean makePath(String sPath) {
		File file = new File(sPath);
		if (file.exists()) {
			return true;
		}
		if (!makePath(file.getParent())) {
			return false;
		}
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file.exists();
	}

	/****************************************************************
	 * @param sFile
	 * @return
	 ****************************************************************/
	public static boolean fileExists(String sFile) {
		return isExist(sFile);
	}

	/****************************************************************
	 * @param sFolder
	 * @return
	 ****************************************************************/
	public static boolean folderExists(String sFolder) {
		return isExist(sFolder);
	}

	/****************************************************************
	 * @param sName
	 * @return
	 ****************************************************************/
	private static boolean isExist(String sName) {
		return new File(sName).exists();
	}

	/****************************************************************
	 * @param sFolderPath
	 ****************************************************************/
	public static void removeFolder(String sFolderPath) {
		File file = new File(sFolderPath);
		file.delete();
	}

	/****************************************************************
	 * @param sFolderPath
	 * @return
	 ****************************************************************/
	public static boolean makeFolder(String sFolderPath) {
		if (!new File(sFolderPath).isDirectory())
			return new File(sFolderPath).mkdir();
		else
			return true;
	}

	public static String getTempPath() {
		return "";
	}

	/****************************************************************
	 * @param sFile
	 ****************************************************************/
	public static void createTextFile(String sFile) {
		File file = new File(sFile);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
