package com.xavient.tap.selenium.appdriver;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import jxl.JXLException;
import jxl.read.biff.BiffException;
import jxl.write.biff.RowsExceededException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import com.cb.utils.ChromeDriverEx;
import com.cb.utils.MyChromeDriverManager;
import com.locators.selenium.util.Createlocators;
import com.locators.selenium.util.Xlprocessing;
import com.xavient.tap.selenium.actions.AppDriver;
import com.xavient.tap.selenium.actions.Harness;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.DataRow;

public class TAPDriver extends AppDriver {
	
	public String strObject;
	public List<String> Tagnames = new ArrayList<String>();
	public  static String locatorpath1 = "D:/MozillanewLocators.xls";
	Createlocators cret=new Createlocators();
	Xlprocessing xlsw = new Xlprocessing();
	public TAPDriver () throws IOException, RowsExceededException, JXLException {
		
		
		Tagnames=xlsw.xlsreader("D:/tagname.xls","Locators");
		//xlsw.writelocatorxls(Tagnames, locatorpath1, "Tagnames");
	}
	
	
	/****************************************************************
	 * @Method Name : login
	 * @Method Description : User authentication by logging in 
	 * @param args
	 *            :input,output
	 * @param Sample
	 *            Usage : login(input, output);
	 * @throws InterruptedException
	 * @throws AWTException
	 * @throws IOException
	 * @throws JXLException 
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 ****************************************************************/
	public void Mozillasupport(DataRow input, DataRow output) throws IOException, InterruptedException, AWTException, JXLException, ParserConfigurationException, SAXException {
		
		
		String title=driver.getTitle();
		Harness.cExecutor.saveOrCompare("MSupport", "HomePage", driver, false);
		if (title
				.contains(
						"Mozilla Support")) {
			oRPT.log("Landed on Mozilla Support Page","Landed on Mozilla Support Page",ResultType.PASSED,"Landed on Mozilla Support Page","Landed on Mozilla Support Page",true);
			
		} else {
			oRPT
					.log(
							"Landed on Mozilla Support Page","Landed on Mozilla Support Page",ResultType.FAILED,
							"No Landed on Mozilla Support Page",
							"Landed on Mozilla Support Page",true);
		}
		
		//cret.ByTagxpathcreate(driver,Tagnames);
		//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"HomePage");
		try {
			
			
		
			// Click on Basic Page
			strObject = xlsw.getxpathByIndex(locatorpath1, "HomePage", driver, "index_49");
			WebElement product=driver.findElement(By.xpath(strObject));
			//WebElement product = waitForWebElement(By.xpath("//a[@href='/en-US/products/firefox']"), 200);
			
			
			product.click();
			
			
			Harness.cExecutor.saveOrCompare("MSupport", "BasicPage", driver, false);
			oRPT.log("Firefox Product page","Firefox Product page", ResultType.PASSED,
					"Firefox Product page should be visible",
					"Firefox Product page should is visible", true);
			
		} catch (Exception e) {
			oRPT.log("Firefox Product page","Firefox Product page", ResultType.FAILED,
					"Firefox Product page should be visible",
					"Firefox Product page should is visible", true);
			xlsw.recoverxpath();
			e.printStackTrace();
			driver.quit();
		}

		
	}	
	
	
	public void BasicSupport(DataRow input, DataRow output) throws IOException, InterruptedException, AWTException, JXLException, ParserConfigurationException, SAXException {
	
		//cret.ByTagxpathcreate(driver,Tagnames);
		//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"BasicPage");
		strObject = xlsw.getxpathByIndex(locatorpath1, "BasicPage", driver, "index_67");
		
		WebElement basic=driver.findElement(By.xpath(strObject));
		basic.click();
		//driver.findElement(By.xpath("//a[@href='/en-US/products/firefox/basic-browsing-firefox']")).click();
	    waitForPageToLoad(driver,"Basic Browsing", 20);
	    
		oRPT.log("Firefox basic browsing page","Firefox basic browsing page", ResultType.PASSED,
				"Firefox basic browsing page should be displayed",
				"Firefox basic browsing page is Displayed", true);
		
		Harness.cExecutor.saveOrCompare("MSupport", "BasicBrowsingPage", driver, false);
			
			
				}
	/****************************************************************
	 * @Method Name : logout
	 * @Method Description : Log out 
	 * @param args
	 *            :input,output
	 * @param Sample
	 *            Usage : logout(input, output);
	 * @throws InterruptedException
	 * @throws AWTException
	 * @throws IOException
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws JXLException 
	 ****************************************************************/
	public void ContusPage(DataRow input, DataRow output) throws IOException, InterruptedException, AWTException, ParserConfigurationException, SAXException, JXLException {
		
		//cret.ByTagxpathcreate(driver,Tagnames);
		//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"BasicBrowsingPage");
		
		
		strObject = xlsw.getxpathByIndex(locatorpath1, "BasicBrowsingPage", driver, "index_128");
		
		WebElement Contactus=driver.findElement(By.xpath(strObject));
		Contactus.click();
		/*driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.CONTROL);
	    driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.ENTER);*/
	    waitForPageToLoad(driver,"Contacts", 20);
	    oRPT.log("Contact Us Page","Contact Us Page", ResultType.PASSED,
				"Contact Us Page should be visible",
				"Contact Us Page is visible", true);
	    Thread.sleep(5000);
	    Harness.cExecutor.saveOrCompare("MSupport", "Contactuspage", driver, false);
	 //cret.ByTagxpathcreate(driver,Tagnames);
	  //xlsw.writelocatorxls(cret.relxpath,locatorpath1,"Contactuspage");
	    driver.quit();
	    
	}
	
	
	
	public void demoRunChrome(DataRow input,DataRow output){
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/drivers/chromedriver.exe");
		try{
		 ChromeDriverEx driver = MyChromeDriverManager.getChromeDriverEx();
		 
		 driver.manage().window().maximize();
		 driver.get("https://support.mozilla.org/en-US/");
		    waitForPageToLoad(driver,"Mozilla Support", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1", "MozillaSupportHomepage", driver,false);
		
		    driver.findElement(By.xpath("//a[@href='/en-US/products/firefox']")).click();
		    waitForPageToLoad(driver,"Firefox Help", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1", "MozillaDesktopSupportPage", driver, false);
		    
		    driver.findElement(By.xpath("//a[@href='/en-US/products/firefox/basic-browsing-firefox']")).click();
		    waitForPageToLoad(driver,"Basic Browsing", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1","SimpleBrowsingPage", driver, false);
		    
		    driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.CONTROL);
		    driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.ENTER);
		    waitForPageToLoad(driver,"Contacts", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1", "CotactUsPage", driver, false);
		    oRPT.passed("Test Passed", "Test Passed", "Test Passed", "Test Passed");
		    driver.quit();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void waitForPageToLoad(WebDriver driver, String title, int timeout){
		WebDriverWait wait = new WebDriverWait(driver,timeout);
		//wait.until(ExpectedConditions.titleContains(title));
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
	}
}
	
