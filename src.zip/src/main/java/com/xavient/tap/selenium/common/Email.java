/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xavient.tap.selenium.common;

//import auto.*;

/**
 * 
 * @author dv81650
 */
public class Email {

	/** Creates a new instance of ServerAppUtil */

	public static void sendEmail(String recipients[], String subject, String from, String ApplicationName) {
		try {
			String msg = "";
				msg = "Hi Team," + "\n\n"
						+ "The execution of "+ApplicationName +" has been completed.\n"
						+ "Execution Status: \n"
						+"Passed: "+com.xavient.tap.selenium.harness.Harness.passedCount+"\n"
						+"Failed: "+com.xavient.tap.selenium.harness.Harness.failedCount+"\n"
						+"Warning: "+com.xavient.tap.selenium.harness.Harness.warningCount+"\n"
						+"Not Completed: "+com.xavient.tap.selenium.harness.Harness.notCompletedCount
						+ "\n\n" + "Thank You.";

			try {
				ServerAppUtil.postMail(recipients,  subject, msg, from,
						"");

			} catch (Exception e) {
				System.out.println("Sending email error" + e);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
