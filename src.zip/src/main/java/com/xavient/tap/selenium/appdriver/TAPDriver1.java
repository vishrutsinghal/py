package com.xavient.tap.selenium.appdriver;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import jxl.JXLException;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import com.cb.utils.ChromeDriverEx;
import com.cb.utils.MyChromeDriverManager;
import com.locators.selenium.util.Createlocators;
import com.locators.selenium.util.Xlprocessing;
import com.xavient.tap.selenium.actions.AppDriver;
import com.xavient.tap.selenium.actions.Harness;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.utils.DataRow;

public class TAPDriver1 extends AppDriver {
	
	public String strObject;
	public List<String> Tagnames = new ArrayList<String>();
	public  static String locatorpath1 = "D:/Mozillalocators.xls";
	Createlocators cret=new Createlocators();
	Xlprocessing xlsw = new Xlprocessing();
	public TAPDriver1 () throws IOException, BiffException {
		
		
		Tagnames=xlsw.xlsreader("D:/tagname.xls","Locators");
	}
	
	
	/****************************************************************
	 * @Method Name : login
	 * @Method Description : User authentication by logging in 
	 * @param args
	 *            :input,output
	 * @param Sample
	 *            Usage : login(input, output);
	 * @throws InterruptedException
	 * @throws AWTException
	 * @throws IOException
	 * @throws JXLException 
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 ****************************************************************/
	public void login(DataRow input, DataRow output) throws IOException, InterruptedException, AWTException, JXLException, ParserConfigurationException, SAXException {
		
		
		String title=driver.getTitle();
		Harness.cExecutor.saveOrCompare("XAPTestCase1", "XAPLaunchPage", driver, false);
		if (title
				.contains(
						"XAP")) {
			oRPT.log("Landed on XAP Page","Landed on XAP Page",ResultType.PASSED,"Landed on XAP Page","Landed on XAP Page",true);
			
		} else {
			oRPT
					.log(
							"Landed on XAP Page","Landed on XAP Page",ResultType.FAILED,
							"No Landed on XAP Page",
							"Landed on XAP Page",true);
		}
		
		//cret.ByTagxpathcreate(driver,Tagnames);
		//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"Loginpage");
		try {
			
			
			String userID = input.get("Login-userID");
			String password = input.get("Login-password");
			
			
			// Enter userID and Password
			strObject = xlsw.getxpathByIndex(locatorpath1, "Loginpage", driver, "index_24");
			WebElement OlbUserId = waitForWebElement(By.xpath(strObject), 200);
			OlbUserId.sendKeys(userID);
			//OlbUserId.sendKeys(Keys.ENTER);

			strObject = xlsw.getxpathByIndex(locatorpath1, "Loginpage", driver, "index_29");
			WebElement OlbPassword = waitForWebElement(By.xpath(strObject), 200);
			OlbPassword.sendKeys(password);
			OlbPassword.sendKeys(Keys.ENTER);
			
			Thread.sleep(5000);
			Harness.cExecutor.saveOrCompare("XAPTestCase1", "XAPLogin", driver, false);
			oRPT.log("Login page","Login page", ResultType.PASSED,
					"Application should login",
					"Application logged in successfully", true);
			
		} catch (Exception e) {
			oRPT.log("Login page","Login page", ResultType.FAILED,
					"Application should login",
					"Unable to login to the application", true);
			xlsw.recoverxpath();
			e.printStackTrace();
		}

		
	}	
	
	
	public void XavDashboard(DataRow input, DataRow output) throws IOException, InterruptedException, AWTException, JXLException, ParserConfigurationException, SAXException {
	
		Thread.sleep(5000);
		oRPT.log("XAP Dashboard is Displayed","XAP Dashboard is Displayed", ResultType.PASSED,
				"XAP Dashboard is Displayed",
				"XAP Dashboard is Displayed", true);
		Thread.sleep(5000);
		Harness.cExecutor.saveOrCompare("XAPTestCase1", "XAPDashboard", driver, false);
			
		
			//cret.ByTagxpathcreate(driver,Tagnames);
			//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"Dashboard");
			/*strObject = xlsw.getxpathByIndex(locatorpath1, "Dashboard", driver, "index_77");
			 
			WebElement useroptions = waitForWebElement(By.xpath(strObject), 200);
			useroptions.isDisplayed();*/
			
			
			//cret.ByTagxpathcreate(driver,Tagnames);
			//xlsw.writelocatorxls(cret.relxpath,locatorpath1,"UserOption");
		
	}
	/****************************************************************
	 * @Method Name : logout
	 * @Method Description : Log out 
	 * @param args
	 *            :input,output
	 * @param Sample
	 *            Usage : logout(input, output);
	 * @throws InterruptedException
	 * @throws AWTException
	 * @throws BiffException
	 * @throws IOException
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 ****************************************************************/
	public void logout(DataRow input, DataRow output) throws BiffException,
			IOException, InterruptedException, AWTException, ParserConfigurationException, SAXException {
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//label[text()='Syed Faeez Sultan']"))).click(driver.findElement(By.xpath("//a[text()='Log Out ']"))).build().perform();
		oRPT.log("XAP logout","XAP logout successfully", ResultType.PASSED,
				"XAP logout successfully",
				"XAP logout successfully", true);
		Thread.sleep(2000);
		Thread.sleep(5000);
		Harness.cExecutor.saveOrCompare("XAPTestCase1", "XAPLogout", driver, false);
		driver.quit();	
	}
	
	
	
	public void demoRunChrome(DataRow input,DataRow output){
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/drivers/chromedriver.exe");
		try{
		 ChromeDriverEx driver = MyChromeDriverManager.getChromeDriverEx();
		 
		 driver.manage().window().maximize();
		 driver.get("https://support.mozilla.org/en-US/");
		    waitForPageToLoad(driver,"Mozilla Support", 20);
		    Thread.sleep(3000);
		  
		    Harness.cExecutor.saveOrCompare("TestCase1", "MozillaSupportHomepage", driver,false);
		  
		    driver.findElement(By.xpath("//a[@href='/en-US/products/firefox']")).click();
		    waitForPageToLoad(driver,"Firefox Help", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1", "MozillaDesktopSupportPage", driver, false);
		    
		    driver.findElement(By.xpath("//a[@href='/en-US/products/firefox/basic-browsing-firefox']")).click();
		    waitForPageToLoad(driver,"Basic Browsing", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1","SimpleBrowsingPage", driver, false);
		    
		    driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.CONTROL);
		    driver.findElement(By.linkText("Contact Us")).sendKeys(Keys.ENTER);
		    waitForPageToLoad(driver,"Contacts", 20);
		    Thread.sleep(3000);
		    Harness.cExecutor.saveOrCompare("TestCase1", "CotactUsPage", driver, false);
		    oRPT.passed("Test Passed", "Test Passed", "Test Passed", "Test Passed");
		    driver.quit();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static void waitForPageToLoad(WebDriver driver, String title, int timeout){
		WebDriverWait wait = new WebDriverWait(driver,timeout);
		//wait.until(ExpectedConditions.titleContains(title));
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
	}
}
	
