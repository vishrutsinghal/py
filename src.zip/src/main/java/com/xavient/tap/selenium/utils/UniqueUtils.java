package com.xavient.tap.selenium.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UniqueUtils {

	public String uniqueString(String str) {

		String[] parsed = new String[2];
		parsed = parse(str);
		if (parsed.length==0) {
			logger.handleError("Invalid input : " + str);
			return "????";
		}
		List<Character> domain;
		if (parsed[1].equals(""))
			domain = getDomain("0");
		else
			domain = getDomain(parsed[1]);

		int domLen = domain.size();
		int outLen = Integer.parseInt(parsed[0]);
		int nSecs = Math.abs((int) (beginTm.getTime() - new Date().getTime()));
		String uniqueString = "";

		while (uniqueString.length() < outLen) {
			int n = nSecs % domLen;
			uniqueString = domain.get(n) + uniqueString;
			nSecs = nSecs / domLen;
		}

		return uniqueString;
	}

	/****************************************************************
	 * @param str
	 * @return
	 ****************************************************************/
	private String[] parse(String str) {
		String[] result = new String[2];
		Pattern pattern = Pattern.compile("^\\s*(\\d+)(\\w*)\\s*$");
		Matcher match = pattern.matcher(str);
		while (match.find()) {
			result[0] = match.group(1);
			result[1] = match.group(2);
		}
		return result;
	}

	/****************************************************************
	 * @param str
	 * @return
	 ****************************************************************/
	private List getDomain(String str) {
		List<Character> domain = new ArrayList<Character>();
		String[] variants = { "A", "a", "0" };
		for (String variant : variants) {
			if (str.contains(variant)) {
				switch (variant.charAt(0)) {
				case 'A':
					domain = append('A', 26);
					break;
				case 'a':
					domain = append('a', 26);
					break;
				case '0':
					domain = append('0', 10);
				}
			}
		}
		return domain;
	}

	/****************************************************************
	 * @param startChar
	 * @param numChars
	 * @return
	 ****************************************************************/
	private List append(char startChar, int numChars) {
		List domain = new ArrayList<Character>();
		if (!Character.isDigit(startChar)) {
			int asciiCode = (int) startChar;
			for (int ix = asciiCode; ix <= asciiCode + numChars - 1; ix++) {
				domain.add((char) ix);
			}
		} else {
			for (int ix = Integer.parseInt("" + startChar); ix <= numChars - 1; ix++)
				domain.add(ix);
		}
		return domain;
	}

	private Logger logger = new Logger(this);
	private Date beginTm;
	public static final UniqueUtils singleton = new UniqueUtils();

	public UniqueUtils() {
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		beginTm = new Date(c.get(Calendar.YEAR), 1, 1);
	}

	public String toString() {
		return "UniqueUtils()";
	}
}
