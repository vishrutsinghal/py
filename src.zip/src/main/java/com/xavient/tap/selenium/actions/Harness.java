package com.xavient.tap.selenium.actions;

import java.io.IOException;

import com.cb.uitester.ComparisonExecutor;
import com.cb.uitester.TestCaseExecutor;
import com.xavient.tap.selenium.common.Email;
import com.xavient.tap.selenium.common.FileUtilities;
import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.reporting.HtmlSummaryReport;


public class Harness {

	com.xavient.tap.selenium.harness.Harness oHarness;
	FileUtilities fileUtility = new FileUtilities();
	ConfigParams CONFIG = ConfigParams.SINGLETON;
	public static ComparisonExecutor cExecutor = ComparisonExecutor.getUIComparisonExecutor();

	public static TestCaseExecutor tcExecutor;

	/****************************************************************
	 * @Method Name : testHarness
	 * @Method Description : Delete and create the temporary folder, Starts the execution flow
	 * @param args
	 *            :String[]
	 * @param Sample
	 *            Usage : testHarness(String[] args);
	 * @throws Exception 
	 ****************************************************************/
	public void testHarness(String[] args) throws Exception {
		//Online Business Center - Login screen is not displayed Successfully 
		//fileUtility.makeLibAndResourcesReady();
		//Delete and create the required folder for execution
		fileUtility.deleteTempFolder();
		fileUtility.deleteFolder();
		fileUtility.createFolder();
		fileUtility.createTxtFile();
		oHarness = new com.xavient.tap.selenium.harness.Harness();
		oHarness.runTestSet();
	}

	public static void main(String args[]) throws Exception {
		try {
			tcExecutor = new TestCaseExecutor();
			Harness oHarness = new Harness();
			oHarness.testHarness(args);
			tcExecutor.createReport();
			HtmlSummaryReport htmlSummaryReport = new HtmlSummaryReport();
			htmlSummaryReport.createHTMLSummaryReport(AppDriver.summaryMAP);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Execution Status: ");
			System.out.println("Passed: "+com.xavient.tap.selenium.harness.Harness.passedCount);
			System.out.println("Failed: "+com.xavient.tap.selenium.harness.Harness.failedCount);
			System.out.println("Warning: "+com.xavient.tap.selenium.harness.Harness.warningCount);
			System.out.println("Not Completed: "+com.xavient.tap.selenium.harness.Harness.notCompletedCount);
			
			ConfigParams CONFIG = ConfigParams.SINGLETON;
			if(CONFIG.properties.getProperty("Email").equalsIgnoreCase("true")){
				String recipientsList = CONFIG.properties.getProperty("recipients");
				String recipients[] = recipientsList.split(",");
				String subject = CONFIG.properties.getProperty("subject");
				String from = CONFIG.properties.getProperty("from");
				String ApplicationName = CONFIG.properties.getProperty("ApplicationName");
				Email.sendEmail(recipients,  subject, from, ApplicationName);
				System.out.println("Sending email to recipients");
			}
			try {
				//Kill the process after the execution is completed. 
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			if(com.xavient.tap.selenium.harness.Harness.failedCount > 0){
				throw new Exception( "Selenium Run Fails!");
				}else if (com.xavient.tap.selenium.harness.Harness.failedCount == 0 && com.xavient.tap.selenium.harness.Harness.passedCount == 0) {
				throw new Exception( "Selenium Run Fails!");
				}else{
				System.out.println("Selenium Run Successfull!");
				}

		}
	}
}