package com.xavient.tap.selenium.qcRESTConnection;

import java.util.HashMap;
import java.util.Map;

public class createEntity {
	
	 private RestConnector con;
	 
	 public createEntity(){
		 con = RestConnector.getInstance();
	 }
	
	 public String createEnt(String collectionUrl, String postedEntityXml)
		        throws Exception {
		 Map<String, String> requestHeaders = new HashMap<String, String>();
		    requestHeaders.put("Content-Type", "application/xml");
		    requestHeaders.put("Accept", "application/xml");

		    // As can be seen in the implementation below, creating an entity
		    //is simply posting its xml into the correct collection.
		    Response response = con.httpPost(collectionUrl,
		        postedEntityXml.getBytes(), requestHeaders);

		    Exception failure = response.getFailure();
		    
		  if (failure != null) {
		        throw new Exception(response.toString());
		    }

		    /*
		     Note that we also get the xml of the newly created entity.
		     at the same time we get the url where it was created in a
		     location response header.
		    */
		  String entityUrl = null;
		  if(response.getResponseHeaders().get("Location")!=null){
			  entityUrl =
		       response.getResponseHeaders().get("Location").iterator().next();
		  }

		    return entityUrl;
	 }

}
