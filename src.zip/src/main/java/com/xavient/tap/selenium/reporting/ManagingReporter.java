package com.xavient.tap.selenium.reporting;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.io.*;

import com.xavient.tap.selenium.common.FileUtilities;
import com.xavient.tap.selenium.engine.ResultReporter;
import com.xavient.tap.selenium.engine.TestResult;
import com.xavient.tap.selenium.engine.TestResult.ResultType;
import com.xavient.tap.selenium.engine.TestResultTracker.Reporter;
import com.xavient.tap.selenium.harness.ConfigParams;
import com.xavient.tap.selenium.harness.ResourcePaths;
import com.xavient.tap.selenium.utils.FileUtils;
import com.xavient.tap.selenium.utils.Logger;

public class ManagingReporter implements ResultReporter {
	public ManagingReporter(String resultsFolder, String[] reporterSelection,
			ResourcePaths oResourcePaths) {
		this.resourcePaths = oResourcePaths;
		this.reporters = selectReporters(resultsFolder, reporterSelection);
	}

	final String[] supportedReports = { "ScreenDump", "HtmlEvent",
			"ExcelReport" };

	/****************************************************************
	 * @param resultsFolder
	 * @param reporterSelection
	 * @return
	 ****************************************************************/
	private List<Reporter> selectReporters(String resultsFolder,
			String[] reporterSelection) {
		logger.trace("Select Reporters:", reporterSelection);
		for (String reporterName : supportedReports) {
			boolean isSelected = false;
			if (reporterSelection.length<=0) {
				isSelected = true;
			} else {
				for (String selReport : reporterSelection) {
					if (selReport.equals(reporterName)) {
						isSelected = true;
						break;
					}
				}
			}
			if (isSelected) {
				Reporter reporter = makeReporter(resultsFolder, reporterName);
				reporters.add(reporter);
				logger.trace("Reporter selected:", reporter);
			}
		}
		return reporters;
	}

	public void open(Map headers) {

		for (Reporter reporter : reporters) {
			try {
				((ResultReporter) reporter).open(headers);
				logger.trace("opened reporter", reporter);
			} catch (Exception e) {
				logger.handleError("Error opening reporter", e, reporter);
			}
		}
	}

	public void close() {

		for (Reporter reporter : reporters) {
			try {
				((ResultReporter) reporter).close();
			} catch (Exception e) {
				logger.warning("Error closing reporter", e, reporter);
			}
		}
	}

	public void start(TestResult result) {
		for (Reporter reporter : reporters) {
			try {
				reporter.start(result);
			} catch (Exception e) {
				logger.warning("Error in start", e, reporter, result);
			}
		}
	}

	public void log(TestResult result, ResultType rsType, Map details) {
		for (Reporter reporter : reporters) {
			try {
				reporter.log(result, rsType, details);
			} catch (Exception e) {
				logger.warning("Error in reporting", e, reporter, result,
						rsType, details);
			}
		}
	}

	public void finish(TestResult result, ResultType rsType, Object details) {
		for (Reporter reporter : reporters) {
			try {
				reporter.finish(result, rsType, details);
			} catch (Exception e) {
				logger.warning("Error in finish", e, reporter, result, rsType,
						details);
			}
		}
	}

	/****************************************************************
	 * @param resultsFolder
	 * @param reporterName
	 * @return
	 ****************************************************************/
	public Reporter makeReporter(String resultsFolder, String reporterName) {
		Reporter reporter = null;
		try {
			if (reporterName.equalsIgnoreCase("ExcelReport")) {
				resultsFolder = readTxtFile();
				reporter = new ExcelReporter(resultsFolder
						+ "/ExecutionReport.xls", resourcePaths.makePath(
						"templates", "ReportTemplate.xls"));
			} else if (reporterName.equalsIgnoreCase("HtmlEvent")) {
				resultsFolder = readTxtFile();
				String htmlEventsFolder = resultsFolder + "/HtmlEvents";
				if (!(FileUtils.makeFolder(htmlEventsFolder))) {
					logger.handleError("Cant create/access html reports folder; these will not be generated: "
							+ htmlEventsFolder);
				}
				reporter = new HtmlEventReporter(htmlEventsFolder, null);
			} else if (reporterName.equalsIgnoreCase("ScreenDump")) {
				resultsFolder = readTxtFile();
				String screenDumpFolder = resultsFolder + "/ScreenShots";
				if (!FileUtils.makeFolder(screenDumpFolder)) {
					logger.handleError("Cant create/access ScreenShots folder; these will not be generated: "
							+ screenDumpFolder);
				}
				reporter = new ScreenDumpManager(screenDumpFolder);
			}
		} catch (Exception e) {
			logger.handleError("Failed to instantiate report: " + reporterName,
					e);
		}
		return reporter;
	}

	public String toString() {
		return "ManagingReporters()";
	}

	private List<Reporter> reporters = new ArrayList<Reporter>();
	private ResourcePaths resourcePaths;
	private Logger logger = new Logger(this);

	/****************************************************************
	 * @return
	 * @throws IOException
	 ****************************************************************/
	public static String readTxtFile() throws IOException {

		String content = null;
		FileUtilities fileUtilities = new FileUtilities();
		ConfigParams CONFIG = ConfigParams.SINGLETON;
		String folderPath = CONFIG.properties.getProperty("FolderPath");
		File file = fileUtilities.loadFile(folderPath + "/FolderName.txt");
		FileReader reader = null;
		try {
			reader = new FileReader(file);
			char[] chars = new char[(int) file.length()];
			reader.read(chars);
			content = new String(chars);
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
		return content;
	}
}
