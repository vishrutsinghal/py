package com.xavient.tap.selenium.utils;

import java.util.HashMap;
import java.util.Map;

public class DataRow extends HashMap<String, String> {

	public DataRow(Map<String, String> data) {
		this.putAll(data);
	}

	public DataRow() {
	}

	public String toString() {
		StringBuilder mapValues = new StringBuilder();
		//String mapValues = "";
		//Sonar Fix :  Performance - Inefficient use of keySet iterator instead of entrySet iterator
		Iterable<java.util.Map.Entry<String, String>> keys = this.entrySet();
		for (java.util.Map.Entry<String, String> key : keys) {
			mapValues = mapValues.append(key.getKey().toString()).append(" = ").append(key.getValue().toString()).append(";");
			//mapValues = mapValues + key + " = " + this.get(key) + ";";

		}
		return "{" + mapValues.toString() + "}";
	}

}