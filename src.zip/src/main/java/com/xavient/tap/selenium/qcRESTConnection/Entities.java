package com.xavient.tap.selenium.qcRESTConnection;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "entity" })
@XmlRootElement(name = "Entities")
public class Entities {

	@XmlElement(name = "Entity", required = true)
	protected List<Entity> entity;
	@XmlAttribute(name = "TotalResults", required = true)
	protected String totalResult;

	public Entities(Entities entities) {
		totalResult = entities.getTotalResult();
		entity = new ArrayList<Entity>(entities.getEntity());
	}

	public List<Entity> getEntity() {
		return entity;
	}

	public void setEntity(List<Entity> entity) {
		this.entity = entity;
	}

	public String getTotalResult() {
		return totalResult;
	}

	public void setTotalResult(String totalResult) {
		this.totalResult = totalResult;
	}

	public Entities() {
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "fields" })
	public static class Entity {

		@XmlElement(name = "Fields", required = true)
		protected Entity.Fields fields;
		@XmlAttribute(name = "Type", required = true)
		protected String type;

		public Entity(Entity entity) {
			type = entity.getType();
			fields = new Entity.Fields(entity.getFields());
		}

		public Entity() {
		}

		public Entity.Fields getFields() {
			return fields;
		}

		public void setFields(Entity.Fields value) {
			this.fields = value;
		}

		public String getType() {
			return type;
		}

		public void setType(String value) {
			this.type = value;
		}

		@XmlAccessorType(XmlAccessType.FIELD)
		@XmlType(name = "", propOrder = { "field" })
		public static class Fields {

			@XmlElement(name = "Field", required = true)
			protected List<Field> field;

			public Fields(Fields fields) {
				field = new ArrayList<Field>(fields.getField());
			}

			public Fields() {
			}

			public List<Field> getField() {
				if (field == null) {
					field = new ArrayList<Field>();
				}
				return this.field;
			}

			@XmlAccessorType(XmlAccessType.FIELD)
			@XmlType(name = "", propOrder = { "value" })
			public static class Field {

				@XmlElement(name = "Value", required = true)
				protected List<String> value;
				@XmlAttribute(name = "Name", required = true)
				protected String name;

				public List<String> getValue() {
					if (value == null) {
						value = new ArrayList<String>();
					}
					return this.value;
				}

				public String getName() {
					return name;
				}

				public void setName(String value) {
					this.name = value;
				}

			}

		}

	}
}
