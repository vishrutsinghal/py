package com.xavient.tap.selenium.serializer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.xavient.tap.selenium.utils.DataRow;
import com.xavient.tap.selenium.utils.ExcelAccess;
import com.xavient.tap.selenium.utils.Logger;
import com.xavient.tap.selenium.utils.ExcelAccess.MapReader;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DTAccess {
	private Logger logger = new Logger(this);
	private String filePath;

	public interface RowSelector {
		boolean select(Map row, int rowIx);
	}

	public static class RowSelectorByRowId implements RowSelector {
		private String rowId;

		public RowSelectorByRowId(String rowId) {
			this.rowId = rowId;
		}

		public boolean select(Map row, int rowIx) {
			if (rowId.equals("")) {
				return true;
			} else {
				return rowId.equals((String) row.get("_rowId"));
			}
		}
	}

	public DTAccess(String excelFilePath) {
		this.filePath = excelFilePath;
	}

	public List<Map> readSheet(String sheetName) {
		return readSelectedRows(sheetName, "");
	}

	/****************************************************************
	 * @param sheetName
	 * @param selector
	 * @return
	 * @throws BiffException
	 * @throws IOException
	 ****************************************************************/
	public List<Map> readSelectedRows(String sheetName,
			final RowSelector selector) throws BiffException, IOException {
		class MyHandler extends MapReader {
			public Map outrow;
			List<Map> rows = new ArrayList();

			@Override
			public boolean handleRow(DataRow row, int rowIx) {
				if (selector == null || selector.select(row, rowIx)) {
					rows.add(row);
				}
				return true;
			}
		}

		MyHandler mh = new MyHandler();
		ExcelAccess.accessSheet(filePath, sheetName, mh);

		return mh.rows;
	}

	/****************************************************************
	 * @param sheetName
	 * @param rowId
	 * @return
	 ****************************************************************/
	public List<Map> readSelectedRows(String sheetName, String rowId) {
		RowSelector selector = new RowSelectorByRowId(rowId);
		List<Map> selectedRows = null;
		try {
			selectedRows = readSelectedRows(sheetName, selector);
		} catch (BiffException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		} catch (IOException e) {
			logger.handleError("Exception caught : " + e.getMessage());
		}
		return selectedRows;
	}

	/****************************************************************
	 * @param sheetName
	 * @return
	 ****************************************************************/
	public boolean isSheetExists(String sheetName) {
		boolean result = false;
		;
		try {
			Workbook objWorkbook;
			Sheet objWorksheet;
			int blnSheetExists;
			Workbook workbook = Workbook.getWorkbook(new File(filePath));
			String sheets[] = workbook.getSheetNames();
			for (String sheet : sheets) {
				if (sheet.equals(sheetName)) {
					result = true;
					return result;
				}
			}
		} catch (IOException e) {
		} catch (BiffException e) {
		}
		return result;
	}

	public String toString() {
		return "Accessing {" + filePath + "}";
	}
}
