# Selenium_Python_Framework
POM framework implemented in python 3.3 using Selenium-Library latest

This code is for creating framework of POM based architecture in Python, as shared in python selenium tutorials by Specialize Automation.
