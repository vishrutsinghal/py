from selenium import webdriver
import time

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--incognito")
chrome_options.setBinary("C:\\Program Files (x86)\\Google\\Chrome Beta\\Application\\chrome.exe");

driver = webdriver.Chrome("D:\PD\chromedriver.exe", chrome_options=chrome_options)
driver.get("http://google.com")
