from selenium import webdriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from pprint import pprint
from selenium.webdriver.firefox.options import Options



options = Options()
options.add_argument("--headless")



# driver = webdriver.Firefox(firefox_binary=binary)

driver=webdriver.Firefox(executable_path="D:\PD\geckodriver.exe",log_path=None)

print("Firefox Headless Browser Invoked")


# driver.get("https://iniitian.niit-tech.com/ntless/homepages.asp")
input1= []
driver.get("http://onecore.net")
print ("site alunched")
input1= driver.find_elements_by_tag_name("input")
for ini in input1:
    if ini.get_attribute("name" )is None:
        print("ini_name",ini.get_attribute("name"))
    if ini.get_attribute("id") is None:
        print ("ini",ini.get_attribute("id"))
    if ini.get_attribute("href") is None:
        print ("ini",ini.get_attribute("href"))
    if ini.get_attribute("class") is None:
        print ("ini",ini.get_attribute("class"))
    if ini.get_attribute("src") is None:
        print ("ini",ini.get_attribute("src"))
    if ini.get_attribute("alt") is None:
        print ("ini",ini.get_attribute("alt"))
    if ini.get_attribute("title") is None:
        print ("ini",ini.get_attribute("title"))
    if (ini.get_attribute("name") is None and ini.get_attribute("type") is None):
        name_title = ini.get_attribute("name")+"..."+ini.get_attribute("title")
        print ("ini",name_title)

driver.quit()



