from selenium import webdriver
from selenium.webdriver import ActionChains
import time

driver=webdriver.Chrome("D:\PD\chromedriver.exe")
driver.get("http://google.com")
driver.execute_script("window.alert('this is alert');")
time.sleep(2)
alert=driver.switch_to_alert()
alert.accept
time.sleep(2)
driver.quit()