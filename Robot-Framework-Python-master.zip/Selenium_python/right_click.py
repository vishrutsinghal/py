from selenium import webdriver
from selenium.webdriver import ActionChains
import time

driver=webdriver.Chrome("D:\PD\chromedriver.exe")
driver.get("http://google.com")
element=driver.find_element_by_link_text("हिन्दी")
print(element.is_displayed())
actionChains=ActionChains(driver)
actionChains.context_click(element).perform()
time.sleep(2)
driver.quit()
