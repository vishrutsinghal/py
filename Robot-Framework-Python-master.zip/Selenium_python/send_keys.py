import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://google.com")
search=driver.find_element_by_id('lst-ib').send_keys("python")
driver.find_element_by_name("btnK").click()
# search.send_keys(keys.ENTER)
time.sleep(3)
driver.find_element_by_id('lst-ib').clear()
time.sleep(3)
driver.quit()
