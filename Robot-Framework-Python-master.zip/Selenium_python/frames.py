from selenium import webdriver
from selenium.webdriver import ActionChains
import time

driver=webdriver.Chrome("D:\PD\chromedriver.exe")
driver.get("http://wayvermedia.com/iframe-demo.html")
driver.switch_to.frame("frame1")
time.sleep(2)
driver.quit()