from xlwt import Workbook, Formula, easyxf

wb=Workbook()
sheet1=wb.add_sheet("Sheet1")
sheet2=wb.add_sheet("Sheet2")
sheet3=wb.add_sheet("Sheet3")

styl=easyxf("pattern: pattern solid, fore_colour yellow;")
# sheet1.write(0,0,"This is sheet1")
for i in range(10):
    sheet1.write(i,0,i)

sheet1.write(10,0,Formula("SUM(A1:A10)"), styl)


sheet2.write(0,0,"This is sheet2")
sheet3.write(0,0,"This is sheet3")

sheet1.col(0).width=7000
sheet2.col(0).width=7000
sheet3.col(0).width=7000

wb.save("C:/Users/Vishrut/Desktop/WriteSheet.xls")

