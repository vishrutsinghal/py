import time
import re
from selenium import webdriver

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://www.airindia.in/contact-details.htm")
doc=driver.page_source
emails=re.findall(r'[\w\.-]+@[\w\.-]+',doc)
for email in emails:
    print (email)
driver.quit()