from selenium import webdriver
from pprint import pprint
import re

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("https://www.jetairways.com/EN/IN/JetPrivilege/Service-Centre.aspx")
# doc=driver.page_source
# print ("yes")

# emails=re.findall(r'[\w\.-]+@[\w\.-]+',doc)

# for email in emails:
#     pprint(emails)