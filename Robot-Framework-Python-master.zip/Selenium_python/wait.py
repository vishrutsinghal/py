from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://google.com")
elm=driver.find_element_by_link_text("About")
driver.implicitly_wait(5)
elm.click()
driver.close()
