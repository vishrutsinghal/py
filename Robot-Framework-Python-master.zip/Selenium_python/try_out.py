import time
from selenium import webdriver

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
# driver=webdriver.Chrome()
driver.get("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=e2fXWabgLpTT8gevto-gCg&gws_rd=ssl")
print(driver.title)
# time.sleep(8)
driver.quit()
