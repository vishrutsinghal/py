from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://bing.com")
print(driver.current_url)
print("Version is ")
print(driver.capabilities["version"])
driver.quit()