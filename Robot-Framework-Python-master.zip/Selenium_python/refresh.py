from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://wikipedia.com")
time.sleep(3)
driver.refresh()
time.sleep(3)
driver.quit()