from selenium import webdriver

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://google.com")
ids=driver.find_elements_by_xpath("//*[@class]")
for ii in ids:
    print(ii.get_attribute("class"))
driver.quit()