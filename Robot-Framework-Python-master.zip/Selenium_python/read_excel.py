import xlrd
from  selenium import webdriver
import openpyxl

file_location="C:/Users/Vishrut/Desktop/test-excel.xls"
workbook=xlrd.open_workbook(file_location)
sheet=workbook.sheet_by_index(0)
value=sheet.cell_value(0,0)
# print(value)
for col in range(sheet.ncols):
    for row in range(sheet.nrows):
        print (sheet.cell_value(row,col))

data=[[sheet.cell_value(r,c) for c in range(sheet.ncols)] for r in range(sheet.nrows)]
print(data)


file_location = "C:/Users/Vishrut/Desktop/Data.xls"
workbook=xlrd.open_workbook(file_location)
sheet=workbook.sheet_by_index(0)
value=sheet.cell_value(0,0)
if value =="URL":
    value1=sheet.cell_value(0,1)
print ("value ", value1)
driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get(value1)
URL=driver.find_elements_by_xpath("//*[@href]")
for url in URL:
    pprint(url.get_attribute("href"))
driver.quit()


print ("***********************************************")


