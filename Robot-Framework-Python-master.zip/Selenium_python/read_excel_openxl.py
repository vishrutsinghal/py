import openpyxl
from openpyxl import Workbook
from pprint import pprint

wb=openpyxl.load_workbook("C:/Users/Vishrut/Desktop/read_openxl.xlsx", data_only=True)
print (wb.sheetnames)

demo_worksheet=wb.get_sheet_by_name("Sheet1")

# for row in demo_worksheet.rows:
#     pprint(type(row))
#     pprint(row,indent=4)

# for cell in next (demo_worksheet.columns):
# for cell in next (demo_worksheet.rows):

    # pprint("Cell ",cell.column, "Row ",cell.row)
    # print ("Cell {0} {1}".format(cell.column, cell.row))
    # pprint(cell)
    # pprint(type(cell))
    # pprint(row,indent=4)
    # pprint(cell.value)

# print (demo_worksheet["a1"].font.name)

# Created a set of employees.
employee_ids1={ row[0].value for row in demo_worksheet.rows if row[0].value!="employee_id"}
# print (employee_ids1)


employee_aggregate={}
for employee in employee_ids1:
    employee_aggregate[employee]={}
    department = [row[2].value for row in demo_worksheet.rows if employee==row[0].value]
    salary = [row[1].value for row in demo_worksheet.rows if employee==row[0].value]

    employee_aggregate[employee]["Department"]=list(department)[0]
    employee_aggregate[employee]["Salary"]=list(salary)[0]


pprint (employee_aggregate)




