# from selenium.webdriver.support.wait import WebDriverWait

# # wait to make sure there are two windows open
# WebDriverWait(driver, 10).until(lambda d: len(d.window_handles) == 2)

# # switch windows
# driver.switch_to_window(driver.window_handles[1])

# # wait to make sure the new window is loaded
# WebDriverWait(driver, 10).until(lambda d: d.title != "")