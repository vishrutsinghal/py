from selenium import webdriver

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://onecore.net")
ids=driver.find_elements_by_xpath('//*[@id]')
for ii in ids:
    print(ii.get_attribute('id'))
driver.quit()
