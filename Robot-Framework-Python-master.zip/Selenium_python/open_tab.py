from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://google.com")
driver.find_element_by_tag_name("body").send_keys(Keys.CONTROL+'t')
time.sleep(2)
driver.quit()