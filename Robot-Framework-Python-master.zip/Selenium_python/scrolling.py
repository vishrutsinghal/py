from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait


driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://wikipedia.org")
login_wait = WebDriverWait(driver, 10)
# elm=driver.find_element_by_tag_name("html").send_keys(Keys.END)
elm = login_wait.until(EC.presence_of_element_located((By.TAG_NAME,'html')))
elm.send_keys(Keys.END)
time.sleep(2)
elm.send_keys(Keys.HOME)
time.sleep(2)
driver.quit()