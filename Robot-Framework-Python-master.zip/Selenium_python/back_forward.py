from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\selenium\chromedriver.exe")
driver.get("http://google.com")
elm=driver.find_element_by_link_text("About")
elm.click()
time.sleep(2)
driver.back()
time.sleep(2)
driver.forward()
time.sleep(2)
driver.quit()