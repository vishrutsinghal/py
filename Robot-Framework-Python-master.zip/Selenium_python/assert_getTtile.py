from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\chromedriver.exe")
driver.get("http://google.com")
try:
    assert "Google" in driver.title
    print("test case pass")
except Exception as e:
    print("assertion test case failed ",format(e))
driver.quit()