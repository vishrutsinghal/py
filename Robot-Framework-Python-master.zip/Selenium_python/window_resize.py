from selenium import webdriver
import time

driver=webdriver.Chrome("D:\PD\chromedriver.exe")
driver.get("http://google.com")
time.sleep(1)
driver.set_window_size(1024, 768)
time.sleep(1)
print(driver.get_window_size())
time.sleep(1)
driver.maximize_window()
print(driver.get_window_size())
driver.quit()
