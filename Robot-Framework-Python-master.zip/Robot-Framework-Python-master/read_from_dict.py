def get_locator_npsp(self, path, *args, **kwargs):
    """ Returns a rendered locator string from the Salesforce lex_locators
        dictionary.  This can be useful if you want to use an element in
        a different way than the built in keywords allow.
    """
    locator = npsp_lex_locators
    for key in path.split('.'):
        locator = locator[key]
    main_loc = locator.format(*args, **kwargs)
    return main_loc
