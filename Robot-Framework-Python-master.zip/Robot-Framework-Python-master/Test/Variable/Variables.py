__author__ = 'Aditya Roy'

URL = 'http://newtours.demoaut.com/'
title = 'Welcome: Mercury Tours'
timeout = '3s'
UserName = 'Aditya'
Password = 'Test123'


U_FirstName = 'Aditya'
U_LastName = 'Roy'
U_phone = '7501451160'
U_userID = 'aditya.qa14@gmail.com'
U_country = 'INDIA'
U_userName = 'aditya.qa14@gmail.com'
U_password = 'Test123'
U_confirmPassword = 'Test123'