import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class CreateLocators
{
	public  List<String> relxpath = null;
	public static WebDriver driver = null;
	
	/*creates xpath using the tagnames from the excel-sheet and the tagnames from the webpage */
	public  void createXpathByTagname(WebDriver driver, List<String> tagnames) throws IOException, RowsExceededException, WriteException, BiffException
    {
           try
           {
           relxpath= new ArrayList<String>();
      
           for(String tagname:tagnames){
     List<WebElement> elementsinputn = driver.findElements(By.tagName(tagname));
  
     for(WebElement ele : elementsinputn)
           
     {     
           String temp1;
           //creates xpath based on attribute name
           String temp = ele.getAttribute("name");
           if(temp!=null)
                  if(temp.length()!=0)
                  {
           relxpath.add("//"+tagname+"[@name=\""+temp+"\"]");
                  }
           
         //creates xpath based on attribute id
           temp = ele.getAttribute("id");
           if(temp!=null)
                  if(temp.length()!=0)
                  {
           relxpath.add("//"+tagname+"[@id=\""+temp+"\"]");
                  }
           
         //creates xpath based on attribute href
           temp = ele.getAttribute("href");
           
           if(temp!=null)
                  if(temp.length()!=0)
                  {
           relxpath.add("//"+tagname+"[@href=\""+temp+"\"]");
                  }
           
         //creates xpath based on text() 
           temp = ele.getText();
           if(temp!=null)
                  if(!temp.isEmpty())
                  {
                        char ch[] = temp.toCharArray();
                        int count=0;
                        for(Character c:ch)
                        {      count++;
                               int i=c;
                              
                               if((i==32)|(i==10)|(i==9))
                               {
                                      if(i==10|i==9)
                                      {
                                             temp=" ";
                                             break;
                                      }
                                      if(count>2){
                                             temp=" ";
                                             break;
                                      }
                               }
                               if(count>2)
                                      break;
                        }
                        if(!temp.equals(" ")){
                        if(temp.length()<125){
                               
                               relxpath.add("//"+tagname+"[text()=\""+temp+"\"]");
                              
                               
                        }}
                  }
           
         //creates xpath based on attribute class
           temp = ele.getAttribute("class");
           if(temp!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@class=\""+temp+"\"]");
                  }
           
         //creates xpath based on attribute src
           temp = ele.getAttribute("src");
           if(temp!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@src=\""+temp+"\"]");
                  }
           
         //creates xpath based on attribute alt
           temp = ele.getAttribute("alt");
           if(temp!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@alt=\""+temp+"\"]");
                  }
           
         //creates xpath based on attribute title
           temp = ele.getAttribute("title");
           if(temp!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@title=\""+temp+"\"]");
                  }
           
         //creates xpath based on attributes name and type
           temp = ele.getAttribute("name");  
           temp1 = ele.getAttribute("type");
           if(temp!=null&&temp1!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@type=\""+temp1+"\" and @name=\""+temp+"\"]");
                  }
           
         //creates xpath based on attributes id and type
           temp = ele.getAttribute("id");
           temp1 = ele.getAttribute("type");
           if(temp!=null&&temp1!=null)
                  if(temp.length()!=0){
           relxpath.add("//"+tagname+"[@type=\""+temp1+"\" and @id=\""+temp+"\"]");
                  }
     }
           }}
           catch(Exception e)
     {
           e.printStackTrace();
     }
     
    }

}
