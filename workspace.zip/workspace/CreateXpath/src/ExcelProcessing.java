import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jxl.JXLException;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExcelProcessing 
{
	//reads the excel sheet which user has created to fetch all the tagnames.
	//returns the list of tagnames
	public List<String> xlsReader(String path, String Sheetname) throws BiffException, IOException {
		List<String> tagnames = new ArrayList<String>();
		Workbook workBook = Workbook.getWorkbook(new File(path));
		String[] sheetNames = workBook.getSheetNames();
		Sheet sheet = null;
		for (int sheetNumber = 0; sheetNumber < sheetNames.length; sheetNumber++) 
		{

			sheet = workBook.getSheet(sheetNames[sheetNumber]);
			int row = sheet.getRows();
			if (sheetNames[sheetNumber].equals(Sheetname))
				System.out.println("The tagnames present are");
				for (int columns = 0; columns < row; columns++) 
				{
					
					System.out.println(sheet.getCell(0, columns).getContents());
					tagnames.add(sheet.getCell(0, columns).getContents());
				}

		}
		workBook.close();
		return tagnames;
	}
	
	/*creates the new excel-sheet at provided path with sheetname and writes
	  the tagnames into it with index values.*/
	public void writeTagnameToXls(List<String> locators, String path, String sheetname)throws IOException, RowsExceededException, JXLException {
		boolean createflag = true;
        FileOutputStream fo = null;
		WritableWorkbook wb = null;
		WritableSheet ws = null;
		    
		fo = new FileOutputStream(path);
		wb = Workbook.createWorkbook(fo);
		if (createflag) 
		{

					ws = wb.createSheet(sheetname, 1);

					int row = 0;
					for (int i = 0; i < locators.size(); i++) 
					{
						if (locators.get(i).contains("=null"))
							locators.remove(i);

					}
					for (String locator : locators) 
					{
						Label label1 = new Label(0, row, "index_" + row);
						Label label = new Label(1, row, locator);
						
						row = row + 1;
						ws.addCell(label);
						ws.addCell(label1);
					}
					wb.write();
					wb.close();
					System.out.println("Tagnames are written into excel");
		}
	}
			
			
	/*modifies the excel-sheet to write all the xpath created into the sheet with sheetname provided*/					
	public static void modifyExistingExcel(List<String> locators, String path, String sheetname)
			throws BiffException, IOException, RowsExceededException, WriteException
	{
		Workbook workbook1 = Workbook.getWorkbook(new File(path));
		WritableWorkbook copy = Workbook.createWorkbook(new File(path), workbook1);
		WritableSheet ws = copy.getSheet(sheetname);
		int row_div =0;
		int row_a =0;
		int row_span=0;
		int row_im=0;
		int row_te=0;
		int row_h=0;
		int row_fo=0;
		int row = ws.getRows(); // last rows
		for (String locator : locators)
		{
			if(locator.contains("//input["))
			{
			Label label1 = new Label(0, row, "index_0_" + row);
			Label label = new Label(1, row, locator);
			
			row = row + 1;
			ws.addCell(label);
			ws.addCell(label1);
			}
			
			if(locator.contains("//div["))
			{
			
			Label label1 = new Label(0, row, "index_1_" + row_div);
			Label label = new Label(1, row, locator);
			row_div=row_div+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			if(locator.contains("//img["))
			{
			
			Label label1 = new Label(0, row, "index_2_" + row_im);
			Label label = new Label(1, row, locator);
			row_im=row_im+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			if(locator.contains("//textarea["))
			{
			
			Label label1 = new Label(0, row, "index_3_" + row_te);
			Label label = new Label(1, row, locator);
			row_te=row_te+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			if(locator.contains("//a["))
			{
			
			Label label1 = new Label(0, row, "index_4_" + row_a);
			Label label = new Label(1, row, locator);
			row_a=row_a+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			if(locator.contains("//h["))
			{
			
			Label label1 = new Label(0, row, "index_5_" + row_h);
			Label label = new Label(1, row, locator);
			row_h=row_h+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			if(locator.contains("//font["))
			{
			
			Label label1 = new Label(0, row, "index_6_" + row_fo);
			Label label = new Label(1, row, locator);
			row_fo=row_fo+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
			
			if(locator.contains("//span["))
			{
			Label label1 = new Label(0, row, "index_7_" + row_span);
			Label label = new Label(1, row, locator);
			row_span=row_span+1;
			row = row + 1;
			
			ws.addCell(label);
			ws.addCell(label1);
			}
		}
		copy.write();
		copy.close();
	    }
	
	/*creates a new sheet in the excel-sheet and writes all the xpath created into the sheet*/
	public static void newSheetCreation(List<String> locators, String path, String sheetname)throws BiffException, IOException, RowsExceededException, WriteException
    {
		boolean createflag = false;
		Workbook workbook1 = Workbook.getWorkbook(new File(path));
		WritableWorkbook copy = Workbook.createWorkbook(new File(path), workbook1);

		String sheets[] = copy.getSheetNames();
		for (String sheet : sheets) {
			if (sheet.equals(sheetname))
				createflag = true;
		}

		if (!createflag) {
			WritableSheet ws = copy.createSheet(sheetname, 1);
			int row = ws.getRows(); // last rows
			int row_div =0;
			int row_a =0;
			int row_span=0;
			int row_im=0;
			int row_te=0;
			int row_h=0;
			int row_fo=0;
			for (String locator : locators)
			{
				if(locator.contains("//input["))
				{
				Label label1 = new Label(0, row, "index_0_" + row);
				Label label = new Label(1, row, locator);
				
				row = row + 1;
				ws.addCell(label);
				ws.addCell(label1);
				}
				
				if(locator.contains("//div["))
				{
				
				Label label1 = new Label(0, row, "index_1_" + row_div);
				Label label = new Label(1, row, locator);
				row_div=row_div+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				if(locator.contains("//img["))
				{
				
				Label label1 = new Label(0, row, "index_2_" + row_im);
				Label label = new Label(1, row, locator);
				row_im=row_im+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				if(locator.contains("//textarea["))
				{
				
				Label label1 = new Label(0, row, "index_3_" + row_te);
				Label label = new Label(1, row, locator);
				row_te=row_te+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				if(locator.contains("//a["))
				{
				
				Label label1 = new Label(0, row, "index_4_" + row_a);
				Label label = new Label(1, row, locator);
				row_a=row_a+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				if(locator.contains("//h["))
				{
				
				Label label1 = new Label(0, row, "index_5_" + row_h);
				Label label = new Label(1, row, locator);
				row_h=row_h+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				if(locator.contains("//font["))
				{
				
				Label label1 = new Label(0, row, "index_6_" + row_fo);
				Label label = new Label(1, row, locator);
				row_fo=row_fo+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
				
				if(locator.contains("//span["))
				{
				Label label1 = new Label(0, row, "index_7_" + row_span);
				Label label = new Label(1, row, locator);
				row_span=row_span+1;
				row = row + 1;
				
				ws.addCell(label);
				ws.addCell(label1);
				}
			}
		
		copy.write();
		copy.close();
		}
	}

	/*writes the Xpath created into the excel-sheet*/
	public void writeXpathToXls(List<String> locators, String path, String sheetname) throws IOException, RowsExceededException, JXLException 
	{
		boolean createflag = true;
        File file = new File(path);
		FileOutputStream fo = null;
		WritableWorkbook wb = null;
		WritableSheet ws = null;
		if (file.exists()) 
		{
			Workbook workBook = Workbook.getWorkbook(new File(path));
			String[] sheetNames = workBook.getSheetNames();

			for (String sheetname1 : sheetNames) 
			{
				if (file.exists() && sheetname1.equals(sheetname)) 
				{
					modifyExistingExcel(locators, path, sheetname);
					createflag = false;
					break;
				} 
				else 
				{
					newSheetCreation(locators, path, sheetname);
				}
			}

		} 
		else 
		{

			if (!file.exists()) 
			{
				fo = new FileOutputStream(path);
				wb = Workbook.createWorkbook(fo);
				if (createflag) 
				{

					ws = wb.createSheet(sheetname, 1);

					int row = 0;
					int row_div =0;
					int row_a =0;
					int row_span=0;
					int row_im=0;
					int row_te=0;
					int row_h=0;
					int row_fo=0;

					for (int i = 0; i < locators.size(); i++) 
					{
						if (locators.get(i).contains("=null"))
							locators.remove(i);

					}
					for (String locator : locators) 
					{
						
						if(locator.contains("//input["))
						{
						Label label1 = new Label(0, row, "index_0_" + row);
						Label label = new Label(1, row, locator);
						
						row = row + 1;
						ws.addCell(label);
						ws.addCell(label1);
						}
						
						if(locator.contains("//div["))
						{
						
						Label label1 = new Label(0, row, "index_1_" + row_div);
						Label label = new Label(1, row, locator);
						row_div=row_div+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						if(locator.contains("//img["))
						{
						
						Label label1 = new Label(0, row, "index_2_" + row_im);
						Label label = new Label(1, row, locator);
						row_im=row_im+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						if(locator.contains("//textarea["))
						{
						
						Label label1 = new Label(0, row, "index_3_" + row_te);
						Label label = new Label(1, row, locator);
						row_te=row_te+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						if(locator.contains("//a["))
						{
						
						Label label1 = new Label(0, row, "index_4_" + row_a);
						Label label = new Label(1, row, locator);
						row_a=row_a+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						if(locator.contains("//h["))
						{
						
						Label label1 = new Label(0, row, "index_5_" + row_h);
						Label label = new Label(1, row, locator);
						row_h=row_h+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						if(locator.contains("//font["))
						{
						
						Label label1 = new Label(0, row, "index_6_" + row_fo);
						Label label = new Label(1, row, locator);
						row_fo=row_fo+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						
						if(locator.contains("//span["))
						{
						Label label1 = new Label(0, row, "index_7_" + row_span);
						Label label = new Label(1, row, locator);
						row_span=row_span+1;
						row = row + 1;
						
						ws.addCell(label);
						ws.addCell(label1);
						}
						}

					wb.write();
					wb.close();
				}
			}
		}

	}

}
