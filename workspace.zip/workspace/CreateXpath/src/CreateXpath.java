import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;

import jxl.JXLException;

public class CreateXpath 
{
	public static WebDriver driver = null;
	public static List<String> Tagnames = new ArrayList<String>();
	static  String  xpathlocator = null;
	
	//user has to create the following excel-sheet (name it as Tagname.xls)
	public static String path = "C:/Users/rray/Desktop/locators/Tagname.xls";
	/*1.user has to create the following sheet(name it as Tagnames ) in the above created excel-sheet
	  2.mention all the tagnames in the sheet which exist in the webpage*/
	public static String sheetname = "Tagnames";


	public static void main(String[] args) throws IOException, JXLException, InterruptedException
	{
		createXpathforExcel();
 
	}
	
    //create xpath with the tagnames and write it into excel-sheet.
	public static void createXpathforExcel() throws IOException, JXLException, InterruptedException
	{
		CreateLocators cl =new CreateLocators();
		LaunchDriver ld = new LaunchDriver();
		ExcelProcessing xlsp = new ExcelProcessing();
		Tagnames=xlsp.xlsReader(path, sheetname);
		xlsp.writeTagnameToXls(Tagnames,"C:/Users/rray/Desktop/locators/Mylocatorfile.xls","Tagnames");
		driver = ld.driverLauncher();	
		cl.createXpathByTagname(driver,Tagnames);
		xlsp.writeXpathToXls(cl.relxpath,"C:/Users/rray/Desktop/locators/Mylocatorfile.xls","Xpathpage");
		driver = ld.navigateToOtherPage();
		cl.createXpathByTagname(driver, Tagnames);
		xlsp.writeXpathToXls(cl.relxpath, "C:/Users/rray/Desktop/locators/Mylocatorfile.xls", "Privacy");
		System.out.println("Xpath written to Excel");
		driver.quit();

   }
}
